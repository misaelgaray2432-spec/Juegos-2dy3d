"""Fútbol 3D en Ursina con estética de estadio y modos cooperativos."""
from __future__ import annotations

# Mantener esta importación antes de Ursina evita una colisión de DLL en Windows
# cuando TensorFlow y Panda3D se cargan en el mismo proceso.
import math
import random

from ia_futbol import IAFutbol, MODOS, clamp
from ursina import (AmbientLight, Button, Cylinder, DirectionalLight, Entity, Func, Text, destroy,
                    Ursina, Vec3, application, camera, color, held_keys, time,
                    window)


LARGO, ANCHO = 24.0, 14.0
VERDE_1 = color.rgb32(31, 119, 69)
VERDE_2 = color.rgb32(38, 132, 74)
BLANCO = color.rgb32(239, 246, 238)
AZUL = color.rgb32(31, 139, 255)
ROJO = color.rgb32(244, 71, 81)
AMARILLO = color.rgb32(255, 203, 66)


def segmento(a: tuple[float, float], b: tuple[float, float], grosor: float = .045,
             y: float = .025, tono=BLANCO, parent=None) -> Entity:
    """Dibuja una línea sobre el plano XZ usando una caja fina."""
    dx, dz = b[0] - a[0], b[1] - a[1]
    largo = math.hypot(dx, dz)
    e = Entity(model="cube", parent=parent, color=tono,
               position=((a[0] + b[0]) / 2, y, (a[1] + b[1]) / 2),
               scale=(largo, .025, grosor))
    e.rotation_y = -math.degrees(math.atan2(dz, dx))
    return e


class Juego3D(Entity):
    """Partido 3D con equipos mixtos, físicas sencillas y HUD deportivo."""

    def __init__(self) -> None:
        super().__init__()
        window.color = color.rgb32(7, 15, 24)
        window.exit_button.visible = False
        camera.position = (0, 24, -30)
        camera.rotation = (38, 0, 0)
        camera.fov = 61
        self.estado = "menu"
        self.modo = 1
        self.ia: IAFutbol | None = None
        self.jugadores: list[dict] = []
        self.poseedor: dict | None = None
        self.arena = Entity(parent=self, enabled=True)
        self.menu_widgets: list[Entity] = []
        self.hud_widgets: list[Entity] = []
        self.balon: Entity
        self.vista_cenital = False
        self.boton_vista: Button | None = None
        self.mensaje_partido = ""
        self.mensaje_tiempo = 0.0
        self.tiempo = 0.0
        self.reloj_partido = 150.0
        self.temporizador_ia = 0.0
        self.pausa = False
        self.fin = False
        # El estadio sirve también como fondo visual del menú principal.
        self._crear_estadio()
        self._crear_balon()
        self.balon.enabled = False
        self._menu()

    # ------------------------------- Menús ---------------------------------
    def _menu(self) -> None:
        # Paneles translúcidos; el estadio iluminado sigue visible detrás del menú.
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", scale=(2, 2),
                                        color=color.rgba32(3, 9, 17, 115)))
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(-.18, 0),
                                        scale=(.54, .90), color=color.rgba32(7, 17, 29, 236)))
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(.31, 0),
                                        scale=(.42, .90), color=color.rgba32(8, 20, 32, 232)))
        self.menu_widgets.append(Text("PITCH  /  MATCH CENTER", parent=camera.ui,
                                      x=-.18, y=.385, scale=.78, color=AMARILLO))
        self.menu_widgets.append(Text("FÚTBOL 3D + IA", parent=camera.ui,
                                      x=-.18, y=.315, scale=1.45, color=BLANCO))
        self.menu_widgets.append(Text("ELIGE EL FORMATO DEL PARTIDO", parent=camera.ui,
                                      x=-.18, y=.245, scale=.67,
                                      color=color.rgb32(174, 195, 207)))

        modos = [
            ("UN JUGADOR VS IA", "Un jugador local contra la computadora"),
            ("DUELO LOCAL", "J1 contra J2 · teclado compartido"),
            ("COOPERATIVO", "Una IA frente a dos jugadores humanos"),
            ("PARTIDO 2 VS 2", "Dos IA contra J1 y J2 cooperativos"),
        ]
        tonos = [AZUL, color.rgb32(111, 210, 164), AMARILLO, ROJO]
        for i, (titulo, detalle) in enumerate(modos):
            y = .145 - i * .118
            self.menu_widgets.append(Entity(parent=camera.ui, model="quad",
                                            position=(-.18, y), scale=(.48, .101),
                                            color=color.rgb32(17, 35, 50)))
            self.menu_widgets.append(Entity(parent=camera.ui, model="quad",
                                            position=(-.407, y), scale=(.008, .082),
                                            color=tonos[i]))
            boton = Button(parent=camera.ui, text=f"0{i + 1}   ·   {titulo}",
                           position=(-.18, y + .014), scale=(.43, .043),
                           color=color.rgba32(20, 39, 55, 255),
                           highlight_color=color.rgb32(39, 66, 83),
                           pressed_color=tonos[i], text_color=BLANCO,
                           text_size=.90, on_click=Func(self.iniciar, i + 1))
            self.menu_widgets.append(boton)
            self.menu_widgets.append(Text(detalle, parent=camera.ui, x=-.18,
                                          y=y - .027, scale=.55,
                                          color=color.rgb32(163, 186, 198)))

        self.menu_widgets.append(Text("VISTA DEL ESTADIO", parent=camera.ui,
                                      x=.31, y=.385, scale=.78, color=AMARILLO))
        self.menu_widgets.append(Text("Cancha táctica · IA en tiempo real",
                                      parent=camera.ui, x=.31, y=.337, scale=.58,
                                      color=color.rgb32(166, 189, 202)))
        # Miniatura de cancha con líneas reglamentarias, como adelanto de la vista cenital.
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(.31, .12),
                                        scale=(.30, .30), color=BLANCO))
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(.31, .12),
                                        scale=(.292, .292), color=color.rgb32(31, 119, 69)))
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(.31, .12),
                                        scale=(.002, .287), color=color.rgb32(222, 232, 222)))
        self.menu_widgets.append(Entity(parent=camera.ui, model="quad", position=(.31, .12),
                                        scale=(.287, .002), color=color.rgb32(222, 232, 222)))
        for lado in (-1, 1):
            self.menu_widgets.append(Entity(parent=camera.ui, model="quad",
                                            position=(.31 + lado * .125, .12),
                                            scale=(.035, .105),
                                            color=color.rgb32(209, 227, 215)))
            self.menu_widgets.append(Entity(parent=camera.ui, model="quad",
                                            position=(.31 + lado * .125, .12),
                                            scale=(.031, .101),
                                            color=color.rgb32(31, 119, 69)))
        self.menu_widgets.append(Text("AZUL  ·  IA / LOCAL  ·  ROJO",
                                      parent=camera.ui, x=.31, y=-.065, scale=.54,
                                      color=color.rgb32(190, 207, 214)))
        self.boton_vista = Button(parent=camera.ui, text="", position=(.31, -.145),
                                  scale=(.32, .055), color=color.rgb32(30, 54, 72),
                                  highlight_color=color.rgb32(49, 82, 99),
                                  pressed_color=AMARILLO, text_color=BLANCO,
                                  text_size=.72, on_click=Func(self._alternar_vista))
        self.menu_widgets.append(self.boton_vista)
        self._actualizar_boton_vista()
        self.menu_widgets.append(Text("V también cambia la cámara durante el partido",
                                      parent=camera.ui, x=.31, y=-.195, scale=.49,
                                      color=color.rgb32(150, 174, 188)))
        self.menu_widgets.append(Text("J1  WASD · ESPACIO tiro · Q pase · F robo",
                                      parent=camera.ui, x=.31, y=-.285, scale=.50,
                                      color=color.rgb32(195, 211, 218)))
        self.menu_widgets.append(Text("J2  FLECHAS · CTRL DER. tiro · ENTER pase · ALT robo",
                                      parent=camera.ui, x=.31, y=-.325, scale=.44,
                                      color=color.rgb32(166, 190, 201)))
        self.menu_widgets.append(Text("1–4 seleccionar modo  ·  ESC salir",
                                      parent=camera.ui, x=-.18, y=-.405, scale=.58,
                                      color=color.rgb32(133, 158, 174)))

    def _actualizar_boton_vista(self) -> None:
        if self.boton_vista is not None:
            self.boton_vista.text = ("CAMBIAR A TRANSMISIÓN 3D" if self.vista_cenital
                                     else "CAMBIAR A VISTA CENITAL 2D")

    def _configurar_camara(self) -> None:
        """Alterna entre retransmisión inclinada y táctica cenital tipo 2D."""
        if self.vista_cenital:
            camera.position = (0, 31, 0)
            camera.rotation = (90, 0, 0)
            camera.fov = 42
        else:
            camera.position = (0, 23, -29)
            camera.rotation = (38, 0, 0)
            camera.fov = 61

    def _alternar_vista(self) -> None:
        self.vista_cenital = not self.vista_cenital
        self._configurar_camara()
        self._actualizar_boton_vista()

    def _crear_hud(self) -> None:
        self.hud_widgets = [
            Entity(parent=camera.ui, model="quad", position=(0, .455),
                   scale=(.78, .105), color=color.rgba32(7, 18, 30, 225)),
            Text("", parent=camera.ui, y=.46, scale=1.05, color=BLANCO),
            Text("", parent=camera.ui, y=-.455, scale=.65,
                 color=color.rgb32(202, 216, 219)),
            Text("", parent=camera.ui, y=.36, scale=.8, color=AMARILLO),
        ]

    def _hud_visible(self, visible: bool) -> None:
        for widget in self.hud_widgets:
            widget.enabled = visible

    # ---------------------------- Estadio/campo -----------------------------
    def _crear_estadio(self) -> None:
        # Iluminación y suelo del estadio.
        Entity(parent=self.arena, model="plane", scale=(42, 1, 31),
               color=color.rgb32(22, 37, 43), position=(0, -.32, 0))
        Entity(parent=self.arena, model="plane", scale=(LARGO, 1, ANCHO),
               color=VERDE_1, position=(0, -.13, 0))
        for i in range(12):
            x = -LARGO / 2 + i * LARGO / 12 + LARGO / 24
            Entity(parent=self.arena, model="cube", color=VERDE_1 if i % 2 == 0 else VERDE_2,
                   position=(x, -.045, 0), scale=(LARGO / 12, .035, ANCHO - .12))

        # Líneas blancas reglamentarias.
        x0, x1, z0, z1 = -LARGO / 2, LARGO / 2, -ANCHO / 2, ANCHO / 2
        segmento((x0, z0), (x1, z0), parent=self.arena)
        segmento((x0, z1), (x1, z1), parent=self.arena)
        segmento((x0, z0), (x0, z1), parent=self.arena)
        segmento((x1, z0), (x1, z1), parent=self.arena)
        segmento((0, z0), (0, z1), parent=self.arena)
        # Círculo central y punto de saque dibujados como líneas segmentadas.
        self._circulo((0, .04, 0), 2.0, 48, parent=self.arena)
        Entity(parent=self.arena, model="sphere", color=BLANCO, scale=.12,
               position=(0, .035, 0))
        for lado in (-1, 1):
            x = lado * 8.0
            xa = lado * 12.0
            # Área grande (16 x 6), área chica (5 x 3.2), penal y semicírculo.
            segmento((xa, -3), (x, -3), parent=self.arena)
            segmento((x, -3), (x, 3), parent=self.arena)
            segmento((x, 3), (xa, 3), parent=self.arena)
            xc = lado * 10.35
            segmento((xa, -1.65), (xc, -1.65), parent=self.arena)
            segmento((xc, -1.65), (xc, 1.65), parent=self.arena)
            segmento((xc, 1.65), (xa, 1.65), parent=self.arena)
            Entity(parent=self.arena, model="sphere", color=BLANCO, scale=.11,
                   position=(lado * 8.1, .035, 0))
            self._arco_penal(lado, parent=self.arena)
            self._portería(lado, parent=self.arena)

        # Tribunas escalonadas, vallas y focos para dejar clara la escala del estadio.
        for i in range(3):
            altura = .6 + i * .55
            for lado in (-1, 1):
                Entity(parent=self.arena, model="cube", color=color.rgb32(23 + i * 5, 38 + i * 5, 53 + i * 6),
                       position=(0, altura, lado * (8.2 + i * .62)), scale=(30, .7, .75))
                Entity(parent=self.arena, model="cube", color=color.rgb32(22 + i * 4, 38 + i * 4, 54 + i * 5),
                       position=(lado * (13.1 + i * .55), altura, 0), scale=(.75, .7, 17))
        self._multitud()
        for x in (-14.8, 14.8):
            for z in (-9.6, 9.6):
                Entity(parent=self.arena, model=Cylinder(), color=color.rgb32(70, 85, 99),
                       position=(x, 4.1, z), scale=(.12, 8.2, .12))
                Entity(parent=self.arena, model="cube", color=color.rgb32(213, 233, 255),
                       position=(x, 8.15, z), scale=(1.1, .2, .45))
        # Paneles luminosos y banderines de esquina completan la lectura de estadio.
        tonos_panel = [color.rgb32(24, 91, 143), color.rgb32(26, 120, 91),
                       color.rgb32(146, 91, 32)]
        for i, x in enumerate(range(-9, 10, 3)):
            for lado in (-1, 1):
                Entity(parent=self.arena, model="cube", color=tonos_panel[i % len(tonos_panel)],
                       position=(x, .20, lado * 7.22), scale=(2.75, .34, .10))
        for x in (-11.7, 11.7):
            for z in (-6.7, 6.7):
                Entity(parent=self.arena, model=Cylinder(), color=color.rgb32(232, 236, 222),
                       position=(x, .36, z), scale=(.035, .72, .035))
                Entity(parent=self.arena, model="cube",
                       color=AZUL if (x * z) > 0 else ROJO,
                       position=(x + .13, .60, z), scale=(.27, .16, .025))
        sol = DirectionalLight(parent=self.arena, y=12, z=-5)
        sol.look_at(Vec3(0, 0, 0))
        AmbientLight(parent=self.arena, color=color.rgba32(115, 130, 150, 255))
        self._configurar_camara()

    def _circulo(self, centro: tuple[float, float, float], radio: float,
                 pasos: int, parent) -> None:
        cx, y, cz = centro
        puntos = [(cx + math.cos(i * 2 * math.pi / pasos) * radio,
                   cz + math.sin(i * 2 * math.pi / pasos) * radio) for i in range(pasos + 1)]
        for a, b in zip(puntos, puntos[1:]):
            segmento(a, b, grosor=.04, y=y, parent=parent)

    def _arco_penal(self, lado: int, parent) -> None:
        cx, radio = lado * 8.1, 2.0
        puntos = []
        # Sólo se dibuja el arco que queda fuera del rectángulo del área.
        inicio = math.pi / 2 if lado == 1 else -math.pi / 2
        for i in range(25):
            ang = inicio + i * math.pi / 24
            puntos.append((cx + math.cos(ang) * radio, math.sin(ang) * radio))
        for a, b in zip(puntos, puntos[1:]):
            segmento(a, b, y=.035, parent=parent)

    def _portería(self, lado: int, parent) -> None:
        x = lado * 12.35
        poste = color.rgb32(245, 246, 233)
        for z in (-1.7, 1.7):
            Entity(parent=parent, model="cube", color=poste,
                   position=(x, .95, z), scale=(.16, 1.9, .16))
        Entity(parent=parent, model="cube", color=poste,
               position=(x, 1.9, 0), scale=(.16, .16, 3.5))
        fondo_x = lado * 13.7
        # Malla visible en fondo y laterales del arco.
        for i in range(8):
            z = -1.65 + i * .47
            segmento((fondo_x, z), (x, z), grosor=.022, y=.15, tono=color.rgb32(174, 197, 193), parent=parent)
        for z in (-1.7, 1.7):
            for i in range(5):
                yy = .15 + i * .36
                Entity(parent=parent, model="cube", color=color.rgb32(172, 195, 190),
                       position=((x + fondo_x) / 2, yy, z),
                       scale=(abs(fondo_x - x), .018, .018))

    def _multitud(self) -> None:
        rng = random.Random(29)
        tonos = [color.rgb32(47, 134, 224), color.rgb32(228, 74, 83),
                 color.rgb32(244, 202, 75), color.rgb32(223, 229, 221),
                 color.rgb32(48, 173, 126)]
        # Puntos de color como público lejano en las cuatro tribunas.
        for i in range(360):
            color_fan = rng.choice(tonos)
            lado = rng.choice((-1, 1))
            if i % 2:
                x, z = rng.uniform(-13, 13), lado * rng.uniform(8.5, 10.1)
            else:
                x, z = lado * rng.uniform(13, 15.1), rng.uniform(-7.8, 7.8)
            y = rng.choice((.95, 1.5, 2.05))
            Entity(parent=self.arena, model="sphere", color=color_fan,
                   position=(x, y, z), scale=.11)

    # --------------------------- Inicio y entidades ------------------------
    def iniciar(self, modo: int) -> None:
        self.modo = modo
        self.ia = IAFutbol()
        self.ia.log.start(modo)
        for widget in self.menu_widgets:
            widget.enabled = False
        # Conserva el estadio del menú y recrea únicamente los actores del partido.
        for jugador in self.jugadores:
            destroy(jugador["e"])
        if self.balon:
            destroy(self.balon)
        self._crear_jugadores()
        self._crear_balon()
        self._iniciar_saque(0)
        if not self.hud_widgets:
            self._crear_hud()
        self._hud_visible(True)
        self.tiempo = self.temporizador_ia = 0.0
        self.reloj_partido = 150.0
        self.pausa = self.fin = False
        self.estado = "partido"
        self._configurar_camara()

    def _iniciar_saque(self, equipo: int) -> None:
        """Da el balón al equipo que recibe el gol y devuelve a todos a su posición."""
        signo = 1 if equipo == 0 else -1
        for jugador in self.jugadores:
            jugador["e"].position = (jugador["casa"][0], 0, jugador["casa"][1])
            jugador["objetivo"] = jugador["casa"]
            jugador["direccion"] = (float(signo), 0.0)
            jugador["e"].rotation_y = math.degrees(math.atan2(-signo, 0))
            jugador["moviendo"] = False
            jugador["recarga_robo"] = 0.0

        sacador = min((p for p in self.jugadores if p["equipo"] == equipo),
                      key=lambda p: p["indice"], default=None)
        if sacador is not None:
            sacador["e"].position = (-signo * .72, 0, 0)
            sacador["objetivo"] = (-signo * .72, 0.0)
            sacador["direccion"] = (float(signo), 0.0)
            sacador["e"].rotation_y = math.degrees(math.atan2(-signo, 0))
            sacador["recarga_robo"] = .8
        self.poseedor = sacador
        self.balon.position = (0, .42, 0)
        self.vel_balon = Vec3(0, 0, 0)
        self.mensaje_partido = "SAQUE INICIAL · " + ("AZUL" if equipo == 0 else "ROJO")
        self.mensaje_tiempo = 2.0

    def _crear_jugadores(self) -> None:
        configuraciones = {
            1: [(0, "H1"), (1, "IA")],
            2: [(0, "H1"), (1, "H2")],
            3: [(0, "IA"), (1, "H1"), (1, "H2")],
            4: [(0, "IA"), (0, "IA"), (1, "H1"), (1, "H2")],
        }
        conteo = {0: 0, 1: 0}
        self.jugadores = []
        for equipo, control in configuraciones[self.modo]:
            indice = conteo[equipo]
            conteo[equipo] += 1
            x = -6.6 if equipo == 0 else 6.6
            z = (-1.7 if indice == 0 else 1.7) if conteo[equipo] > 1 else 0
            equipo_color = AZUL if equipo == 0 else ROJO
            actor = Entity(parent=self.arena, position=(x, 0, z))
            # Sombra de contacto y figura humana compuesta para anclar al jugador al césped.
            Entity(parent=actor, model="sphere", color=color.rgb32(18, 58, 38),
                   position=(0, .045, 0), scale=(.78, .055, .96))
            Entity(parent=actor, model="cube", color=color.rgb32(23, 29, 37),
                   position=(0, .17, .02), scale=(.28, .20, .40))
            piernas, brazos = [], []
            for lado in (-1, 1):
                pierna = Entity(parent=actor, model=Cylinder(), color=color.rgb32(35, 45, 53),
                                position=(lado * .14, .32, 0), scale=(.13, .39, .15))
                piernas.append(pierna)
                Entity(parent=actor, model="cube", color=color.rgb32(245, 242, 221),
                       position=(lado * .14, .12, -.13), scale=(.15, .09, .24))
                brazo = Entity(parent=actor, model=Cylinder(), color=equipo_color,
                               position=(lado * .31, .79, 0), rotation_z=-lado * 12,
                               scale=(.12, .47, .12))
                brazos.append(brazo)
            Entity(parent=actor, model="cube", color=equipo_color,
                   position=(0, .83, 0), scale=(.52, .57, .34))
            Entity(parent=actor, model="cube", color=color.rgb32(246, 246, 237),
                   position=(0, .82, -.177), scale=(.045, .39, .012))
            Entity(parent=actor, model="sphere", color=color.rgb32(222, 174, 137),
                   position=(0, 1.27, 0), scale=.34)
            Entity(parent=actor, model="sphere", color=color.rgb32(45, 37, 34),
                   position=(0, 1.40, -.015), scale=(.35, .13, .34))
            dorsal = Text(str(indice + 1), parent=actor, position=(0, .84, -.185),
                          rotation=(0, 0, 0), scale=4.4, color=color.white)
            dorsal.billboard = True
            self.jugadores.append({"equipo": equipo, "indice": indice, "control": control,
                                   "nombre": f"E{equipo + 1}_J{indice + 1}", "e": actor,
                                   "casa": (x, z), "objetivo": (x, z), "stamina": 1.0,
                                   "direccion": (1.0 if equipo == 0 else -1.0, 0.0),
                                   "recarga_robo": 0.0, "piernas": piernas,
                                   "brazos": brazos, "fase": indice * 1.4,
                                   "moviendo": False})

    def _animar_jugadores(self, dt: float) -> None:
        """Balancea brazos y piernas mientras corren para dar vida a la escena."""
        for jugador in self.jugadores:
            if jugador["moviendo"]:
                jugador["fase"] += dt * 13.0
                paso = math.sin(jugador["fase"]) * 20
                for indice, pierna in enumerate(jugador["piernas"]):
                    pierna.rotation_z = paso if indice == 0 else -paso
                for indice, brazo in enumerate(jugador["brazos"]):
                    brazo.rotation_z = (-12 if indice == 0 else 12) - (paso * .45 if indice == 0 else -paso * .45)
            else:
                for indice, pierna in enumerate(jugador["piernas"]):
                    pierna.rotation_z = 0
                for indice, brazo in enumerate(jugador["brazos"]):
                    brazo.rotation_z = -12 if indice == 0 else 12

    def _crear_balon(self) -> None:
        self.balon = Entity(parent=self.arena, model="sphere", color=color.rgb32(246, 246, 233),
                            scale=.42, position=(0, .35, 0))
        for i in range(5):
            ang = i * math.tau / 5
            Entity(parent=self.balon, model="sphere", color=color.rgb32(35, 42, 48),
                   position=(math.cos(ang) * .28, math.sin(ang) * .20, -.04),
                   scale=.105)
        self.vel_balon = Vec3(0, 0, 0)

    # ------------------------------ Controles ------------------------------
    def _movimiento(self, control: str) -> tuple[float, float, bool]:
        if control == "H1":
            dx = held_keys["d"] - held_keys["a"]
            dz = held_keys["s"] - held_keys["w"]
            correr = held_keys["left shift"]
        else:
            dx = held_keys["right arrow"] - held_keys["left arrow"]
            dz = held_keys["down arrow"] - held_keys["up arrow"]
            correr = held_keys["right shift"]
        return dx, dz, bool(correr)

    def _accion(self, tecla: str) -> None:
        es_j1 = tecla in ("space", "q")
        p = next((j for j in self.jugadores if j["control"] == ("H1" if es_j1 else "H2")), None)
        if p is None:
            return
        companero = next((j for j in self.jugadores if j["equipo"] == p["equipo"] and j is not p), None)
        self._patear(p, "pase" if tecla in ("q", "enter") else "tiro", companero)

    def _robar(self, control: str) -> None:
        """El usuario disputa la posesión cerca del portador o recoge un balón dividido."""
        p = next((j for j in self.jugadores if j["control"] == control), None)
        if p is None:
            return
        objetivo = self.poseedor
        bx, bz = ((objetivo["e"].x, objetivo["e"].z) if objetivo
                  else (self.balon.x, self.balon.z))
        distancia = math.hypot(p["e"].x - bx, p["e"].z - bz)
        if objetivo is not None and objetivo["equipo"] != p["equipo"] and distancia < 1.35:
            self.poseedor = p
            p["recarga_robo"] = .65
            self.vel_balon = Vec3(0, 0, 0)
        elif objetivo is None and distancia < 1.15:
            self.poseedor = p
            self.vel_balon = Vec3(0, 0, 0)

    def _patear(self, p: dict, accion: str, companero: dict | None = None) -> None:
        if math.hypot(p["e"].x - self.balon.x, p["e"].z - self.balon.z) > 1.55:
            return
        if self.poseedor is not None and self.poseedor["equipo"] != p["equipo"]:
            return
        signo = 1 if p["equipo"] == 0 else -1
        if accion == "pase" and companero:
            dx = companero["e"].x + companero["direccion"][0] * .8 - self.balon.x
            dz = companero["e"].z + companero["direccion"][1] * .8 - self.balon.z
            potencia = 7.2
            altura = 1.4
        elif accion == "pase":
            # Sin compañero cercano, el usuario puede filtrar el balón al espacio.
            dx, dz = p["direccion"]
            potencia = 6.3
            altura = .9
        else:
            teclas = {"H1": ("d", "a", "s", "w"),
                      "H2": ("right arrow", "left arrow", "down arrow", "up arrow")}
            if p["control"] in teclas:
                derecha, izquierda, abajo, arriba = teclas[p["control"]]
                dx = held_keys[derecha] - held_keys[izquierda]
                dz = held_keys[abajo] - held_keys[arriba]
                if math.hypot(dx, dz) > 0:
                    largo_aim = math.hypot(dx, dz)
                    p["direccion"] = (dx / largo_aim, dz / largo_aim)
            dx, dz = p["direccion"]
            potencia = 10.5
            altura = 3.3
        largo = max(.001, math.hypot(dx, dz))
        self.vel_balon = Vec3(dx / largo * potencia, altura, dz / largo * potencia)
        self.poseedor = None
        if self.ia:
            self.ia.log.action(p["equipo"], p["nombre"], accion, self.tiempo)

    def input(self, key: str) -> None:
        if key == "escape":
            if self.estado == "partido":
                if self.ia and not self.ia.log.done:
                    self.ia.log.finish()
                self.estado = "menu"
                for jugador in self.jugadores:
                    jugador["e"].enabled = False
                self.balon.enabled = False
                self._hud_visible(False)
                for widget in self.menu_widgets:
                    widget.enabled = True
            else:
                application.quit()
        elif self.estado == "menu" and key in ("1", "2", "3", "4"):
            self.iniciar(int(key))
        elif key == "v":
            self._alternar_vista()
        elif self.estado == "partido":
            if key == "p" and not self.fin:
                self.pausa = not self.pausa
            elif key in ("space", "q", "right control", "enter") and not self.pausa and not self.fin:
                self._accion(key)
            elif key in ("f", "right alt") and not self.pausa and not self.fin:
                self._robar("H1" if key == "f" else "H2")
            elif key == "r" and self.fin:
                self.iniciar(self.modo)

    # -------------------------------- Bucle ---------------------------------
    def update(self) -> None:
        if self.estado != "partido" or self.pausa or self.fin:
            self._actualizar_hud()
            return
        dt = min(time.dt, .04)
        self.tiempo += dt
        self.mensaje_tiempo = max(0.0, self.mensaje_tiempo - dt)
        self.reloj_partido = max(0.0, self.reloj_partido - dt)
        for p in self.jugadores:
            if p["control"] == "IA":
                continue
            dx, dz, sprint = self._movimiento(p["control"])
            magnitud = math.hypot(dx, dz)
            p["moviendo"] = magnitud > 0
            if magnitud:
                dx, dz = dx / magnitud, dz / magnitud
                velocidad = 6.4 if sprint and p["stamina"] > .06 else 4.8
                if self.poseedor is p:
                    velocidad *= .84
                p["e"].x = clamp(p["e"].x + dx * velocidad * dt, -11.4, 11.4)
                p["e"].z = clamp(p["e"].z + dz * velocidad * dt, -6.4, 6.4)
                p["direccion"] = (dx, dz)
                # El modelo mira hacia -Z en reposo; se orienta al vector de movimiento.
                p["e"].rotation_y = math.degrees(math.atan2(-dx, -dz))
                p["stamina"] = max(0.0, p["stamina"] - dt * (.22 if sprint else .07))
            else:
                p["stamina"] = min(1.0, p["stamina"] + dt * .15)

        for p in self.jugadores:
            p["recarga_robo"] = max(0.0, p["recarga_robo"] - dt)
        self._actualizar_ia(dt)
        self._animar_jugadores(dt)
        self._actualizar_posesion(dt)
        self._actualizar_balon(dt)
        if self.reloj_partido <= 0:
            self.fin = True
            if self.ia:
                self.ia.log.finish()
        self._actualizar_hud()

    def _actualizar_ia(self, dt: float) -> None:
        if not self.ia:
            return
        self.temporizador_ia -= dt
        if self.temporizador_ia <= 0:
            self.temporizador_ia = .18
            ia_jugadores = [p for p in self.jugadores if p["control"] == "IA"]
            equipos: dict[int, list[dict]] = {}
            for p in ia_jugadores:
                equipos.setdefault(p["equipo"], []).append(p)
            for equipo, miembros in equipos.items():
                signo = 1 if equipo == 0 else -1
                compañeros = [q for q in self.jugadores if q["equipo"] == equipo]
                for p in miembros:
                    compañero = min((q for q in compañeros if q is not p),
                                    key=lambda q: math.hypot(q["e"].x - self.balon.x,
                                                             q["e"].z - self.balon.z), default=None)
                    actor = (p["e"].x / 12, p["e"].z / 7)
                    mate = (compañero["e"].x / 12, compañero["e"].z / 7) if compañero else None
                    accion, prediccion = self.ia.decide((self.balon.x / 12, self.balon.z / 7,
                                                          clamp(self.balon.y / 3, 0, 1)), actor, mate,
                                                         signo)
                    if self.poseedor is p:
                        distancia_meta = abs((12 if equipo == 0 else -12) - p["e"].x)
                        rivales = [q for q in self.jugadores if q["equipo"] != equipo]
                        presion = min((math.hypot(p["e"].x - q["e"].x,
                                                  p["e"].z - q["e"].z) for q in rivales), default=99)
                        objetivo = (p["e"].x + signo * 2.0, p["e"].z * .72)
                        p["objetivo"] = (clamp(objetivo[0], -10.8, 10.8),
                                          clamp(objetivo[1], -5.9, 5.9))
                        if distancia_meta < 4.5 and math.hypot(p["e"].x - self.balon.x,
                                                               p["e"].z - self.balon.z) < 1.3:
                            self._patear(p, "tiro", compañero)
                        elif (compañero and presion < 1.55 and accion == "pase"
                              and math.hypot(p["e"].x - self.balon.x,
                                             p["e"].z - self.balon.z) < 1.3):
                            self._patear(p, "pase", compañero)
                    elif self.poseedor and self.poseedor["equipo"] != equipo:
                        portador = self.poseedor
                        presionador = min(miembros, key=lambda q: math.hypot(
                            q["e"].x - portador["e"].x, q["e"].z - portador["e"].z))
                        if p is presionador:
                            p["objetivo"] = (portador["e"].x, portador["e"].z)
                        else:
                            p["objetivo"] = ((p["casa"][0] + self.balon.x) / 2,
                                              (p["casa"][1] + self.balon.z) / 2)
                    elif self.poseedor is None:
                        cazador = min(miembros, key=lambda q: math.hypot(
                            q["e"].x - self.balon.x, q["e"].z - self.balon.z))
                        if p is cazador:
                            p["objetivo"] = (self.balon.x, self.balon.z)
                        else:
                            p["objetivo"] = (clamp(self.balon.x + signo * 2.0, -10.5, 10.5),
                                              clamp(self.balon.z + (-1.5 if p["indice"] == 0 else 1.5),
                                                    -5.5, 5.5))
                    else:
                        p["objetivo"] = (clamp(self.poseedor["e"].x + signo * 2.0, -10.5, 10.5),
                                          clamp(self.poseedor["e"].z + (1.5 if p["indice"] else -1.5),
                                                -5.5, 5.5))
                    if accion == "apoyo" and self.poseedor is None:
                        p["objetivo"] = (clamp(prediccion[0] * 12, -10.5, 10.5),
                                          clamp(prediccion[1] * 7, -5.5, 5.5))
        for p in self.jugadores:
            if p["control"] != "IA":
                continue
            dx, dz = p["objetivo"][0] - p["e"].x, p["objetivo"][1] - p["e"].z
            distancia = math.hypot(dx, dz)
            if distancia > .08:
                velocidad = min(5.2, distancia * 2.6)
                nx, nz = dx / distancia, dz / distancia
                p["moviendo"] = True
                p["e"].x += nx * velocidad * dt
                p["e"].z += nz * velocidad * dt
                p["direccion"] = (nx, nz)
                p["e"].rotation_y = math.degrees(math.atan2(-nx, -nz))
            else:
                p["moviendo"] = False

    def _actualizar_posesion(self, dt: float) -> None:
        """Pega el balón al portador y permite intercepciones y recuperaciones."""
        if self.poseedor is not None:
            p = self.poseedor
            dx, dz = p["direccion"]
            self.balon.position = (p["e"].x + dx * .72, .42, p["e"].z + dz * .72)
            self.vel_balon = Vec3(0, 0, 0)
            # La defensa de la máquina intenta recuperar el balón al entrar en rango.
            for defensor in self.jugadores:
                if (defensor["control"] == "IA" and defensor["equipo"] != p["equipo"]
                        and defensor["recarga_robo"] <= 0 and p["recarga_robo"] <= 0
                        and math.hypot(defensor["e"].x - p["e"].x,
                                       defensor["e"].z - p["e"].z) < .78):
                    self.poseedor = defensor
                    defensor["recarga_robo"] = .8
                    break
            if self.poseedor is not None:
                return

        velocidad = math.hypot(self.vel_balon.x, self.vel_balon.z)
        receptor = min(self.jugadores, key=lambda q: math.hypot(
            q["e"].x - self.balon.x, q["e"].z - self.balon.z), default=None)
        umbral = .78 if velocidad < 5.0 else .48
        if (receptor and self.balon.y < 1.25
                and math.hypot(receptor["e"].x - self.balon.x,
                               receptor["e"].z - self.balon.z) < umbral):
            self.poseedor = receptor
            self.vel_balon = Vec3(0, 0, 0)

    def _actualizar_balon(self, dt: float) -> None:
        if self.poseedor is not None:
            return
        self.vel_balon.y -= 9.8 * dt
        self.balon.position += self.vel_balon * dt
        self.balon.rotation_x += self.vel_balon.z * dt * 70
        self.balon.rotation_z -= self.vel_balon.x * dt * 70
        if self.balon.y < .34:
            self.balon.y = .34
            self.vel_balon.y = abs(self.vel_balon.y) * .40
            self.vel_balon.x *= .985
            self.vel_balon.z *= .985
        if abs(self.balon.z) > 6.75:
            self.balon.z = clamp(self.balon.z, -6.75, 6.75)
            self.vel_balon.z *= -.62
        if abs(self.balon.x) > 12.35:
            if abs(self.balon.z) < 1.72 and self.balon.y < 2.05:
                equipo = 0 if self.balon.x > 0 else 1
                candidatos = [p for p in self.jugadores if p["equipo"] == equipo]
                autor = min(candidatos, key=lambda p: math.hypot(p["e"].x - self.balon.x,
                                                                  p["e"].z - self.balon.z), default=None)
                if self.ia:
                    self.ia.log.goal(equipo, autor["nombre"] if autor else "Equipo", self.tiempo)
                    if max(self.ia.log.score.values()) >= 5:
                        self.fin = True
                        self.ia.log.finish()
                equipo_saque = 1 - equipo
                self._iniciar_saque(equipo_saque)
                self.mensaje_partido = (
                    f"¡GOL {('AZUL' if equipo == 0 else 'ROJO')}!  ·  "
                    f"SAQUE {('AZUL' if equipo_saque == 0 else 'ROJO')}"
                )
                self.mensaje_tiempo = 2.4
            else:
                self.balon.x = math.copysign(12.35, self.balon.x)
                self.vel_balon.x *= -.62

    def _actualizar_hud(self) -> None:
        if not self.hud_widgets or not self.ia:
            return
        _, marcador, ayuda, etiqueta = self.hud_widgets
        minutos, segundos = divmod(int(self.reloj_partido), 60)
        marcador.text = (f"AZUL   {self.ia.log.score[0]}     ·     {self.ia.log.score[1]}   ROJO       "
                         f"{minutos:02}:{segundos:02}")
        ayuda.text = "WASD · ESPACIO tiro · Q pase · F robo · SHIFT sprint      │      " \
                     "FLECHAS · CTRL DER. tiro · ENTER pase · ALT DER. robo · V cámara"
        posesion = ("AZUL" if self.poseedor["equipo"] == 0 else "ROJA") if self.poseedor else "DIVIDIDA"
        vista = "CENITAL 2D" if self.vista_cenital else "TRANSMISIÓN 3D"
        etiqueta.text = f"{MODOS[self.modo].upper()} · {vista} · BALÓN {posesion}"
        if self.mensaje_tiempo > 0 and self.mensaje_partido:
            etiqueta.text = self.mensaje_partido
        if self.pausa:
            etiqueta.text = "PAUSA  ·  P para continuar  ·  ESC menú"
        elif self.fin:
            etiqueta.text = "FINAL  ·  R revancha  ·  ESC menú"


if __name__ == "__main__":
    app = Ursina(title="PITCH / Fútbol 3D con IA", fullscreen=False,
                 size=(1440, 810), development_mode=False,
                 editor_ui_enabled=False)
    juego = Juego3D()
    app.run()

