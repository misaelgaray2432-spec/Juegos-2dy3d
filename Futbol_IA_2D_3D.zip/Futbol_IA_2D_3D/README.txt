PITCH / FÚTBOL IA 2D Y 3D
========================

Dos juegos independientes: uno 2D con Pygame y otro 3D con Ursina.
Ambos comparten la lógica de IA y el registro de partidos de ia_futbol.py.

REQUISITOS
----------
- Windows 64 bits y Python 3.12 de 64 bits.
- Entorno virtual .2d3d activado antes de instalar o ejecutar.
- Instalar las dependencias desde esta carpeta:

    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt

La carpeta del entorno virtual no forma parte del ZIP: debe permanecer fuera
del código del juego. Si el proyecto está en C:\OCT13\Futbol_IA_2D_3D y el
entorno en C:\OCT13\.2d3d, activa el entorno desde PowerShell con:

    ..\.2d3d\Scripts\Activate.ps1

EJECUTAR
--------
Desde Futbol_IA_2D_3D, con .2d3d activo:

    python juego_2d.py
    python juego_3d.py

MODOS
-----
1. Un usuario contra la IA.
2. Dos usuarios locales.
3. Una IA contra dos usuarios cooperativos.
4. Dos IA contra dos usuarios cooperativos.

CONTROLES
---------
Jugador 1: WASD para moverse, Espacio para tirar, Q para pasar,
F para disputar/recuperar el balón y Shift izquierdo para correr.
Jugador 2: flechas para moverse, Ctrl derecho para tirar, Enter para pasar,
Alt derecho para disputar/recuperar el balón y Shift derecho para correr.
La dirección del tiro sigue la orientación del jugador; se puede apuntar
mientras se mueve. El balón se conduce al tenerlo cerca, los pases buscan al
compañero (o van al espacio si no hay uno) y los jugadores de IA presionan y
ofrecen líneas de apoyo.
Después de cada gol, el equipo que lo recibió inicia desde el centro. En el
juego 3D, pulsa V para alternar entre cámara de transmisión y vista cenital 2D.
P pausa; R inicia una revancha tras el final; Esc vuelve al menú.

DATOS E IA
----------
Al iniciar un modo se ajusta una regresión logística de Scikit-learn y una red
Keras pequeña usando datos sintéticos de demostración. Los goles, tiros, pases
y resultados se guardan en CSV dentro de data/ al cerrar o finalizar el partido.
La primera carga puede tardar unos segundos mientras se inicializan los modelos.
