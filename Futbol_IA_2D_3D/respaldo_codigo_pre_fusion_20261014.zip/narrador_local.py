"""Proceso de voz aislado: pyttsx3/SAPI con respaldo a System.Speech de Windows."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


BASE = Path(__file__).resolve().parent
ESTADO = BASE / "assets" / "narrador_estado.txt"


def guardar_estado(texto: str) -> None:
    try:
        ESTADO.parent.mkdir(parents=True, exist_ok=True)
        ESTADO.write_text(texto, encoding="utf-8")
    except OSError:
        pass


def voz_sistema_windows() -> int:
    """Lee por stdin con el sintetizador .NET que acompaña PowerShell en Windows."""
    comando = (
        "Add-Type -AssemblyName System.Speech; "
        "[Console]::InputEncoding=New-Object System.Text.UTF8Encoding($false); "
        "$v=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "try{$v.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet, "
        "[System.Speech.Synthesis.VoiceAge]::NotSet, 0, "
        "[System.Globalization.CultureInfo]::GetCultureInfo('es-CO'))}catch{}; "
        "while(($s=[Console]::In.ReadLine()) -ne $null){if($s){$v.Speak($s)}}; $v.Dispose()"
    )
    powershell = os.environ.get("WINDIR", r"C:\Windows") + r"\System32\WindowsPowerShell\v1.0\powershell.exe"
    proceso = subprocess.Popen([powershell, "-NoProfile", "-Command", comando],
                               stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, text=True, encoding="utf-8",
                               bufsize=1)
    guardar_estado("Narrador activo: System.Speech de Windows")
    for frase in sys.stdin:
        if proceso.poll() is not None:
            break
        if proceso.stdin:
            proceso.stdin.write(frase)
            proceso.stdin.flush()
    if proceso.stdin:
        proceso.stdin.close()
    return proceso.wait()


def main() -> None:
    try:
        import pyttsx3
        motor = pyttsx3.init("sapi5" if os.name == "nt" else None)
        motor.setProperty("rate", 175)
        motor.setProperty("volume", 1.0)
        voces = motor.getProperty("voices") or []
        for voz in voces:
            identificador = f"{voz.id} {voz.name}".lower()
            if any(palabra in identificador for palabra in ("spanish", "español", "es-es", "es-mx", "es_")):
                motor.setProperty("voice", voz.id)
                break
        guardar_estado("Narrador activo: pyttsx3/SAPI")
        for frase in sys.stdin:
            frase = frase.strip()
            if frase:
                motor.say(frase)
                motor.runAndWait()
        motor.stop()
    except Exception as error:
        guardar_estado(f"pyttsx3 no inició; usando voz del sistema: {error}")
        if os.name == "nt":
            try:
                voz_sistema_windows()
                return
            except Exception as error_windows:
                guardar_estado(f"Narrador no disponible: {error_windows}")
        else:
            guardar_estado(f"Narrador no disponible: {error}")


if __name__ == "__main__":
    main()
