"""Asientos, espectadores y pancartas tridimensionales del estadio."""
from __future__ import annotations

import random


def construir_detalle_estadio(parent, *, Entity, color) -> dict[str, int]:
    """Añade geometría estática ligera sobre las tribunas existentes."""
    rng = random.Random(41)
    paleta_asientos = [
        color.rgb32(32, 87, 123), color.rgb32(47, 105, 143),
        color.rgb32(49, 76, 105), color.rgb32(113, 54, 65),
    ]
    paleta_publico = [
        color.rgb32(44, 129, 214), color.rgb32(226, 74, 76),
        color.rgb32(245, 197, 63), color.rgb32(232, 237, 229),
        color.rgb32(47, 164, 119), color.rgb32(115, 90, 194),
    ]
    asientos = 0
    espectadores = 0

    def asiento(posicion, lado_grada):
        nonlocal asientos
        tono = rng.choice(paleta_asientos)
        z_respaldo = posicion[2] + lado_grada * .14
        Entity(parent=parent, model="cube", color=tono, position=posicion,
               scale=(.48, .13, .30), unlit=True)
        Entity(parent=parent, model="cube", color=tono,
               position=(posicion[0], posicion[1] + .18, z_respaldo),
               scale=(.46, .24, .055), unlit=True)
        asientos += 1

    # Tribunas longitudinales: tres niveles con butacas individuales.
    for lado in (-1, 1):
        for nivel in range(3):
            altura = .95 + nivel * .55
            z = lado * (8.2 + nivel * .62)
            for indice in range(17):
                x = -12.5 + indice * 1.56
                asiento((x, altura + .075, z), lado)

    # Gradas detrás de ambas porterías, a la misma escala que las laterales.
    for lado in (-1, 1):
        for nivel in range(3):
            altura = .95 + nivel * .55
            x = lado * (13.1 + nivel * .55)
            for indice in range(8):
                z = -6.5 + indice * 1.85
                tono = rng.choice(paleta_asientos)
                Entity(parent=parent, model="cube", color=tono,
                       position=(x, altura + .075, z),
                       scale=(.30, .13, .48), unlit=True)
                Entity(parent=parent, model="cube", color=tono,
                       position=(x + lado * .14, altura + .255, z),
                       scale=(.055, .24, .46), unlit=True)
                asientos += 1

    # Hinchas sentados como figuras geométricas: torso y cabeza con volumen.
    for lado in (-1, 1):
        for nivel in range(3):
            altura = 1.16 + nivel * .55
            z = lado * (8.2 + nivel * .62)
            for indice in range(9):
                x = -11.3 + indice * 2.82
                tono = rng.choice(paleta_publico)
                Entity(parent=parent, model="sphere", color=tono,
                       position=(x, altura + .31, z),
                       scale=(.19, .28, .16), unlit=True)
                Entity(parent=parent, model="sphere",
                       color=color.rgb32(196, 151, 116),
                       position=(x, altura + .54, z), scale=.14, unlit=True)
                espectadores += 1

    for lado in (-1, 1):
        for nivel in range(3):
            altura = 1.16 + nivel * .55
            x = lado * (13.1 + nivel * .55)
            for indice in range(4):
                z = -5.5 + indice * 3.65
                tono = rng.choice(paleta_publico)
                Entity(parent=parent, model="sphere", color=tono,
                       position=(x, altura + .31, z),
                       scale=(.19, .28, .16), unlit=True)
                Entity(parent=parent, model="sphere",
                       color=color.rgb32(196, 151, 116),
                       position=(x, altura + .54, z), scale=.14, unlit=True)
                espectadores += 1

    # Pancartas con espesor, colocadas por encima de los asientos.
    for lado in (-1, 1):
        for indice, tono in enumerate(paleta_asientos[:3]):
            x = -8 + indice * 8
            Entity(parent=parent, model="cube", color=tono,
                   position=(x, 2.52, lado * 10.12),
                   scale=(3.8, .54, .10), unlit=True)

    return {"asientos": asientos, "espectadores_3d": espectadores}
