"""Selecciones, plantillas ficticias y formación compartida por ambos juegos."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Seleccion:
    nombre: str
    sigla: str
    camiseta: tuple[int, int, int]
    detalle: tuple[int, int, int]
    bandera: tuple[tuple[int, int, int], ...]
    once: tuple[str, ...]


# Nombres ficticios para que cada selección muestre una plantilla propia sin
# depender de licencias de jugadores, clubes, escudos ni marcas comerciales.
SELECCIONES = (
    Seleccion("Argentina", "ARG", (91, 177, 220), (245, 245, 237), ((116, 192, 231), (248, 248, 239), (116, 192, 231)),
              ("Mateo Ríos", "Tomás Ibarra", "Julián Acosta", "Nicolás Vera", "Bruno Sosa", "Thiago Luna", "Franco Paredes", "Lautaro Gil", "Damián Cruz", "Santiago Moya", "Benjamín Solís")),
    Seleccion("Brasil", "BRA", (245, 202, 43), (35, 143, 82), ((36, 147, 78), (245, 205, 49), (39, 79, 157)),
              ("Caio Nunes", "Rafael Costa", "Davi Almeida", "Enzo Rocha", "João Viana", "Lucas Melo", "Pedro Reis", "Iago Freitas", "Natan Lima", "Vitor Alves", "Gabriel Moraes")),
    Seleccion("Colombia", "COL", (226, 48, 52), (246, 205, 49), ((242, 205, 47), (35, 76, 157), (204, 48, 49)),
              ("Samuel Rojas", "David Rincón", "Juan Cárdenas", "Andrés Pardo", "Kevin Salazar", "Mateo Beltrán", "Felipe Torres", "Nicolás Ospina", "Sergio Lozano", "Daniel Buitrago", "Esteban Murillo")),
    Seleccion("España", "ESP", (203, 48, 49), (242, 198, 55), ((196, 43, 48), (238, 197, 53), (196, 43, 48)),
              ("Álvaro León", "Diego Campos", "Pablo Rivas", "Mario Soler", "Hugo Marín", "Adrián Vidal", "Iker Santos", "Marco Gil", "Sergio Alba", "Raúl Vega", "Leo Navarro")),
    Seleccion("Francia", "FRA", (48, 78, 160), (239, 241, 239), ((46, 69, 145), (239, 239, 232), (202, 54, 58)),
              ("Noah Laurent", "Lucas Petit", "Ethan Moreau", "Hugo Bernard", "Enzo Robert", "Adam Richard", "Léo Dubois", "Mathis Simon", "Nolan Michel", "Tom Leroy", "Yanis Roux")),
    Seleccion("Alemania", "GER", (232, 232, 222), (53, 58, 65), ((32, 32, 34), (219, 55, 51), (231, 195, 52)),
              ("Felix Weber", "Lukas Fischer", "Jonas Becker", "Paul Hoffmann", "Ben Schneider", "Leon Wagner", "Noah Meyer", "Elias Schulz", "Finn Koch", "Max Braun", "Theo Richter")),
    Seleccion("Inglaterra", "ENG", (238, 239, 233), (50, 75, 135), ((238, 238, 232), (203, 50, 53), (238, 238, 232)),
              ("Oliver Smith", "Harry Jones", "Jack Taylor", "Charlie Brown", "George Wilson", "Leo Davies", "Alfie Evans", "Theo Thomas", "Freddie Moore", "Oscar Hall", "Arthur Clarke")),
    Seleccion("México", "MEX", (43, 139, 90), (239, 239, 227), ((36, 123, 75), (238, 238, 229), (201, 54, 53)),
              ("Santiago Flores", "Emiliano Cruz", "Diego Herrera", "Sebastián Reyes", "Gael Navarro", "Leonardo Vega", "Matías Aguilar", "Iker Castillo", "Alexis Mendoza", "Bruno Campos", "Joaquín Fuentes")),
    Seleccion("Uruguay", "URU", (88, 169, 215), (241, 241, 230), ((242, 242, 234), (92, 167, 207), (242, 242, 234)),
              ("Martín Silva", "Facundo Pérez", "Nicolás Castro", "Thiago Ramos", "Agustín Suárez", "Franco Méndez", "Luca Pereira", "Mateo Cabrera", "Bruno Núñez", "Valentín Díaz", "Santino Olivera")),
    Seleccion("Japón", "JPN", (239, 239, 231), (53, 79, 143), ((240, 240, 235), (204, 51, 58), (240, 240, 235)),
              ("Haruto Sato", "Ren Suzuki", "Yuto Takahashi", "Sota Tanaka", "Kaito Watanabe", "Riku Ito", "Minato Nakamura", "Aoi Kobayashi", "Yuma Kato", "Itsuki Yoshida", "Hinata Yamada")),
    Seleccion("Portugal", "POR", (41, 128, 77), (208, 53, 52), ((30, 117, 69), (207, 49, 51), (207, 49, 51)),
              ("Tiago Silva", "Gonçalo Costa", "Rafael Santos", "Diogo Pereira", "Afonso Ferreira", "João Oliveira", "Martim Rodrigues", "Francisco Martins", "Duarte Sousa", "Tomás Lopes", "Miguel Gomes")),
)

# (avance desde el arco propio, carril lateral); índice 0 es arquero.
FORMACION_433 = (
    (.055, 0.0),
    (.205, -.73), (.225, -.25), (.225, .25), (.205, .73),
    (.405, -.52), (.435, 0.0), (.405, .52),
    (.685, -.68), (.735, 0.0), (.685, .68),
)


def obtener_seleccion(indice: int) -> Seleccion:
    return SELECCIONES[indice % len(SELECCIONES)]


def formacion(equipo: int, indice: int, x_min: float, x_max: float,
              y_centro: float, y_radio: float) -> tuple[float, float]:
    """Convierte la formación 4-3-3 a coordenadas; ambos atacan hacia el centro rival."""
    avance, carril = FORMACION_433[indice % 11]
    x = x_min + avance * (x_max - x_min) if equipo == 0 else x_max - avance * (x_max - x_min)
    return x, y_centro + carril * y_radio


def color_equipo(indice_pais: int, equipo: int = 0) -> tuple[int, int, int]:
    seleccion = obtener_seleccion(indice_pais)
    return seleccion.camiseta if equipo == 0 else seleccion.detalle
