"""Fútbol 2D de estilo broadcast: partido local, cooperativo e IA."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass

import pygame

from ia_futbol import IAFutbol, MODOS, clamp
from selecciones import SELECCIONES, color_equipo, formacion, obtener_seleccion
from audio_futbol import AudioFutbol
from recursos_visuales_2d import ASSET_STYLE, RecursosVisuales


ANCHO, ALTO = 1280, 720
FPS = 60
CAMPO = pygame.Rect(70, 130, 1140, 490)
VERDE_1 = (26, 111, 68)
VERDE_2 = (31, 124, 74)
BLANCO = (239, 246, 241)
AZUL = (33, 139, 255)
ROJO = (247, 74, 83)
AMARILLO = (255, 206, 76)
FONDO = (8, 17, 29)


def limitar_posicion(x: float, y: float) -> tuple[float, float]:
    return (clamp(x, CAMPO.left + 22, CAMPO.right - 22),
            clamp(y, CAMPO.top + 22, CAMPO.bottom - 22))


@dataclass
class Jugador:
    equipo: int
    indice: int
    control: str
    nombre: str
    x: float
    y: float
    casa: tuple[float, float]
    objetivo: tuple[float, float]
    angulo: float = 0.0
    energia: float = 1.0
    recarga_robo: float = 0.0


class Futbol2D:
    """Partido 2D con controles locales, IA táctica y registro CSV."""

    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption("PITCH / Fútbol 2D con IA")
        self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        self.recursos_visual = RecursosVisuales()
        self.reloj = pygame.time.Clock()
        self.fuentes = {
            "mini": pygame.font.SysFont("segoeui", 14),
            "normal": pygame.font.SysFont("segoeui", 18),
            "bold": pygame.font.SysFont("segoeui", 22, bold=True),
            "titulo": pygame.font.SysFont("segoeui", 48, bold=True),
            "numero": pygame.font.SysFont("segoeui", 18, bold=True),
        }
        self.estado = "menu"
        self.modo = 1
        self.ia: IAFutbol | None = None
        self.jugadores: list[Jugador] = []
        self.balon = pygame.Vector2(CAMPO.center)
        self.vel_balon = pygame.Vector2()
        self.poseedor: Jugador | None = None
        self.altura = 0.0
        self.vel_altura = 0.0
        self.tiempo = 0.0
        self.reloj_partido = 150.0
        self.temporizador_ia = 0.0
        self.pausa = False
        self.fin = False
        self.mensaje = ""
        self.mensaje_tiempo = 0.0
        self.numero_jugadas = 0
        self.pais_indices = [0, 1]
        self.audio = AudioFutbol()
        self.ultimo_golpeador: Jugador | None = None
        self._poseedor_control_anterior: Jugador | None = None
        self.botones_overlay: dict[str, pygame.Rect] = {}
        self.ejecutando = True
        self._iniciar_fuentes()

    def _iniciar_fuentes(self) -> None:
        # Mantiene un juego legible al cambiar el tamaño de la ventana.
        self.fuentes["mini"] = pygame.font.SysFont("segoeui", 14)

    def iniciar_partido(self, modo: int) -> None:
        self.modo = modo
        if self.ia is None:
            self.ia = IAFutbol()
        elif not self.ia.log.done:
            self.ia.log.finish()
        paises = tuple(obtener_seleccion(i).nombre for i in self.pais_indices)
        self.ia.log.start(modo, paises)
        self.jugadores = []
        for equipo in (0, 1):
            seleccion = obtener_seleccion(self.pais_indices[equipo])
            for indice in range(11):
                control = "IA"
                if modo == 1 and equipo == 0 and indice == 10:
                    control = "H1"
                elif modo == 2 and indice == 10:
                    control = "H1" if equipo == 0 else "H2"
                elif modo in (3, 4) and equipo == 1 and indice in (9, 10):
                    control = "H2" if indice == 9 else "H1"
                x, y = formacion(equipo, indice, CAMPO.left + 30, CAMPO.right - 30,
                                 CAMPO.centery, CAMPO.height * .40)
                casa = (x, y)
                self.jugadores.append(Jugador(equipo, indice, control,
                                              seleccion.once[indice], x, y, casa, casa,
                                              angulo=0.0 if equipo == 0 else math.pi))
        self._iniciar_saque(0)
        self.tiempo = self.temporizador_ia = 0.0
        self.reloj_partido = 150.0
        self.pausa = self.fin = False
        self.estado = "partido"
        self._poseedor_control_anterior = None
        self.mensaje = "¡Que ruede el balón!"
        self.mensaje_tiempo = 2.2
        self.audio.efecto("silbato")

    def _iniciar_saque(self, equipo: int) -> None:
        """Reubica los equipos y entrega el saque al equipo que debe iniciar."""
        signo = 1 if equipo == 0 else -1
        for jugador in self.jugadores:
            jugador.x, jugador.y = jugador.casa
            jugador.objetivo = jugador.casa
            jugador.angulo = 0.0 if jugador.equipo == 0 else math.pi
            jugador.recarga_robo = 0.0

        sacador = max((p for p in self.jugadores if p.equipo == equipo
                       and p.indice >= 9), key=lambda p: p.indice, default=None)
        if sacador is not None:
            sacador.x = CAMPO.centerx - signo * 19
            sacador.y = CAMPO.centery
            sacador.objetivo = (sacador.x, sacador.y)
            sacador.angulo = 0.0 if equipo == 0 else math.pi
            sacador.recarga_robo = .8
        self.poseedor = sacador
        self.balon.update(CAMPO.center)
        self.vel_balon.update(0, 0)
        self.altura = self.vel_altura = 0.0
        self.ultimo_golpeador = None
        self._poseedor_control_anterior = None

    def volver_al_menu(self) -> None:
        if self.ia and not self.ia.log.done:
            self.ia.log.finish()
        self.estado = "menu"

    def bucle(self) -> None:
        try:
            while self.ejecutando:
                # tick limita la velocidad a 60 FPS y espera el siguiente frame.
                dt = min(self.reloj.tick(FPS) / 1000.0, .035)
                self._eventos()
                if self.estado == "partido" and not self.pausa and not self.fin:
                    self.actualizar(dt)
                self.dibujar()
                pygame.display.flip()
        except KeyboardInterrupt:
            # Ctrl+C o el botón Stop del IDE cierran el juego sin traceback.
            self.ejecutando = False
        finally:
            self.audio.cerrar()
            pygame.quit()

    def _eventos(self) -> None:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                self.ejecutando = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE:
                    if self.estado == "partido":
                        if self.pausa or self.fin:
                            self.volver_al_menu()
                        else:
                            self.pausa = True
                    else:
                        self.ejecutando = False
                elif self.estado == "menu" and pygame.K_1 <= evento.key <= pygame.K_4:
                    self.iniciar_partido(evento.key - pygame.K_0)
                elif self.estado == "menu" and evento.key in (pygame.K_a, pygame.K_d,
                                                               pygame.K_LEFT, pygame.K_RIGHT):
                    equipo = 0 if evento.key in (pygame.K_a, pygame.K_d) else 1
                    paso = 1 if evento.key in (pygame.K_d, pygame.K_RIGHT) else -1
                    self.pais_indices[equipo] = (self.pais_indices[equipo] + paso) % len(SELECCIONES)
                elif self.estado == "menu" and evento.key == pygame.K_r:
                    equipo_ia = 1 if self.modo in (1, 2) else 0
                    opciones = [i for i in range(len(SELECCIONES))
                                if i != self.pais_indices[1 - equipo_ia]]
                    self.pais_indices[equipo_ia] = random.choice(opciones)
                elif self.estado == "partido":
                    if evento.key == pygame.K_p and not self.fin:
                        self.pausa = not self.pausa
                    elif evento.key == pygame.K_r:
                        self.iniciar_partido(self.modo)
                    elif evento.key in (pygame.K_SPACE, pygame.K_q, pygame.K_e,
                                        pygame.K_RCTRL, pygame.K_RETURN, pygame.K_u) and not self.pausa and not self.fin:
                        self._accion_humana(evento.key)
                    elif evento.key in (pygame.K_f, pygame.K_RALT) and not self.pausa and not self.fin:
                        self._robar("H1" if evento.key == pygame.K_f else "H2")
                    elif evento.key == pygame.K_TAB and not self.pausa and not self.fin:
                        self._cambiar_jugador("H1")
                    elif evento.key == pygame.K_BACKSPACE and not self.pausa and not self.fin:
                        self._cambiar_jugador("H2")
            elif (evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1
                  and self.estado == "partido" and (self.pausa or self.fin)):
                for accion, rect in self.botones_overlay.items():
                    if rect.collidepoint(evento.pos):
                        if accion == "continuar":
                            self.pausa = False
                        elif accion in ("reiniciar", "jugar_de_nuevo"):
                            self.iniciar_partido(self.modo)
                        elif accion == "menu":
                            self.volver_al_menu()
                        elif accion == "salir":
                            self.ejecutando = False
                        break

    def _jugador_humano(self, control: str) -> Jugador | None:
        return next((p for p in self.jugadores if p.control == control), None)

    def _cambiar_jugador(self, control: str, objetivo: Jugador | None = None) -> None:
        """Transfiere el control humano y deja a la IA manejando al jugador anterior."""
        activo = self._jugador_humano(control)
        if activo is None:
            return
        if objetivo is activo:
            return
        ocupados = {p.indice for p in self.jugadores
                    if p.equipo == activo.equipo and p is not activo
                    and p.control in ("H1", "H2")}
        candidatos = [p for p in self.jugadores if p.equipo == activo.equipo
                      and p is not activo and p.indice not in ocupados]
        if not candidatos:
            return
        coincide = next((p for p in candidatos if p is objetivo), None)
        if coincide is not None:
            nuevo = coincide
        else:
            por_indice = sorted(candidatos, key=lambda p: p.indice)
            siguiente = next((p for p in por_indice if p.indice > activo.indice), por_indice[0])
            nuevo = siguiente
        activo.control = "IA"
        nuevo.control = control
        self.mensaje = f"CONTROL · {nuevo.nombre} · {nuevo.indice + 1}"
        self.mensaje_tiempo = 1.0

    def _sincronizar_controles(self) -> None:
        """Cambia al receptor del pase o al defensor más cercano al recuperar/perder el balón."""
        if self.poseedor is self._poseedor_control_anterior:
            return
        self._poseedor_control_anterior = self.poseedor
        controles = [c for c in ("H1", "H2") if self._jugador_humano(c)]
        controles.sort()
        control_del_portador = None
        if self.poseedor is not None:
            portadores_humanos = [(c, self._jugador_humano(c)) for c in controles]
            portadores_humanos = [(c, p) for c, p in portadores_humanos
                                  if p is not None and p.equipo == self.poseedor.equipo]
            if portadores_humanos:
                # En cooperativo, solo una persona cambia al jugador que recibió el balón.
                # La otra conserva su jugador y puede desmarcarse o apoyar la jugada.
                control_del_portador, _ = min(
                    portadores_humanos,
                    key=lambda par: math.dist((par[1].x, par[1].y),
                                              (self.poseedor.x, self.poseedor.y)))
                self._cambiar_jugador(control_del_portador, self.poseedor)
        for control in controles:
            activo = self._jugador_humano(control)
            if activo is None or control == control_del_portador:
                continue
            if self.poseedor is not None and self.poseedor.equipo == activo.equipo:
                # El segundo usuario mantiene su jugador controlable independiente.
                continue
            if activo.indice == 0:
                # Si el usuario tomó al arquero, lo conserva mientras defiende.
                continue
            ya_controlados = {p.indice for p in self.jugadores
                              if p.equipo == activo.equipo and p.control in ("H1", "H2")
                              and p is not activo}
            opciones = [p for p in self.jugadores if p.equipo == activo.equipo
                        and p.indice != 0 and p is not activo
                        and p.indice not in ya_controlados]
            mas_cercano = min(opciones, key=lambda p: math.dist((p.x, p.y), self.balon),
                              default=None)
            if mas_cercano:
                self._cambiar_jugador(control, mas_cercano)

    def _accion_humana(self, tecla: int) -> None:
        control = "H1" if tecla in (pygame.K_SPACE, pygame.K_q, pygame.K_e) else "H2"
        p = self._jugador_humano(control)
        if not p:
            return
        accion = ("pase" if tecla in (pygame.K_q, pygame.K_RETURN) else
                  "centro" if tecla in (pygame.K_e, pygame.K_u) else "tiro")
        compañero = self._mejor_companero(p, solo_ataque=accion == "centro")
        self._patear(p, accion, compañero)

    def _mejor_companero(self, jugador: Jugador, solo_ataque: bool = False) -> Jugador | None:
        """Prefiere una línea de pase hacia delante y alejada de los defensores."""
        signo = 1 if jugador.equipo == 0 else -1
        candidatos = [q for q in self.jugadores if q.equipo == jugador.equipo and q is not jugador
                      and q.indice != 0]
        if solo_ataque:
            candidatos = [q for q in candidatos if signo * (q.x - jugador.x) > 0]
        rivales = [q for q in self.jugadores if q.equipo != jugador.equipo]
        def puntuacion(q: Jugador) -> float:
            avance = signo * (q.x - jugador.x)
            distancia = math.dist((q.x, q.y), (jugador.x, jugador.y))
            espacio = min((math.dist((q.x, q.y), (r.x, r.y)) for r in rivales), default=180)
            return avance * .52 - distancia * .14 + min(150, espacio) * .28
        return max(candidatos, key=puntuacion, default=None)

    def _robar(self, control: str) -> None:
        """Permite presionar al rival o reclamar un balón dividido."""
        p = self._jugador_humano(control)
        if p is None:
            return
        objetivo = self.poseedor
        distancia = math.dist((p.x, p.y),
                              (objetivo.x, objetivo.y) if objetivo else self.balon)
        if objetivo is not None and objetivo.equipo != p.equipo and distancia < 48:
            self.poseedor = p
            p.recarga_robo = .65
            self.vel_balon.update(0, 0)
            self.mensaje, self.mensaje_tiempo = "¡RECUPERACIÓN!", 1.0
        elif objetivo is None and distancia < 44:
            self.poseedor = p
            self.vel_balon.update(0, 0)

    def actualizar(self, dt: float) -> None:
        assert self.ia is not None
        self.tiempo += dt
        self.reloj_partido = max(0, self.reloj_partido - dt)
        self.mensaje_tiempo = max(0, self.mensaje_tiempo - dt)
        teclas = pygame.key.get_pressed()
        for jugador in self.jugadores:
            if jugador.control == "IA":
                continue
            if jugador.control == "H1":
                dx = float(teclas[pygame.K_d]) - float(teclas[pygame.K_a])
                dy = float(teclas[pygame.K_s]) - float(teclas[pygame.K_w])
                sprint = teclas[pygame.K_LSHIFT]
            else:
                dx = float(teclas[pygame.K_RIGHT]) - float(teclas[pygame.K_LEFT])
                dy = float(teclas[pygame.K_DOWN]) - float(teclas[pygame.K_UP])
                sprint = teclas[pygame.K_RSHIFT]
            magnitud = math.hypot(dx, dy)
            if magnitud:
                velocidad = 300 if sprint and jugador.energia > .08 else 228
                if self.poseedor is jugador:
                    velocidad *= .90  # El control del balón reduce un poco la velocidad.
                dx, dy = dx / magnitud, dy / magnitud
                jugador.x, jugador.y = limitar_posicion(jugador.x + dx * velocidad * dt,
                                                          jugador.y + dy * velocidad * dt)
                jugador.angulo = math.atan2(dy, dx)
                jugador.energia = max(0, jugador.energia - dt * (.24 if sprint else .08))
            else:
                jugador.energia = min(1, jugador.energia + dt * .16)

        for jugador in self.jugadores:
            jugador.recarga_robo = max(0.0, jugador.recarga_robo - dt)
        self._actualizar_ia(dt)
        self._actualizar_posesion(dt)
        self._sincronizar_controles()
        if self.poseedor is not None:
            pais = obtener_seleccion(self.pais_indices[self.poseedor.equipo]).nombre
            self.audio.posesion(self.poseedor.nombre, pais, self.tiempo)
        self._actualizar_balon(dt)
        if self.reloj_partido <= 0:
            self.fin = True
            self.ia.log.finish()
            self.mensaje = "Final del partido · R para revancha"

    def _actualizar_ia(self, dt: float) -> None:
        assert self.ia is not None
        self.temporizador_ia -= dt
        if self.temporizador_ia <= 0:
            self.temporizador_ia = .22
            por_equipo = {t: [p for p in self.jugadores if p.equipo == t and p.control == "IA"]
                          for t in (0, 1)}
            for equipo, miembros in por_equipo.items():
                if not miembros:
                    continue
                signo = 1 if equipo == 0 else -1
                aliados = [p for p in self.jugadores if p.equipo == equipo]
                portador = self.poseedor
                rivales = [p for p in self.jugadores if p.equipo != equipo]
                cazador = min(miembros, key=lambda p: math.dist((p.x, p.y), self.balon))
                pelota = ((self.balon.x - CAMPO.centerx) / (CAMPO.width / 2),
                          (self.balon.y - CAMPO.centery) / (CAMPO.height / 2), self.altura / 90)
                actor = ((cazador.x - CAMPO.centerx) / (CAMPO.width / 2),
                         (cazador.y - CAMPO.centery) / (CAMPO.height / 2))
                mate_p = self._mejor_companero(cazador)
                mate = ((mate_p.x - CAMPO.centerx) / (CAMPO.width / 2),
                        (mate_p.y - CAMPO.centery) / (CAMPO.height / 2)) if mate_p else None
                accion, prediccion = self.ia.decide(pelota, actor, mate, signo)

                for p in miembros:
                    es_portador = portador is p
                    if p.indice == 0:
                        x_meta = CAMPO.left + 28 if equipo == 0 else CAMPO.right - 28
                        y_meta = CAMPO.centery + (self.balon.y - CAMPO.centery) * .22
                        p.objetivo = limitar_posicion(x_meta, y_meta)
                    elif es_portador:
                        meta_x = CAMPO.right - 34 if equipo == 0 else CAMPO.left + 34
                        presion = min((math.dist((p.x, p.y), (r.x, r.y)) for r in rivales), default=999)
                        p.angulo = math.atan2(CAMPO.centery - p.y, signo)
                        distancia_balon = math.dist((p.x, p.y), self.balon)
                        companion = self._mejor_companero(p)
                        distancia_meta = abs(meta_x - p.x)
                        if distancia_balon < 54 and distancia_meta < 255:
                            self._patear(p, "tiro", companion)
                        elif (distancia_balon < 54 and companion and
                              ((presion < 58 and accion == "pase") or
                               (distancia_meta < 390 and abs(p.y - CAMPO.centery) > 120
                                and signo * (p.x - CAMPO.centerx) > 120))):
                            tipo = ("centro" if abs(p.y - CAMPO.centery) > 120 and
                                    signo * (p.x - CAMPO.centerx) > 120 else "pase")
                            self._patear(p, tipo, self._mejor_companero(
                                p, solo_ataque=tipo == "centro"))
                        else:
                            p.objetivo = limitar_posicion(p.x + signo * 105,
                                                          p.y + (CAMPO.centery - p.y) * .12)
                    elif portador and portador.equipo != equipo:
                        if p is min(miembros, key=lambda q: math.dist((q.x, q.y),
                                                                     (portador.x, portador.y))):
                            p.objetivo = (portador.x, portador.y)
                        else:
                            apoyo_x = p.casa[0] + (self.balon.x - CAMPO.centerx) * .12
                            p.objetivo = limitar_posicion(apoyo_x,
                                                          p.casa[1] + (self.balon.y - p.casa[1]) * .18)
                    elif portador is None and p is cazador:
                        p.objetivo = (self.balon.x, self.balon.y)
                        if accion == "perseguir":
                            p.objetivo = limitar_posicion(CAMPO.centerx + prediccion[0] * CAMPO.width / 2,
                                                          CAMPO.centery + prediccion[1] * CAMPO.height / 2)
                    else:
                        avance = 62 if portador and portador.equipo == equipo else -28
                        p.objetivo = limitar_posicion(
                            p.casa[0] + signo * avance + (self.balon.x - CAMPO.centerx) * .12,
                            p.casa[1] + (self.balon.y - p.casa[1]) * .18)

        for p in self.jugadores:
            if p.control == "IA":
                self._mover_ia(p, dt)

    def _actualizar_posesion(self, dt: float) -> None:
        """Conducción, control de balones divididos y presión de la defensa IA."""
        if self.poseedor is not None:
            portador = self.poseedor
            self.balon.update(portador.x + math.cos(portador.angulo) * 19,
                              portador.y + math.sin(portador.angulo) * 19)
            self.altura = 0.0
            self.vel_balon.update(0, 0)
            rivales_ia = [p for p in self.jugadores
                          if p.control == "IA" and p.equipo != portador.equipo]
            for defensor in rivales_ia:
                if math.dist((defensor.x, defensor.y), (portador.x, portador.y)) < 23:
                    if defensor.recarga_robo <= 0 and portador.recarga_robo <= 0:
                        self.poseedor = defensor
                        defensor.recarga_robo = .8
                    break
            if self.poseedor is not None:
                return

        # La pelota se puede recuperar al llegar a ella; los pases en movimiento
        # siguen siendo interceptables si un jugador cruza su trayectoria.
        velocidad = self.vel_balon.length()
        receptor = min(self.jugadores,
                       key=lambda p: math.dist((p.x, p.y), self.balon), default=None)
        if receptor and math.dist((receptor.x, receptor.y), self.balon) < (22 if velocidad < 190 else 15):
            if self.altura < 24:
                self.poseedor = receptor
                self.vel_balon.update(0, 0)


    def _mover_ia(self, p: Jugador, dt: float) -> None:
        dx, dy = p.objetivo[0] - p.x, p.objetivo[1] - p.y
        distancia = math.hypot(dx, dy)
        if distancia > 3:
            velocidad = min(170, distancia * 3.2)
            p.x, p.y = limitar_posicion(p.x + dx / distancia * velocidad * dt,
                                         p.y + dy / distancia * velocidad * dt)
            p.angulo = math.atan2(dy, dx)

    def _patear(self, p: Jugador, accion: str, compañero: Jugador | None) -> None:
        if math.dist((p.x, p.y), self.balon) > 54:
            return
        if self.poseedor is not None and self.poseedor.equipo != p.equipo:
            return
        if accion == "pase" and compañero is None:
            return
        signo = 1 if p.equipo == 0 else -1
        if accion == "pase" and compañero:
            # Pase raso hacia el espacio al que corre el compañero.
            destino = pygame.Vector2(compañero.x + math.cos(compañero.angulo) * 34,
                                     compañero.y + math.sin(compañero.angulo) * 34)
            velocidad = 405
        elif accion == "centro":
            # Centro aéreo al área: busca un atacante y lo guía unos metros.
            meta_x = CAMPO.right - 150 if p.equipo == 0 else CAMPO.left + 150
            meta_y = compañero.y if compañero else CAMPO.centery
            destino = pygame.Vector2(meta_x, meta_y)
            velocidad = 440
            self.vel_altura = 205
        elif accion == "pase":
            # En un 1 contra 1, el pase se juega al espacio para avanzar la pelota.
            direccion = pygame.Vector2(math.cos(p.angulo), math.sin(p.angulo))
            destino = self.balon + direccion * 390
            velocidad = 390
        else:
            teclas = pygame.key.get_pressed()
            if p.control == "H1":
                dx = float(teclas[pygame.K_d]) - float(teclas[pygame.K_a])
                dy = float(teclas[pygame.K_s]) - float(teclas[pygame.K_w])
            elif p.control == "H2":
                dx = float(teclas[pygame.K_RIGHT]) - float(teclas[pygame.K_LEFT])
                dy = float(teclas[pygame.K_DOWN]) - float(teclas[pygame.K_UP])
            else:
                dx = dy = 0.0
            if math.hypot(dx, dy) > 0:
                p.angulo = math.atan2(dy, dx)
            elif p.control == "IA":
                p.angulo = 0.0 if signo == 1 else math.pi
            direccion = pygame.Vector2(math.cos(p.angulo), math.sin(p.angulo))
            destino = self.balon + direccion * 620
            velocidad = 570
            self.vel_altura = 155
        vector = destino - self.balon
        if vector.length_squared() == 0:
            vector.update(signo, 0)
        self.vel_balon = vector.normalize() * velocidad
        self.poseedor = None
        self.ultimo_golpeador = p
        self.audio.efecto("balon")
        self.audio.jugada(p.nombre, accion)
        self.ia.log.action(p.equipo, p.nombre, accion, self.tiempo)  # type: ignore[union-attr]
        self.numero_jugadas += 1

    def _actualizar_balon(self, dt: float) -> None:
        assert self.ia is not None
        if self.poseedor is not None:
            return
        self.vel_balon *= max(0, 1 - .62 * dt)
        self.balon += self.vel_balon * dt
        self.vel_altura -= 480 * dt
        self.altura = max(0, self.altura + self.vel_altura * dt)
        if self.altura == 0:
            self.vel_altura = max(0, -self.vel_altura * .43)
        if self.balon.y < CAMPO.top + 8 or self.balon.y > CAMPO.bottom - 8:
            self.balon.y = clamp(self.balon.y, CAMPO.top + 8, CAMPO.bottom - 8)
            self.vel_balon.y *= -.68
        if self.balon.x < CAMPO.left - 18 or self.balon.x > CAMPO.right + 18:
            if abs(self.balon.y - CAMPO.centery) < 72:
                equipo = 0 if self.balon.x > CAMPO.centerx else 1
                goleador = self.ultimo_golpeador
                self.ia.log.goal(equipo, goleador.nombre if goleador else "Equipo", self.tiempo)
                pais = obtener_seleccion(self.pais_indices[equipo]).nombre
                self.mensaje = f"¡GOOOL! · {pais} · {goleador.nombre if goleador else 'Equipo'}"
                self.mensaje_tiempo = 2.0
                self.audio.gol(goleador.nombre if goleador else "el equipo", pais)
                self.numero_jugadas += 1
                equipo_saque = 1 - equipo
                self._iniciar_saque(equipo_saque)
                self.mensaje += " · SAQUE " + ("AZUL" if equipo_saque == 0 else "ROJO")
                if max(self.ia.log.score.values()) >= 5:
                    self.fin = True
                    self.ia.log.finish()
            else:
                self.balon.x = clamp(self.balon.x, CAMPO.left - 18, CAMPO.right + 18)
                self.vel_balon.x *= -.68

    # ------------------------------- Dibujo ---------------------------------
    def dibujar(self) -> None:
        w, h = self.pantalla.get_size()
        self.pantalla.fill(FONDO)
        if self.estado == "menu":
            self._dibujar_menu(w, h)
            return
        self._dibujar_partido(w, h)

    def _texto(self, superficie: pygame.Surface, texto: str, xy: tuple[int, int],
               fuente: str = "normal", color: tuple[int, int, int] = BLANCO,
               centro: bool = False) -> pygame.Rect:
        imagen = self.fuentes[fuente].render(texto, True, color)
        rect = imagen.get_rect()
        if centro:
            rect.center = xy
        else:
            rect.topleft = xy
        superficie.blit(imagen, rect)
        return rect

    def _dibujar_menu(self, w: int, h: int) -> None:
        # Cabecera editorial, luces ambientales y panel de selección.
        pygame.draw.rect(self.pantalla, (12, 28, 45), (0, 0, w, h))
        pygame.draw.circle(self.pantalla, (18, 61, 72), (w - 60, 90), 230)
        pygame.draw.circle(self.pantalla, (19, 39, 65), (30, h - 20), 250)
        self._texto(self.pantalla, "PITCH / LAB", (90, 58), "bold", AMARILLO)
        self._texto(self.pantalla, "FÚTBOL 2D", (86, 102), "titulo")
        self._texto(self.pantalla, "Partido local · IA táctica · Estadísticas en vivo",
                    (92, 166), "normal", (167, 190, 204))
        panel = pygame.Rect(82, 204, min(w - 164, 720), 390)
        pygame.draw.rect(self.pantalla, (15, 29, 45), panel, border_radius=20)
        pygame.draw.rect(self.pantalla, (42, 66, 83), panel, 1, border_radius=20)
        self._texto(self.pantalla, "ELIGE TU PARTIDO", (panel.x + 28, panel.y + 22), "bold")
        descripciones = [
            ("UN JUGADOR", "Tú contra el equipo controlado por IA", AZUL),
            ("LOCAL", "Dos personas · un teclado", (118, 207, 166)),
            ("COOPERATIVO", "Una IA contra dos jugadores", AMARILLO),
            ("2 × 2", "Dos IA contra dos jugadores locales", ROJO),
        ]
        for i, (titulo, detalle, acento) in enumerate(descripciones):
            y = panel.y + 62 + i * 70
            tarjeta = pygame.Rect(panel.x + 22, y, panel.width - 44, 64)
            pygame.draw.rect(self.pantalla, (23, 43, 60), tarjeta, border_radius=12)
            pygame.draw.rect(self.pantalla, acento, (tarjeta.x, tarjeta.y, 5, tarjeta.height), border_radius=3)
            self._texto(self.pantalla, str(i + 1), (tarjeta.x + 22, tarjeta.y + 17), "bold", acento)
            self._texto(self.pantalla, titulo, (tarjeta.x + 66, tarjeta.y + 9), "bold")
            self._texto(self.pantalla, detalle, (tarjeta.x + 66, tarjeta.y + 36), "mini", (171, 191, 204))
            self._texto(self.pantalla, "PULSA " + str(i + 1), (tarjeta.right - 106, tarjeta.y + 24), "mini", acento)
        # Selector local de selecciones. A/D cambia el equipo azul; ←/→ el rojo.
        selector = pygame.Rect(832, 204, min(356, w - 862), 304)
        pygame.draw.rect(self.pantalla, (13, 29, 44), selector, border_radius=18)
        pygame.draw.rect(self.pantalla, (42, 66, 83), selector, 1, border_radius=18)
        self._texto(self.pantalla, "SELECCIONES NACIONALES", (selector.x + 20, selector.y + 19), "bold")
        for equipo in (0, 1):
            sel = obtener_seleccion(self.pais_indices[equipo])
            y = selector.y + 65 + equipo * 98
            tarjeta = pygame.Rect(selector.x + 14, y, selector.width - 28, 82)
            pygame.draw.rect(self.pantalla, (22, 43, 59), tarjeta, border_radius=12)
            self._texto(self.pantalla, "LOCAL" if equipo == 0 else "VISITANTE · IA / J2",
                        (tarjeta.x + 14, tarjeta.y + 8), "mini", (147, 172, 188))
            bandera = pygame.Rect(tarjeta.x + 15, tarjeta.y + 32, 50, 30)
            alto_franja = bandera.height // 3
            for franja, tono in enumerate(sel.bandera):
                pygame.draw.rect(self.pantalla, tono,
                                 (bandera.x, bandera.y + franja * alto_franja,
                                  bandera.width, alto_franja + 1))
            pygame.draw.rect(self.pantalla, (224, 234, 233), bandera, 1)
            self._texto(self.pantalla, f"{sel.nombre}  ·  {sel.sigla}",
                        (tarjeta.x + 78, tarjeta.y + 39), "bold", sel.camiseta)
        self._texto(self.pantalla, "11 TITULARES  ·  FORMACIÓN 4-3-3",
                    (selector.x + 20, selector.bottom + 19), "mini", AMARILLO)
        self._texto(self.pantalla, "A / D azul       ← / → rojo       R sortear selección de la IA",
                    (selector.x + 20, selector.bottom + 43), "mini", (171, 191, 204))
        self._texto(self.pantalla, "Centro: E (J1) / U (J2)  ·  audio y narración local",
                    (selector.x + 20, selector.bottom + 65), "mini", (145, 174, 188))
        previa = pygame.Rect(w - 285, 68, 245, 122)
        pygame.draw.rect(self.pantalla, (10, 23, 36), previa.inflate(10, 10), border_radius=10)
        pygame.draw.rect(self.pantalla, (80, 113, 128), previa.inflate(10, 10), 1, border_radius=10)
        if not self.recursos_visual.dibujar_vista_previa_cancha(self.pantalla, previa):
            pygame.draw.rect(self.pantalla, (30, 105, 62), previa, border_radius=3)
            pygame.draw.rect(self.pantalla, BLANCO, previa, 2)
            pygame.draw.line(self.pantalla, BLANCO, previa.midtop, previa.midbottom, 1)
            pygame.draw.circle(self.pantalla, BLANCO, previa.center, 18, 1)
        self._texto(self.pantalla, f"VISTA TÁCTICA · {ASSET_STYLE.upper()}",
                    (previa.centerx, previa.y - 10), "mini", AMARILLO, True)
        self.recursos_visual.dibujar_hinchas(self.pantalla, pygame.Rect(w - 445, 112, 140, 27))
        self._texto(self.pantalla, "J1 WASD · tiro ESPACIO · pase Q · centro E · robo F · cambio TAB · sprint SHIFT",
                    (92, h - 100), "normal", (192, 210, 219))
        self._texto(self.pantalla, "J2 FLECHAS · tiro CTRL DER. · pase ENTER · centro U · robo ALT · cambio BACKSPACE",
                    (92, h - 70), "mini", (146, 174, 190))
        self._texto(self.pantalla, "ESC salir", (w - 174, h - 48), "mini", (110, 140, 158))
        if self.recursos_visual.errores:
            self._texto(self.pantalla, "FALLBACK VECTORIAL ACTIVO", (w - 370, h - 22), "mini", AMARILLO)

    def _dibujar_partido(self, w: int, h: int) -> None:
        # Faja superior como marcador de transmisión deportiva.
        pygame.draw.rect(self.pantalla, (9, 20, 34), (0, 0, w, 114))
        pygame.draw.line(self.pantalla, (41, 72, 88), (0, 113), (w, 113), 1)
        self._texto(self.pantalla, "PITCH / LIVE", (34, 22), "bold", AMARILLO)
        posesion = (obtener_seleccion(self.pais_indices[self.poseedor.equipo]).sigla
                    if self.poseedor else "DIVIDIDA")
        nombre_poseedor = f" · {self.poseedor.nombre}" if self.poseedor else ""
        self._texto(self.pantalla, f"{MODOS[self.modo].upper()} · BALÓN {posesion}{nombre_poseedor}",
                    (36, 61), "mini", (155, 180, 195))
        assert self.ia is not None
        marcador = pygame.Rect(w // 2 - 190, 18, 380, 78)
        pygame.draw.rect(self.pantalla, (18, 38, 56), marcador, border_radius=15)
        pygame.draw.circle(self.pantalla, color_equipo(self.pais_indices[0]), (marcador.x + 45, marcador.centery), 8)
        pygame.draw.circle(self.pantalla, color_equipo(self.pais_indices[1]), (marcador.right - 45, marcador.centery), 8)
        self._texto(self.pantalla, obtener_seleccion(self.pais_indices[0]).sigla,
                    (marcador.x + 58, marcador.centery - 10), "mini", BLANCO)
        self._texto(self.pantalla, obtener_seleccion(self.pais_indices[1]).sigla,
                    (marcador.right - 94, marcador.centery - 10), "mini", BLANCO)
        self._texto(self.pantalla, str(self.ia.log.score[0]), (marcador.x + 83, marcador.centery), "titulo", color_equipo(self.pais_indices[0]), True)
        self._texto(self.pantalla, "—", (marcador.centerx, marcador.centery), "bold", (175, 193, 205), True)
        self._texto(self.pantalla, str(self.ia.log.score[1]), (marcador.right - 83, marcador.centery), "titulo", color_equipo(self.pais_indices[1]), True)
        restante = int(self.reloj_partido)
        self._texto(self.pantalla, f"{restante // 60:02}:{restante % 60:02}",
                    (w - 126, 34), "bold", AMARILLO)
        self._texto(self.pantalla, "P  pausa   ·   R  reiniciar   ·   ESC  pausa / menú",
                    (w - 320, 72), "mini", (150, 175, 190))
        self._dibujar_cancha()
        self._dibujar_jugadores()
        self._dibujar_balon()
        self._dibujar_pie(w, h)
        if self.pausa or self.fin:
            self._overlay(w, h, "PAUSA" if self.pausa else "PARTIDO FINALIZADO",
                          "Elige continuar, reiniciar o volver al menú" if self.pausa
                          else "Elige una revancha o vuelve a la selección")

    def _dibujar_cancha(self) -> None:
        # Gradas y césped con franjas; la geometría está calculada en píxeles de pantalla.
        grada = CAMPO.inflate(38, 34)
        pygame.draw.rect(self.pantalla, (24, 38, 49), grada, border_radius=8)
        pygame.draw.rect(self.pantalla, (67, 83, 82), CAMPO, border_radius=3)
        banda = CAMPO.width / 12
        for i in range(12):
            x = round(CAMPO.left + i * banda)
            pygame.draw.rect(self.pantalla, VERDE_1 if i % 2 == 0 else VERDE_2,
                             (x, CAMPO.top, math.ceil(banda), CAMPO.height))
        pygame.draw.rect(self.pantalla, BLANCO, CAMPO, 3)
        pygame.draw.line(self.pantalla, BLANCO, CAMPO.midtop, CAMPO.midbottom, 2)
        pygame.draw.circle(self.pantalla, BLANCO, CAMPO.center, 78, 2)
        pygame.draw.circle(self.pantalla, BLANCO, CAMPO.center, 4)
        area_alto, area_ancho = 214, 300
        for lado in (0, 1):
            x = CAMPO.left if lado == 0 else CAMPO.right - area_alto
            pygame.draw.rect(self.pantalla, BLANCO,
                             (x, CAMPO.centery - area_ancho // 2, area_alto, area_ancho), 2)
            x_chica = CAMPO.left if lado == 0 else CAMPO.right - 78
            pygame.draw.rect(self.pantalla, BLANCO,
                             (x_chica, CAMPO.centery - 116, 78, 232), 2)
            punto_x = CAMPO.left + 144 if lado == 0 else CAMPO.right - 144
            pygame.draw.circle(self.pantalla, BLANCO, (punto_x, CAMPO.centery), 4)
            pygame.draw.arc(self.pantalla, BLANCO,
                            (punto_x - 58, CAMPO.centery - 58, 116, 116),
                            -1.1 if lado else 2.05, 1.1 if lado else 4.23, 2)
            # Arco de esquina y marco con red.
            gx = CAMPO.left - 14 if lado == 0 else CAMPO.right
            gy = CAMPO.centery - 72
            porteria = pygame.Rect(gx, gy, 14, 144)
            pygame.draw.rect(self.pantalla, (221, 233, 234), porteria, 2)
            for yy in range(gy + 8, gy + 144, 12):
                pygame.draw.line(self.pantalla, (122, 159, 160), (gx, yy), (gx + 14, yy), 1)
            for xx in range(gx, gx + 15, 7):
                pygame.draw.line(self.pantalla, (122, 159, 160), (xx, gy), (xx, gy + 144), 1)
        for y, hacia in ((CAMPO.top, 1), (CAMPO.bottom, -1)):
            pygame.draw.arc(self.pantalla, BLANCO,
                            (CAMPO.left - 12, y - 12 if hacia == 1 else y - 12, 24, 24),
                            0 if hacia == 1 else math.pi, math.pi if hacia == 1 else 2 * math.pi, 2)

    def _dibujar_jugadores(self) -> None:
        for p in self.jugadores:
            color_uniforme = color_equipo(self.pais_indices[p.equipo])
            x, y = round(p.x), round(p.y)
            if self.recursos_visual.tiene_jugadores(p.equipo):
                if self.poseedor is p:
                    pygame.draw.circle(self.pantalla, AMARILLO, (x, y), 24, 2)
                elif p.control in ("H1", "H2"):
                    color_control = (111, 222, 255) if p.control == "H1" else (255, 221, 121)
                    pygame.draw.circle(self.pantalla, color_control, (x, y), 22, 2)
                if self.recursos_visual.dibujar_jugador(self.pantalla, p.equipo, p.indice,
                                                        (x, y), p.angulo, color_uniforme):
                    if p.control == "IA":
                        pygame.draw.circle(self.pantalla, (240, 240, 226), (x, y - 25), 2)
                    continue
            # Silueta cenital: botas, piernas, brazos, camiseta y cabeza.
            if self.poseedor is p:
                pygame.draw.circle(self.pantalla, AMARILLO, (x, y), 22, 2)
            elif p.control in ("H1", "H2"):
                color_control = (111, 222, 255) if p.control == "H1" else (255, 221, 121)
                pygame.draw.circle(self.pantalla, color_control, (x, y), 20, 2)
            pygame.draw.ellipse(self.pantalla, (13, 43, 34), (x - 16, y + 11, 34, 11))
            ux, uy = math.cos(p.angulo), math.sin(p.angulo)
            perpendicular = pygame.Vector2(-uy, ux)
            centro = pygame.Vector2(x, y)
            frente = pygame.Vector2(ux, uy)
            hombro = centro + frente * 1
            piel = (194, 145, 111)
            for lado in (-1, 1):
                pierna = centro - frente * 6 + perpendicular * (lado * 5)
                pie = pierna - frente * 8
                pygame.draw.line(self.pantalla, (31, 38, 43), pierna, pie, 5)
                pygame.draw.line(self.pantalla, (235, 239, 232), pie,
                                 pie - frente * 5, 3)
                brazo = hombro + perpendicular * (lado * 8)
                mano = brazo + frente * 2 + perpendicular * (lado * 5)
                pygame.draw.line(self.pantalla, color_uniforme, brazo, mano, 5)
                pygame.draw.circle(self.pantalla, piel, (round(mano.x), round(mano.y)), 2)
            # Pantaloneta bajo la camiseta y torso con forma de hombros.
            pantalon = centro - frente * 7
            pygame.draw.ellipse(self.pantalla, (30, 38, 48),
                                (round(pantalon.x - 8), round(pantalon.y - 5), 16, 12))
            vertices = [centro + frente * 10 - perpendicular * 7,
                        centro + frente * 9 + perpendicular * 7,
                        centro - frente * 7 + perpendicular * 6,
                        centro - frente * 8 - perpendicular * 6]
            puntos = [(round(v.x), round(v.y)) for v in vertices]
            pygame.draw.polygon(self.pantalla, (17, 30, 43), puntos)
            pygame.draw.polygon(self.pantalla, color_uniforme, puntos)
            # Franja de camiseta, cuello y cabeza orientada hacia el ataque.
            pygame.draw.line(self.pantalla, (239, 242, 234), centro - frente * 5,
                             centro + frente * 6, 2)
            cabeza = centro + frente * 13
            pygame.draw.circle(self.pantalla, (85, 59, 48),
                               (round(cabeza.x), round(cabeza.y)), 5)
            pygame.draw.circle(self.pantalla, piel,
                               (round(cabeza.x), round(cabeza.y + 1)), 4)
            numero = str(p.indice + 1)
            img = self.fuentes["numero"].render(numero, True, (255, 255, 255))
            self.pantalla.blit(img, img.get_rect(center=(round(x + ux * 1), round(y + uy * 1))))
            punta = (round(x + ux * 22), round(y + uy * 22))
            pygame.draw.circle(self.pantalla, AMARILLO, punta, 3)
            if p.control == "IA":
                pygame.draw.circle(self.pantalla, (240, 240, 226), (x, y - 21), 2)

    def _dibujar_balon(self) -> None:
        x, y = round(self.balon.x), round(self.balon.y - self.altura * .45)
        radio_sombra = max(4, 9 - round(self.altura * .035))
        pygame.draw.ellipse(self.pantalla, (14, 44, 32),
                            (round(self.balon.x - radio_sombra), round(self.balon.y + 6),
                             radio_sombra * 2, max(4, radio_sombra)))
        if self.recursos_visual.dibujar_balon(self.pantalla, (x, y)):
            return
        pygame.draw.circle(self.pantalla, (251, 251, 238), (x, y), 10)
        pygame.draw.circle(self.pantalla, (35, 42, 50), (x, y), 10, 1)
        for i in range(5):
            ang = i * (2 * math.pi / 5) - math.pi / 2
            px, py = round(x + math.cos(ang) * 4), round(y + math.sin(ang) * 4)
            pygame.draw.circle(self.pantalla, (39, 47, 54), (px, py), 2)

    def _dibujar_pie(self, w: int, h: int) -> None:
        pygame.draw.rect(self.pantalla, (9, 20, 34), (0, h - 82, w, 82))
        pygame.draw.line(self.pantalla, (41, 72, 88), (0, h - 82), (w, h - 82), 1)
        controles = "J1  WASD  ·  ESPACIO tiro  ·  Q pase  ·  E centro  ·  F robo  ·  TAB cambia  ·  SHIFT corre"
        self._texto(self.pantalla, controles, (34, h - 58), "mini", (189, 205, 215))
        self._texto(self.pantalla, "J2 FLECHAS · CTRL DER. tiro · ENTER pase · U centro · ALT robo · BKSP cambia · SHIFT DER. corre",
                    (34, h - 34), "mini", (145, 172, 189))
        self._texto(self.pantalla, f"ACCIONES REGISTRADAS  {self.numero_jugadas:03}",
                    (w - 286, h - 48), "mini", (117, 151, 172))
        if self.recursos_visual.errores:
            self._texto(self.pantalla, "FALLBACK VECTORIAL ACTIVO", (34, h - 14), "mini", AMARILLO)
        if self.mensaje_tiempo > 0 and self.mensaje:
            panel = pygame.Surface((440, 54), pygame.SRCALPHA)
            panel.fill((7, 17, 29, 210))
            self.pantalla.blit(panel, (w // 2 - 220, 124))
            self._texto(self.pantalla, self.mensaje, (w // 2, 151), "bold", AMARILLO, True)

    def _overlay(self, w: int, h: int, titulo: str, subtitulo: str) -> None:
        self.botones_overlay.clear()
        capa = pygame.Surface((w, h), pygame.SRCALPHA)
        capa.fill((3, 10, 18, 188))
        self.pantalla.blit(capa, (0, 0))
        caja = pygame.Rect(w // 2 - 270, h // 2 - 166, 540, 332)
        pygame.draw.rect(self.pantalla, (12, 28, 44), caja, border_radius=20)
        pygame.draw.rect(self.pantalla, (74, 104, 120), caja, 1, border_radius=20)
        self._texto(self.pantalla, titulo, (w // 2, h // 2 - 126), "titulo", AMARILLO, True)
        self._texto(self.pantalla, subtitulo, (w // 2, h // 2 - 83), "normal", BLANCO, True)
        if self.fin:
            botones = [("jugar_de_nuevo", "REINICIAR PARTIDO"),
                       ("menu", "VOLVER AL MENÚ"), ("salir", "SALIR DEL JUEGO")]
        else:
            botones = [("continuar", "CONTINUAR JUGANDO"),
                       ("reiniciar", "REINICIAR PARTIDO"), ("menu", "VOLVER AL MENÚ")]
        mouse = pygame.mouse.get_pos()
        for i, (accion, etiqueta) in enumerate(botones):
            rect = pygame.Rect(w // 2 - 205, h // 2 - 48 + i * 61, 410, 48)
            tono = (37, 89, 113) if rect.collidepoint(mouse) else (22, 46, 64)
            pygame.draw.rect(self.pantalla, tono, rect, border_radius=10)
            pygame.draw.rect(self.pantalla, (62, 117, 138), rect, 1, border_radius=10)
            self._texto(self.pantalla, etiqueta, rect.center, "normal", BLANCO, True)
            self.botones_overlay[accion] = rect


if __name__ == "__main__":
    Futbol2D().bucle()