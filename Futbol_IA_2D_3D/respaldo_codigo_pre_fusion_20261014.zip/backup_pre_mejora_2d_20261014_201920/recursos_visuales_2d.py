"""Carga modular de recursos para la vista cenital del juego Pygame.

El estilo activo se elige en ASSET_STYLE. Solo se lee la carpeta seleccionada.
Los fondos de estadio y la cancha trapezoidal de assets_3d se omiten porque no
son compatibles con la cámara cenital fija del juego.
"""
from __future__ import annotations

import colorsys
import math
from pathlib import Path

import pygame


# Cambia a "3d" para usar los sprites prerenderizados de assets_3d.
ASSET_STYLE = "2d"
if ASSET_STYLE not in {"2d", "3d"}:
    raise ValueError('ASSET_STYLE debe ser "2d" o "3d".')


class RecursosVisuales:
    """Carga PNG, recorta sprites aislados y ofrece alternativas seguras."""

    ALTO_JUGADOR = 42
    TAMANO_BALON = 22

    def __init__(self) -> None:
        self.raiz = Path(__file__).resolve().parent / f"assets_{ASSET_STYLE}"
        self.errores: list[str] = []
        self.cancha: pygame.Surface | None = None
        self.balon: pygame.Surface | None = None
        self.hinchas: pygame.Surface | None = None
        self.jugadores: dict[int, list[pygame.Surface]] = {0: [], 1: []}
        self._cache_previa: dict[tuple[int, int], pygame.Surface] = {}
        self._cache_jugador_base: dict[
            tuple[int, int, tuple[int, int, int]], pygame.Surface
        ] = {}
        self._cache_jugador: dict[
            tuple[int, int, int, tuple[int, int, int]], pygame.Surface
        ] = {}
        self._cache_balon: pygame.Surface | None = None
        self._cache_hinchas: dict[tuple[int, int], pygame.Surface] = {}

        # La cancha cenital ilustrada encaja con el estilo 2D. La versión 3D
        # del recurso es trapezoidal y se deja a la cancha vectorial actual.
        if ASSET_STYLE == "2d":
            self.cancha = self._cargar_png("cancha/cancha_completa.png")

        hojas = {
            0: "jugadores/jugadores_amarillo_azul.png",
            1: "jugadores/jugadores_rojo_blanco.png",
        }
        for equipo, nombre in hojas.items():
            hoja = self._cargar_png(nombre)
            if hoja is not None:
                self.jugadores[equipo] = self._recortar_figuras(hoja, nombre)

        self.balon = self._cargar_png("balon_y_efectos/balones.png")
        self.hinchas = self._cargar_png("hinchas/hinchas_fila_1.png")

    def _cargar_png(self, relativo: str) -> pygame.Surface | None:
        """Carga PNG con alfa; ante un fallo, conserva la vista vectorial."""
        ruta = self.raiz / relativo
        try:
            return pygame.image.load(ruta).convert_alpha()
        except (pygame.error, FileNotFoundError, OSError) as error:
            self.errores.append(f"{ruta.name}: {error}")
            return None

    def _recortar_figuras(self, hoja: pygame.Surface,
                          nombre: str) -> list[pygame.Surface]:
        """Detecta siluetas por componentes alfa, sin inventar coordenadas."""
        try:
            mascara = pygame.mask.from_surface(hoja, 96)
            componentes = mascara.connected_components(minimum=80)
            limites: list[pygame.Rect] = []
            for componente in componentes:
                rectangulos = componente.get_bounding_rects()
                if not rectangulos:
                    continue
                caja = rectangulos[0]
                # Excluye balones, confeti y otros detalles desconectados.
                if caja.height >= 42 and caja.width >= 26 and caja.y < hoja.get_height() * .8:
                    limites.append(caja)

            figuras: list[pygame.Surface] = []
            for caja in sorted(limites, key=lambda r: (r.x, r.y)):
                margen = caja.inflate(4, 4).clip(hoja.get_rect())
                figuras.append(hoja.subsurface(margen).copy())
            if not figuras:
                self.errores.append(f"{nombre}: no se detectaron sprites independientes")
            return figuras
        except (pygame.error, ValueError) as error:
            self.errores.append(f"{nombre}: no se pudieron recortar sprites ({error})")
            return []

    def tiene_jugadores(self, equipo: int) -> bool:
        return bool(self.jugadores.get(equipo))

    def dibujar_vista_previa_cancha(self, destino: pygame.Surface,
                                    rect: pygame.Rect) -> bool:
        """Muestra la imagen de cancha en el menú sin deformar su proporción."""
        if self.cancha is None:
            return False
        try:
            factor = min(rect.width / self.cancha.get_width(),
                         rect.height / self.cancha.get_height())
            tamano = (max(1, round(self.cancha.get_width() * factor)),
                      max(1, round(self.cancha.get_height() * factor)))
            if tamano not in self._cache_previa:
                self._cache_previa[tamano] = pygame.transform.smoothscale(self.cancha, tamano)
            imagen = self._cache_previa[tamano]
            destino.blit(imagen, imagen.get_rect(center=rect.center))
            return True
        except pygame.error as error:
            self.errores.append(f"Cancha: no se pudo escalar la vista previa ({error})")
            self.cancha = None
            return False

    def dibujar_jugador(self, destino: pygame.Surface, equipo: int,
                        indice: int, xy: tuple[int, int],
                        angulo: float,
                        color_uniforme: tuple[int, int, int] | None = None) -> bool:
        """Dibuja un recorte de jugador rotado y cacheado por orientación."""
        figuras = self.jugadores.get(equipo, [])
        if not figuras:
            return False
        numero = indice % len(figuras)
        color = color_uniforme or (255, 255, 255)
        pasos = 24
        orientacion = round((angulo % (2 * math.pi)) * pasos / (2 * math.pi)) % pasos
        clave_base = (equipo, numero, color)
        clave = (equipo, numero, orientacion, color)
        if clave_base not in self._cache_jugador_base:
            original = figuras[numero]
            alto = self.ALTO_JUGADOR
            ancho = max(20, round(original.get_width() * alto / original.get_height()))
            base = pygame.transform.smoothscale(original, (ancho, alto))
            tono_objetivo, saturacion_objetivo, valor_objetivo = colorsys.rgb_to_hsv(
                *(componente / 255 for componente in color))
            for y in range(base.get_height()):
                for x in range(base.get_width()):
                    r, g, b, alpha = base.get_at((x, y))
                    tono, saturacion, valor = colorsys.rgb_to_hsv(
                        r / 255, g / 255, b / 255)
                    # Recolorea solo el amarillo o rojo de la camiseta fuente;
                    # conserva tonos de piel, shorts, balón y luces del sprite.
                    camiseta = (0.095 <= tono <= 0.19 if equipo == 0
                                else tono <= 0.04 or tono >= 0.96)
                    if alpha and saturacion > 0.35 and camiseta:
                        nuevo = colorsys.hsv_to_rgb(
                            tono_objetivo,
                            saturacion_objetivo * (0.45 + 0.55 * saturacion),
                            valor_objetivo * (0.45 + 0.55 * valor),
                        )
                        base.set_at((x, y), tuple(round(c * 255) for c in nuevo) + (alpha,))
            self._cache_jugador_base[clave_base] = base
        if clave not in self._cache_jugador:
            self._cache_jugador[clave] = pygame.transform.rotate(
                self._cache_jugador_base[clave_base], -(orientacion * 360 / pasos))
        sprite = self._cache_jugador[clave]
        x, y = xy
        pygame.draw.ellipse(destino, (13, 43, 34), (x - 14, y + 12, 29, 9))
        destino.blit(sprite, sprite.get_rect(center=xy))
        return True

    def dibujar_balon(self, destino: pygame.Surface,
                      xy: tuple[int, int]) -> bool:
        """Dibuja el primer balón aislado de la tira como sprite individual."""
        if self.balon is None:
            return False
        if self._cache_balon is None:
            try:
                mascara = pygame.mask.from_surface(self.balon, 96)
                candidatos: list[pygame.Rect] = []
                for componente in mascara.connected_components(minimum=80):
                    rectangulos = componente.get_bounding_rects()
                    if not rectangulos:
                        continue
                    caja = rectangulos[0]
                    proporcion = caja.width / max(1, caja.height)
                    if caja.width >= 30 and caja.height >= 30 and .7 <= proporcion <= 1.35:
                        candidatos.append(caja)
                if not candidatos:
                    self.errores.append("Balón: no se encontró un recorte circular; se usa el vectorial")
                    self.balon = None
                    return False
                caja = min(candidatos, key=lambda r: (r.x, r.y))
                sprite = self.balon.subsurface(caja.inflate(4, 4).clip(self.balon.get_rect())).copy()
                self._cache_balon = pygame.transform.smoothscale(
                    sprite, (self.TAMANO_BALON, self.TAMANO_BALON))
            except (pygame.error, ValueError) as error:
                self.errores.append(f"Balón: no se pudo recortar ({error})")
                self.balon = None
                return False
        destino.blit(self._cache_balon, self._cache_balon.get_rect(center=xy))
        return True

    def dibujar_hinchas(self, destino: pygame.Surface,
                        rect: pygame.Rect) -> bool:
        """Usa la fila completa como decoración, nunca como personas sueltas."""
        if self.hinchas is None:
            return False
        try:
            clave = rect.size
            if clave not in self._cache_hinchas:
                factor = min(rect.width / self.hinchas.get_width(),
                             rect.height / self.hinchas.get_height())
                tamano = (max(1, round(self.hinchas.get_width() * factor)),
                          max(1, round(self.hinchas.get_height() * factor)))
                self._cache_hinchas[clave] = pygame.transform.smoothscale(self.hinchas, tamano)
            imagen = self._cache_hinchas[clave]
            destino.blit(imagen, imagen.get_rect(center=rect.center))
            return True
        except pygame.error as error:
            self.errores.append(f"Hinchas: no se pudo escalar ({error})")
            self.hinchas = None
            return False
