import queue
import threading
import pyttsx3


class Narrador:
    def __init__(self):
        self.cola = queue.Queue()

        # La voz funciona en otro hilo para no detener el juego.
        self.hilo = threading.Thread(
            target=self._reproducir,
            daemon=True
        )
        self.hilo.start()

    def decir(self, texto):
        """Añade una frase a la cola del narrador."""
        if texto:
            self.cola.put(str(texto))

    def _reproducir(self):
        try:
            motor = pyttsx3.init()
            motor.setProperty("rate", 175)
            motor.setProperty("volume", 1.0)

            # Busca una voz en español instalada en Windows.
            voces = motor.getProperty("voices")

            for voz in voces:
                informacion = (
                    str(voz.name) + " " +
                    " ".join(str(lengua) for lengua in voz.languages)
                ).lower()

                if any(
                    idioma in informacion
                    for idioma in (
                        "spanish", "español", "es_es",
                        "es-mx", "es_co", "es-co"
                    )
                ):
                    motor.setProperty("voice", voz.id)
                    break

            while True:
                texto = self.cola.get()

                try:
                    motor.say(texto)
                    motor.runAndWait()
                except Exception as error:
                    print(f"Error al narrar: {error}")
                finally:
                    self.cola.task_done()

        except Exception as error:
            print(f"No se pudo iniciar el narrador: {error}")