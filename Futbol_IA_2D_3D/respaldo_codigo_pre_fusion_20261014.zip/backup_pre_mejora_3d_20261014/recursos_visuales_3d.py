"""Carga segura y modular de imágenes prerrenderizadas para el juego Ursina."""
from __future__ import annotations

import colorsys
from pathlib import Path


CUADROS_JUGADOR_3D = 11  # La hoja de 756 px muestra once cuadros en una sola fila.


class RecursosVisuales3D:
    """Resuelve texturas dentro de assets_3d y mantiene fallbacks del juego."""

    ARCHIVOS = {
        "cancha": "cancha/cancha_completa.png",
        "estadio": "estadios/estadio_01.png",
        "hinchas_1": "hinchas/hinchas_fila_1.png",
        "hinchas_2": "hinchas/hinchas_fila_2.png",
        "jugadores_0": "jugadores/jugadores_amarillo_azul.png",
        "jugadores_1": "jugadores/jugadores_rojo_blanco.png",
    }

    def __init__(self) -> None:
        self.raiz = Path(__file__).resolve().parent / "assets_3d"
        self._texturas: dict[str, object] = {}
        self._hojas: dict[tuple[int, tuple[int, int, int]], object | None] = {}
        self.errores: list[str] = []

    def textura(self, nombre: str):
        """Carga una textura por su nombre lógico; devuelve None ante un fallo."""
        if nombre in self._texturas:
            return self._texturas[nombre]
        relativo = self.ARCHIVOS.get(nombre)
        if relativo is None:
            self.errores.append(f"Recurso 3D desconocido: {nombre}")
            return None
        ruta = self.raiz / relativo
        try:
            if not ruta.is_file():
                raise FileNotFoundError(ruta)
            # Ursina necesita la carpeta explícita para resolver rutas fuera de
            # su directorio global de assets. La ruta nace siempre de __file__.
            from ursina import load_texture
            textura = load_texture(ruta.name, folder=ruta.parent)
            if textura is None:
                raise OSError(f"Ursina no pudo decodificar {ruta.name}")
            self._texturas[nombre] = textura
            return textura
        except (FileNotFoundError, OSError, RuntimeError, ValueError) as error:
            self.errores.append(f"{ruta}: {error}")
            self._texturas[nombre] = None
            return None

    def hoja_jugadores(self, equipo: int, camiseta: tuple[int, int, int]):
        """Recolorea el tono de camiseta y conserva el sombreado prerenderizado."""
        clave = (equipo, tuple(camiseta))
        if clave in self._hojas:
            return self._hojas[clave]
        nombre = f"jugadores_{equipo}"
        relativa = self.ARCHIVOS[nombre]
        ruta = self.raiz / relativa
        try:
            if not ruta.is_file():
                raise FileNotFoundError(ruta)
            from PIL import Image
            from ursina import Texture

            imagen = Image.open(ruta).convert("RGBA")
            objetivo = colorsys.rgb_to_hsv(*(canal / 255 for canal in camiseta))
            pixeles = imagen.load()
            es_amarilla = equipo == 0
            for y in range(imagen.height):
                for x in range(imagen.width):
                    rojo, verde, azul, alfa = pixeles[x, y]
                    if not alfa:
                        continue
                    tono, saturacion, valor = colorsys.rgb_to_hsv(
                        rojo / 255, verde / 255, azul / 255)
                    camiseta_base = (
                        0.075 <= tono <= 0.20 if es_amarilla
                        else tono <= 0.055 or tono >= 0.945
                    )
                    if camiseta_base and saturacion > 0.30:
                        nuevo = colorsys.hsv_to_rgb(
                            objetivo[0],
                            min(1.0, max(0.42, objetivo[1] * (0.58 + 0.42 * saturacion))),
                            min(1.0, valor * (0.72 + 0.28 * objetivo[2]) / 0.92),
                        )
                        pixeles[x, y] = tuple(round(c * 255) for c in nuevo) + (alfa,)
            textura = Texture(imagen, filtering="bilinear")
            textura.repeat = False
            self._hojas[clave] = textura
            return textura
        except (FileNotFoundError, OSError, RuntimeError, ValueError, ImportError) as error:
            self.errores.append(f"{ruta}: no se pudo preparar la hoja de jugadores ({error})")
            self._hojas[clave] = None
            return None
