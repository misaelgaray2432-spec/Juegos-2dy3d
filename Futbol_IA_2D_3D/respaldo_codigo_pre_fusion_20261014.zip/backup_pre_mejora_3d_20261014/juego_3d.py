"""Fútbol 3D en Ursina con estética de estadio y modos cooperativos."""
from __future__ import annotations

# Mantener esta importación antes de Ursina evita una colisión de DLL en Windows
# cuando TensorFlow y Panda3D se cargan en el mismo proceso.
import math
import random

from ia_futbol import IAFutbol, MODOS, clamp
from selecciones import SELECCIONES, formacion, obtener_seleccion
from audio_futbol import AudioFutbol
from recursos_visuales_3d import RecursosVisuales3D, CUADROS_JUGADOR_3D
from ursina import (AmbientLight, Button, Cylinder, DirectionalLight, Entity, Func, Text, destroy,
                    Ursina, Vec3, application, camera, color, held_keys, time,
                    window)
from ursina.shaders import lit_with_shadows_shader


LARGO, ANCHO = 24.0, 14.0
VERDE_1 = color.rgb32(31, 119, 69)
VERDE_2 = color.rgb32(38, 132, 74)
BLANCO = color.rgb32(239, 246, 238)
AZUL = color.rgb32(31, 139, 255)
ROJO = color.rgb32(244, 71, 81)
AMARILLO = color.rgb32(255, 203, 66)


def segmento(a: tuple[float, float], b: tuple[float, float], grosor: float = .045,
             y: float = .025, tono=BLANCO, parent=None) -> Entity:
    """Dibuja una línea sobre el plano XZ usando una caja fina."""
    dx, dz = b[0] - a[0], b[1] - a[1]
    largo = math.hypot(dx, dz)
    e = Entity(model="cube", parent=parent, color=tono,
               position=((a[0] + b[0]) / 2, y, (a[1] + b[1]) / 2),
               scale=(largo, .025, grosor))
    e.rotation_y = -math.degrees(math.atan2(dz, dx))
    return e


class Juego3D(Entity):
    """Partido 3D con equipos mixtos, físicas sencillas y HUD deportivo."""

    def __init__(self) -> None:
        super().__init__()
        window.color = color.rgb32(7, 15, 24)
        window.exit_button.visible = False
        camera.position = (0, 24, -30)
        camera.rotation = (38, 0, 0)
        camera.fov = 61
        self.estado = "menu"
        self.modo = 1
        self.pais_indices = [0, 1]
        self.pais_etiquetas: list[Text] = []
        self.pais_escudos: list[Entity] = []
        self.audio = AudioFutbol()
        self.recursos_3d = RecursosVisuales3D()
        self.ultimo_golpeador: dict | None = None
        self._poseedor_control_anterior: dict | None = None
        self.ia: IAFutbol | None = None
        self.jugadores: list[dict] = []
        self.poseedor: dict | None = None
        self.arena = Entity(parent=self, enabled=True)
        self.menu_widgets: list[Entity] = []
        self.hud_widgets: list[Entity] = []
        self.overlay_widgets: list[Entity] = []
        self.overlay_title: Text | None = None
        self.overlay_subtitle: Text | None = None
        self.overlay_resume: Button | None = None
        self.overlay_restart: Button | None = None
        self.overlay_menu: Button | None = None
        self.balon: Entity
        self.vista_cenital = False
        self.boton_vista: Button | None = None
        self.panel_marcador: Text | None = None
        self.mensaje_partido = ""
        self.mensaje_tiempo = 0.0
        self.tiempo = 0.0
        self.reloj_partido = 150.0
        self.temporizador_ia = 0.0
        self.pausa = False
        self.fin = False
        # El estadio sirve también como fondo visual del menú principal.
        self._crear_estadio()
        self._crear_balon()
        self.balon.enabled = False
        self._menu()

    # ------------------------------- Menús ---------------------------------
    def _menu(self) -> None:
        """Menú de partido con composición original inspirada en retransmisiones."""
        def panel(x: float, y: float, ancho: float, alto: float, tono,
                  z: float = .02, rotacion: float = 0) -> Entity:
            entidad = Entity(parent=camera.ui, model="quad", position=(x, y, z),
                             scale=(ancho, alto), rotation_z=rotacion,
                             color=tono, unlit=True)
            self.menu_widgets.append(entidad)
            return entidad

        def texto(contenido: str, x: float, y: float, escala: float, tono,
                  z: float = -.035) -> Text:
            entidad = Text(contenido, parent=camera.ui, position=(x, y, z),
                           scale=escala, color=tono, unlit=True)
            self.menu_widgets.append(entidad)
            return entidad

        # Oscurece el estadio sin ocultarlo. Las capas usan Z distintos para
        # evitar el bloque blanco y el parpadeo por superposición del menú viejo.
        panel(0, 0, 2, 2, color.rgba32(2, 8, 15, 92), z=.12)
        panel(-.31, 0, .72, 1.04, color.rgba32(5, 15, 27, 228), z=.07)
        panel(.36, 0, .56, 1.04, color.rgba32(7, 20, 32, 226), z=.07)
        panel(-.31, .476, .72, .008, color.rgba32(42, 161, 255), z=.055)

        # Marca y cabecera, con estética de menú de partido de consola.
        panel(-.612, .414, .045, .045, AZUL, z=.025)
        texto("P", -.625, .397, .86, BLANCO, z=-.045)
        texto("PITCH  /  MATCHDAY 2026", -.565, .408, .56, AMARILLO)
        texto("CENTRO DE PARTIDO", -.565, .342, 1.18, BLANCO)
        texto("Elige cómo quieres jugar", -.565, .293, .58,
              color.rgb32(164, 184, 198))
        texto("MODOS DE JUEGO", -.565, .225, .50,
              color.rgb32(112, 202, 255))

        modos = [
            ("EXHIBICIÓN  ·  1 VS IA", "Un usuario contra el equipo rival controlado por IA."),
            ("DUELO LOCAL  ·  1 VS 1", "Dos personas juegan en el mismo teclado."),
            ("COOPERATIVO  ·  2 VS IA", "Dos usuarios cooperan frente a un equipo de IA."),
            ("PARTIDO  ·  2 VS 2", "Dos usuarios y dos jugadores independientes de IA."),
        ]
        tonos = [AZUL, color.rgb32(111, 210, 164), AMARILLO, ROJO]
        for indice, (titulo, detalle) in enumerate(modos):
            y = .135 - indice * .122
            activo = indice == 0
            base = color.rgba32(17, 38, 56, 245) if activo else color.rgba32(10, 27, 41, 225)
            panel(-.31, y, .645, .102, base, z=.035)
            panel(-.615, y, .008, .078, tonos[indice], z=.005)
            boton = Button(parent=camera.ui, text="", position=(-.31, y, -.012),
                           scale=(.645, .102), color=color.rgba32(22, 43, 59, 0),
                           highlight_color=color.rgba32(49, 77, 96, 150),
                           pressed_color=tonos[indice],
                           on_click=Func(self.iniciar, indice + 1))
            self.menu_widgets.append(boton)
            texto(f"0{indice + 1}", -.585, y + .012, .62, tonos[indice], z=-.05)
            texto(titulo, -.535, y + .014, .57, BLANCO, z=-.05)
            texto(detalle, -.535, y - .025, .405,
                  color.rgb32(158, 180, 194), z=-.05)

        # Selector nacional editable por teclado o botones de flecha.
        texto("PREVIA DEL ENCUENTRO", .105, .414, .56, AMARILLO)
        texto("SELECCIONES · 11 TITULARES", .105, .363, .66, BLANCO)
        actual_0 = obtener_seleccion(self.pais_indices[0])
        actual_1 = obtener_seleccion(self.pais_indices[1])
        self.pais_escudos.append(panel(.175, .277, .070, .060,
                                      color.rgb32(*actual_0.camiseta), z=.015))
        self.pais_etiquetas.append(texto(actual_0.sigla, .153, .259, .55, BLANCO, z=-.04))
        self.pais_etiquetas.append(texto(actual_0.nombre, .218, .265, .45,
                                         color.rgb32(207, 224, 237)))
        texto("VS", .352, .264, .57, color.rgb32(149, 170, 184))
        self.pais_escudos.append(panel(.490, .277, .070, .060,
                                      color.rgb32(*actual_1.camiseta), z=.015))
        self.pais_etiquetas.append(texto(actual_1.sigla, .468, .259, .55, BLANCO, z=-.04))
        self.pais_etiquetas.append(texto(actual_1.nombre, .532, .265, .45,
                                         color.rgb32(237, 210, 210)))
        for equipo, x, paso in ((0, .12, -1), (0, .31, 1), (1, .435, -1), (1, .645, 1)):
            boton_pais = Button(parent=camera.ui, text="‹" if paso < 0 else "›",
                                position=(x, .277, -.025), scale=(.028, .045),
                                color=color.rgb32(23, 46, 63),
                                highlight_color=color.rgb32(46, 87, 111),
                                text_color=BLANCO, text_size=.7,
                                on_click=Func(self.cambiar_pais, equipo, paso))
            self.menu_widgets.append(boton_pais)
        texto("A/D local · ←/→ visitante · R sortear equipo IA", .105, .203, .43,
              color.rgb32(148, 177, 191))

        # Campo de vista previa. Cada capa tiene profundidad propia para que
        # el césped, las líneas, las áreas y los jugadores siempre se dibujen.
        campo_x, campo_y = .36, .035
        campo_w, campo_h = .43, .235
        panel(campo_x, campo_y, campo_w, campo_h, color.rgb32(236, 241, 233), z=.025)
        panel(campo_x, campo_y, campo_w - .012, campo_h - .012,
              color.rgb32(30, 113, 69), z=.018)
        for franja in range(6):
            tono = color.rgb32(34, 124, 74) if franja % 2 == 0 else color.rgb32(29, 108, 66)
            franja_x = campo_x - campo_w / 2 + (franja + .5) * (campo_w / 6)
            panel(franja_x, campo_y, campo_w / 6 - .002, campo_h - .014, tono, z=.012)

        # Trazos reglamentarios de la mini cancha.
        borde = color.rgb32(224, 236, 222)
        linea = .0025
        panel(campo_x, campo_y + campo_h / 2 - .009, campo_w - .018, linea, borde, z=.003)
        panel(campo_x, campo_y - campo_h / 2 + .009, campo_w - .018, linea, borde, z=.003)
        panel(campo_x - campo_w / 2 + .009, campo_y, linea, campo_h - .018, borde, z=.003)
        panel(campo_x + campo_w / 2 - .009, campo_y, linea, campo_h - .018, borde, z=.003)
        panel(campo_x, campo_y, linea, campo_h - .02, borde, z=.001)
        for lado in (-1, 1):
            area_x = campo_x + lado * .151
            panel(area_x, campo_y, .002, .112, borde, z=.001)
            panel(area_x - lado * .033, campo_y + .055, .068, .002, borde, z=.001)
            panel(area_x - lado * .033, campo_y - .055, .068, .002, borde, z=.001)
        # Círculo central con segmentos; evita depender de texturas externas.
        for paso in range(20):
            angulo = paso * math.tau / 20
            panel(campo_x + math.cos(angulo) * .038,
                  campo_y + math.sin(angulo) * .038,
                  .013, .002, borde, z=-.002,
                  rotacion=math.degrees(angulo))
        panel(campo_x, campo_y, .009, .009, AMARILLO, z=-.006, rotacion=45)
        # Marcadores romboidales de ambos equipos sobre el esquema táctico.
        posiciones_azules = [(-.145, 0), (-.092, -.055), (-.092, .055), (-.035, 0)]
        posiciones_rojas = [(.145, 0), (.092, -.055), (.092, .055), (.035, 0)]
        for equipo_color, posiciones in ((AZUL, posiciones_azules), (ROJO, posiciones_rojas)):
            for dx, dy in posiciones:
                panel(campo_x + dx, campo_y + dy, .012, .012,
                      equipo_color, z=-.009, rotacion=45)

        # Textura de cancha prerenderizada de assets_3d. Se ajusta al recuadro
        # sin deformarla; el esquema vectorial anterior queda como fallback.
        textura_cancha = self.recursos_3d.textura("cancha")
        if textura_cancha is not None and textura_cancha.width and textura_cancha.height:
            factor = min((campo_w - .012) / textura_cancha.width,
                         (campo_h - .012) / textura_cancha.height)
            imagen_cancha = Entity(
                parent=camera.ui, model="quad", texture=textura_cancha,
                position=(campo_x, campo_y, -.018),
                scale=(textura_cancha.width * factor, textura_cancha.height * factor),
                color=BLANCO, unlit=True, double_sided=True,
            )
            self.menu_widgets.append(imagen_cancha)

        self.boton_vista = Button(parent=camera.ui, text="VISTA TÁCTICA  /  CAMBIAR CÁMARA",
                                  position=(.36, -.145, -.02), scale=(.43, .052),
                                  color=color.rgb32(21, 48, 68),
                                  highlight_color=color.rgb32(38, 79, 103),
                                  pressed_color=AMARILLO, text_color=BLANCO,
                                  text_size=.62, on_click=Func(self._alternar_vista))
        self.menu_widgets.append(self.boton_vista)
        self._actualizar_boton_vista()
        texto("V cambia la cámara durante el partido", .105, -.198, .43,
              color.rgb32(143, 168, 183))
        panel(.36, -.275, .50, .002, color.rgba32(147, 171, 185, 100), z=.01)
        texto("CONTROLES LOCALES", .105, -.305, .47, AMARILLO)
        texto("J1 WASD · tiro ESPACIO · pase Q · centro E · robo F · cambiar TAB",
              .105, -.345, .405, color.rgb32(208, 220, 224))
        texto("J2 flechas · tiro CTRL DER. · pase ENTER · centro U · robo ALT · cambiar BKSP",
              .105, -.382, .365, color.rgb32(176, 196, 205))
        texto("1–4  ELEGIR MODO     ·     ESC  SALIR", -.565, -.441, .47,
              color.rgb32(133, 158, 174))

    def _actualizar_boton_vista(self) -> None:
        if self.boton_vista is not None:
            self.boton_vista.text = ("CÁMARA  ·  TRANSMISIÓN 3D" if self.vista_cenital
                                     else "CÁMARA  ·  VISTA TÁCTICA")

    def cambiar_pais(self, equipo: int, paso: int) -> None:
        """Actualiza la selección antes de iniciar el partido."""
        self.pais_indices[equipo] = (self.pais_indices[equipo] + paso) % len(SELECCIONES)
        seleccion = obtener_seleccion(self.pais_indices[equipo])
        self.pais_etiquetas[equipo * 2].text = seleccion.sigla
        self.pais_etiquetas[equipo * 2 + 1].text = seleccion.nombre
        self.pais_escudos[equipo].color = color.rgb32(*seleccion.camiseta)

    def _configurar_camara(self) -> None:
        """Alterna entre retransmisión inclinada y táctica cenital tipo 2D."""
        if self.vista_cenital:
            camera.position = (0, 31, 0)
            camera.rotation = (90, 0, 0)
            camera.fov = 42
        else:
            camera.position = (0, 23, -29)
            camera.rotation = (38, 0, 0)
            camera.fov = 61
        for jugador in self.jugadores:
            sprite = jugador.get("sprite")
            cuerpo = jugador.get("cuerpo")
            if sprite is not None:
                sprite.enabled = not self.vista_cenital
            if cuerpo is not None:
                cuerpo.enabled = self.vista_cenital or sprite is None

    def _alternar_vista(self) -> None:
        self.vista_cenital = not self.vista_cenital
        self._configurar_camara()
        self._actualizar_boton_vista()

    def _crear_hud(self) -> None:
        self.hud_widgets = [
            Entity(parent=camera.ui, model="quad", position=(0, .455),
                   scale=(.78, .105), color=color.rgba32(7, 18, 30, 225)),
            Text("", parent=camera.ui, y=.46, scale=1.05, color=BLANCO),
            Text("", parent=camera.ui, y=-.405, scale=.55,
                 color=color.rgb32(202, 216, 219)),
            Text("", parent=camera.ui, y=.36, scale=.8, color=AMARILLO),
        ]
        self._crear_overlay_partido()

    def _crear_overlay_partido(self) -> None:
        """Crea un menú de pausa/final con botones para seguir, reiniciar o salir al menú."""
        sombra = Entity(parent=camera.ui, model="quad", position=(0, 0, -.20),
                        scale=(2, 2), color=color.rgba32(2, 7, 13, 205), unlit=True)
        tarjeta = Entity(parent=camera.ui, model="quad", position=(0, 0, -.23),
                         scale=(.72, .65), color=color.rgba32(10, 25, 40, 250), unlit=True)
        acento = Entity(parent=camera.ui, model="quad", position=(0, .304, -.25),
                        scale=(.72, .008), color=AZUL, unlit=True)
        self.overlay_title = Text("PAUSA", parent=camera.ui, y=.19, z=-.28,
                                  scale=1.65, color=AMARILLO, unlit=True)
        self.overlay_subtitle = Text("El partido está detenido", parent=camera.ui,
                                     y=.105, z=-.28, scale=.72,
                                     color=color.rgb32(190, 207, 216), unlit=True)
        self.overlay_resume = Button(parent=camera.ui, text="CONTINUAR JUGANDO",
                                     position=(0, .025, -.31), scale=(.48, .075),
                                     color=color.rgb32(25, 78, 101),
                                     highlight_color=color.rgb32(39, 115, 143),
                                     pressed_color=AZUL, text_color=BLANCO,
                                     text_size=.8, on_click=Func(self._reanudar_partido))
        self.overlay_restart = Button(parent=camera.ui, text="REINICIAR PARTIDO",
                                      position=(0, -.075, -.31), scale=(.48, .075),
                                      color=color.rgb32(24, 47, 64),
                                      highlight_color=color.rgb32(45, 77, 94),
                                      pressed_color=AMARILLO, text_color=BLANCO,
                                      text_size=.8, on_click=Func(self._reiniciar_partido))
        self.overlay_menu = Button(parent=camera.ui, text="VOLVER A SELECCIÓN",
                                   position=(0, -.175, -.31), scale=(.48, .075),
                                   color=color.rgb32(24, 47, 64),
                                   highlight_color=color.rgb32(45, 77, 94),
                                   pressed_color=ROJO, text_color=BLANCO,
                                   text_size=.8, on_click=Func(self._volver_al_menu))
        self.overlay_widgets = [sombra, tarjeta, acento, self.overlay_title,
                                self.overlay_subtitle, self.overlay_resume,
                                self.overlay_restart, self.overlay_menu]
        for widget in self.overlay_widgets:
            widget.enabled = False

    def _actualizar_overlay_partido(self) -> None:
        visible = self.estado == "partido" and (self.pausa or self.fin)
        for widget in self.overlay_widgets:
            widget.enabled = visible
        if (not visible or self.overlay_title is None
                or self.overlay_subtitle is None):
            return
        if self.fin:
            self.overlay_title.text = "PARTIDO FINALIZADO"
            self.overlay_subtitle.text = "Puedes jugar la revancha o volver al menú de selecciones."
            if self.overlay_resume is not None:
                self.overlay_resume.enabled = False
            if self.overlay_restart is not None:
                self.overlay_restart.text = "JUGAR DE NUEVO"
        else:
            self.overlay_title.text = "PAUSA"
            self.overlay_subtitle.text = "Partido detenido · P continúa · R reinicia · Esc menú"
            if self.overlay_resume is not None:
                self.overlay_resume.enabled = True
            if self.overlay_restart is not None:
                self.overlay_restart.text = "REINICIAR PARTIDO"

    def _reanudar_partido(self) -> None:
        if self.estado == "partido" and not self.fin:
            self.pausa = False
            self._actualizar_overlay_partido()

    def _reiniciar_partido(self) -> None:
        if self.estado == "partido":
            self.iniciar(self.modo)

    def _volver_al_menu(self) -> None:
        if self.ia and not self.ia.log.done:
            self.ia.log.finish()
        self.estado = "menu"
        self.pausa = self.fin = False
        for jugador in self.jugadores:
            jugador["e"].enabled = False
        self.balon.enabled = False
        self._hud_visible(False)
        self._actualizar_overlay_partido()
        for widget in self.menu_widgets:
            widget.enabled = True

    def _hud_visible(self, visible: bool) -> None:
        for widget in self.hud_widgets:
            widget.enabled = visible

    # ---------------------------- Estadio/campo -----------------------------
    def _crear_estadio(self) -> None:
        # El shader de sombras se aplica a la geometría 3D que se crea a
        # continuación; se restaura al terminar para que el menú 2D no cambie.
        shader_anterior = Entity.default_shader
        Entity.default_shader = lit_with_shadows_shader

        # Iluminación y suelo del estadio.
        Entity(parent=self.arena, model="plane", scale=(42, 1, 31),
               color=color.rgb32(22, 37, 43), position=(0, -.32, 0))
        Entity(parent=self.arena, model="plane", scale=(LARGO, 1, ANCHO),
               color=VERDE_1, position=(0, -.13, 0))
        for i in range(12):
            x = -LARGO / 2 + i * LARGO / 12 + LARGO / 24
            Entity(parent=self.arena, model="cube", color=VERDE_1 if i % 2 == 0 else VERDE_2,
                   position=(x, -.045, 0), scale=(LARGO / 12, .035, ANCHO - .12))

        # Líneas blancas reglamentarias.
        x0, x1, z0, z1 = -LARGO / 2, LARGO / 2, -ANCHO / 2, ANCHO / 2
        segmento((x0, z0), (x1, z0), parent=self.arena)
        segmento((x0, z1), (x1, z1), parent=self.arena)
        segmento((x0, z0), (x0, z1), parent=self.arena)
        segmento((x1, z0), (x1, z1), parent=self.arena)
        segmento((0, z0), (0, z1), parent=self.arena)
        # Círculo central y punto de saque dibujados como líneas segmentadas.
        self._circulo((0, .04, 0), 2.0, 48, parent=self.arena)
        Entity(parent=self.arena, model="sphere", color=BLANCO, scale=.12,
               position=(0, .035, 0))
        for lado in (-1, 1):
            x = lado * 8.0
            xa = lado * 12.0
            # Área grande (16 x 6), área chica (5 x 3.2), penal y semicírculo.
            segmento((xa, -3), (x, -3), parent=self.arena)
            segmento((x, -3), (x, 3), parent=self.arena)
            segmento((x, 3), (xa, 3), parent=self.arena)
            xc = lado * 10.35
            segmento((xa, -1.65), (xc, -1.65), parent=self.arena)
            segmento((xc, -1.65), (xc, 1.65), parent=self.arena)
            segmento((xc, 1.65), (xa, 1.65), parent=self.arena)
            Entity(parent=self.arena, model="sphere", color=BLANCO, scale=.11,
                   position=(lado * 8.1, .035, 0))
            self._arco_penal(lado, parent=self.arena)
            self._portería(lado, parent=self.arena)

        # Tribunas escalonadas, vallas y focos para dejar clara la escala del estadio.
        for i in range(3):
            altura = .6 + i * .55
            for lado in (-1, 1):
                Entity(parent=self.arena, model="cube", color=color.rgb32(23 + i * 5, 38 + i * 5, 53 + i * 6),
                       position=(0, altura, lado * (8.2 + i * .62)), scale=(30, .7, .75))
                Entity(parent=self.arena, model="cube", color=color.rgb32(22 + i * 4, 38 + i * 4, 54 + i * 5),
                       position=(lado * (13.1 + i * .55), altura, 0), scale=(.75, .7, 17))
        # Cubiertas, vigas y soportes dan volumen a las tribunas y enmarcan
        # la cancha en la cámara de transmisión.
        for lado in (-1, 1):
            Entity(parent=self.arena, model="cube", color=color.rgb32(16, 29, 43),
                   position=(0, 3.65, lado * 10.25), scale=(30.5, .24, 2.1))
            Entity(parent=self.arena, model="cube", color=color.rgb32(40, 61, 78),
                   position=(0, 3.50, lado * 9.18), scale=(29.5, .10, .09))
            for x in (-13.7, -9.2, -4.6, 0, 4.6, 9.2, 13.7):
                Entity(parent=self.arena, model="cube", color=color.rgb32(45, 59, 70),
                       position=(x, 2.65, lado * 9.75), scale=(.11, 1.8, .12))
        # Pantalla panorámica en la tribuna: usa el estadio de assets_3d y
        # mantiene el marcador/HUD original como capa independiente.
        textura_estadio = self.recursos_3d.textura("estadio")
        Entity(parent=self.arena, model="cube", color=color.rgb32(7, 17, 27),
               position=(0, 4.55, 9.35), scale=(4.6, 2.9, .24))
        if textura_estadio is not None:
            Entity(parent=self.arena, model="quad", texture=textura_estadio,
                   position=(0, 4.55, 9.19), rotation=(0, 180, 0),
                   scale=(4.35, 2.61), color=BLANCO, unlit=True, double_sided=True)
            Entity(parent=self.arena, model="quad",
                   position=(0, 3.40, 9.17), rotation=(0, 180, 0),
                   scale=(4.35, .30), color=color.rgba32(4, 13, 24, 205),
                   unlit=True, double_sided=True)
        self.panel_marcador = Text("PITCH  ·  MATCH CENTER", parent=self.arena,
                                   position=(0, 3.35 if textura_estadio is not None else 4.35, 9.15),
                                   rotation=(0, 180, 0), scale=1.0 if textura_estadio is not None else 1.25,
                                   color=AMARILLO, unlit=True)
        # Banda publicitaria perimetral con bloques luminosos de color.
        tonos_panel = [color.rgb32(24, 91, 143), color.rgb32(26, 120, 91),
                       color.rgb32(146, 91, 32)]
        for i, x in enumerate(range(-9, 10, 3)):
            for lado in (-1, 1):
                Entity(parent=self.arena, model="cube", color=tonos_panel[i % len(tonos_panel)],
                       position=(x, .20, lado * 7.22), scale=(2.75, .34, .10), unlit=True)
        self._multitud()
        for x in (-14.8, 14.8):
            for z in (-9.6, 9.6):
                Entity(parent=self.arena, model=Cylinder(), color=color.rgb32(70, 85, 99),
                       position=(x, 4.1, z), scale=(.12, 8.2, .12))
                Entity(parent=self.arena, model="cube", color=color.rgb32(213, 233, 255),
                       position=(x, 8.15, z), scale=(1.1, .2, .45))
        # Banderines de esquina completan la lectura de estadio.
        for x in (-11.7, 11.7):
            for z in (-6.7, 6.7):
                Entity(parent=self.arena, model=Cylinder(), color=color.rgb32(232, 236, 222),
                       position=(x, .36, z), scale=(.035, .72, .035))
                Entity(parent=self.arena, model="cube",
                       color=AZUL if (x * z) > 0 else ROJO,
                       position=(x + .13, .60, z), scale=(.27, .16, .025))
        sol = DirectionalLight(parent=self.arena, y=12, z=-5,
                               shadows=True, shadow_map_resolution=(512, 512))
        sol.look_at(Vec3(0, 0, 0))
        sol.update_bounds(self.arena)
        AmbientLight(parent=self.arena, color=color.rgba32(115, 130, 150, 255))
        Entity.default_shader = shader_anterior
        self._configurar_camara()

    def _circulo(self, centro: tuple[float, float, float], radio: float,
                 pasos: int, parent) -> None:
        cx, y, cz = centro
        puntos = [(cx + math.cos(i * 2 * math.pi / pasos) * radio,
                   cz + math.sin(i * 2 * math.pi / pasos) * radio) for i in range(pasos + 1)]
        for a, b in zip(puntos, puntos[1:]):
            segmento(a, b, grosor=.04, y=y, parent=parent)

    def _arco_penal(self, lado: int, parent) -> None:
        cx, radio = lado * 8.1, 2.0
        puntos = []
        # Sólo se dibuja el arco que queda fuera del rectángulo del área.
        inicio = math.pi / 2 if lado == 1 else -math.pi / 2
        for i in range(25):
            ang = inicio + i * math.pi / 24
            puntos.append((cx + math.cos(ang) * radio, math.sin(ang) * radio))
        for a, b in zip(puntos, puntos[1:]):
            segmento(a, b, y=.035, parent=parent)

    def _portería(self, lado: int, parent) -> None:
        x = lado * 12.35
        poste = color.rgb32(245, 246, 233)
        for z in (-1.7, 1.7):
            Entity(parent=parent, model="cube", color=poste,
                   position=(x, .95, z), scale=(.16, 1.9, .16))
        Entity(parent=parent, model="cube", color=poste,
               position=(x, 1.9, 0), scale=(.16, .16, 3.5))
        fondo_x = lado * 13.7
        # Malla visible en fondo y laterales del arco.
        for i in range(8):
            z = -1.65 + i * .47
            segmento((fondo_x, z), (x, z), grosor=.022, y=.15, tono=color.rgb32(174, 197, 193), parent=parent)
        for z in (-1.7, 1.7):
            for i in range(5):
                yy = .15 + i * .36
                Entity(parent=parent, model="cube", color=color.rgb32(172, 195, 190),
                       position=((x + fondo_x) / 2, yy, z),
                       scale=(abs(fondo_x - x), .018, .018))

    def _multitud(self) -> None:
        rng = random.Random(29)
        tonos = [color.rgb32(47, 134, 224), color.rgb32(228, 74, 83),
                 color.rgb32(244, 202, 75), color.rgb32(223, 229, 221),
                 color.rgb32(48, 173, 126)]
        # Puntos de color como público lejano en las cuatro tribunas.
        for i in range(180):
            color_fan = rng.choice(tonos)
            lado = rng.choice((-1, 1))
            if i % 2:
                x, z = rng.uniform(-13, 13), lado * rng.uniform(8.5, 10.1)
            else:
                x, z = lado * rng.uniform(13, 15.1), rng.uniform(-7.8, 7.8)
            y = rng.choice((.95, 1.5, 2.05))
            Entity(parent=self.arena, model="sphere", color=color_fan,
                   position=(x, y, z), scale=.11, unlit=True)

        # Las hojas de hinchas son franjas decorativas completas; se colocan
        # como vallas verticales a ambos lados y no se interpretan como sprites
        # individuales. Si falta una, los puntos de público anteriores quedan.
        for z, nombre, giro in ((-8.66, "hinchas_1", 0), (8.66, "hinchas_2", 180)):
            textura = self.recursos_3d.textura(nombre)
            if textura is None or not textura.width or not textura.height:
                continue
            # Mantiene la proporción del recorte y deja el resto del público
            # procedural visible alrededor de la franja.
            ancho = 12.0
            alto = ancho * textura.height / textura.width
            Entity(parent=self.arena, model="quad", texture=textura,
                   position=(0, .48 + alto / 2, z), rotation=(0, giro, 0),
                   scale=(ancho, alto), color=BLANCO, unlit=True, double_sided=True)

    # --------------------------- Inicio y entidades ------------------------
    def iniciar(self, modo: int) -> None:
        self.modo = modo
        if self.ia is None:
            self.ia = IAFutbol()
        elif not self.ia.log.done:
            self.ia.log.finish()
        paises = tuple(obtener_seleccion(i).nombre for i in self.pais_indices)
        self.ia.log.start(modo, paises)
        for widget in self.menu_widgets:
            widget.enabled = False
        # Conserva el estadio del menú y recrea únicamente los actores del partido.
        for jugador in self.jugadores:
            destroy(jugador["e"])
        if self.balon:
            destroy(self.balon)
        self._crear_jugadores()
        self._crear_balon()
        self._iniciar_saque(0)
        if not self.hud_widgets:
            self._crear_hud()
        self._hud_visible(True)
        self.tiempo = self.temporizador_ia = 0.0
        self.reloj_partido = 150.0
        self.pausa = self.fin = False
        self.estado = "partido"
        self._poseedor_control_anterior = None
        self._configurar_camara()
        self.audio.efecto("silbato")
        self._actualizar_overlay_partido()

    def _iniciar_saque(self, equipo: int) -> None:
        """Da el balón al equipo que recibe el gol y devuelve a todos a su posición."""
        signo = 1 if equipo == 0 else -1
        for jugador in self.jugadores:
            jugador["e"].position = (jugador["casa"][0], 0, jugador["casa"][1])
            jugador["objetivo"] = jugador["casa"]
            jugador["direccion"] = (float(signo), 0.0)
            jugador["e"].rotation_y = math.degrees(math.atan2(-signo, 0))
            jugador["moviendo"] = False
            jugador["recarga_robo"] = 0.0

        sacador = max((p for p in self.jugadores if p["equipo"] == equipo
                       and p["indice"] >= 9), key=lambda p: p["indice"], default=None)
        if sacador is not None:
            sacador["e"].position = (-signo * .72, 0, 0)
            sacador["objetivo"] = (-signo * .72, 0.0)
            sacador["direccion"] = (float(signo), 0.0)
            sacador["e"].rotation_y = math.degrees(math.atan2(-signo, 0))
            sacador["recarga_robo"] = .8
        self.poseedor = sacador
        self.balon.position = (0, .42, 0)
        self.vel_balon = Vec3(0, 0, 0)
        self.ultimo_golpeador = None
        self._poseedor_control_anterior = None
        self.mensaje_partido = "SAQUE INICIAL · " + obtener_seleccion(self.pais_indices[equipo]).nombre.upper()
        self.mensaje_tiempo = 2.0

    def _crear_jugadores(self) -> None:
        self.jugadores = []
        for equipo in (0, 1):
          seleccion = obtener_seleccion(self.pais_indices[equipo])
          color_equipo = color.rgb32(*seleccion.camiseta)
          color_detalle = color.rgb32(*seleccion.detalle)
          hoja_jugadores = self.recursos_3d.hoja_jugadores(equipo, seleccion.camiseta)
          for indice in range(11):
            color_camiseta = (color.rgb32(235, 168, 48) if equipo == 0 else color.rgb32(139, 101, 219)) if indice == 0 else color_equipo
            control = "IA"
            if self.modo == 1 and equipo == 0 and indice == 10:
                control = "H1"
            elif self.modo == 2 and indice == 10:
                control = "H1" if equipo == 0 else "H2"
            elif self.modo in (3, 4) and equipo == 1 and indice in (9, 10):
                control = "H2" if indice == 9 else "H1"
            x, z = formacion(equipo, indice, -10.8, 10.8, 0.0, 5.5)
            actor = Entity(parent=self.arena, position=(x, 0, z))
            cuerpo = Entity(parent=actor)
            # Uniforme deportivo por capas: botines, medias, pantaloneta,
            # camiseta con franjas, brazos articulados y cabeza con cabello.
            Entity(parent=actor, model="sphere", color=color.rgba32(8, 18, 15, 135),
                   position=(0, .055, .03), scale=(.61, .035, .82), unlit=True)
            marcador = Entity(parent=actor, model="sphere", color=AMARILLO,
                              position=(0, .082, .03), scale=(.70, .024, .92),
                              unlit=True, enabled=control != "IA")
            piernas, brazos = [], []
            color_pantalon = color.rgb32(24, 32, 43)
            color_media = color.rgb32(235, 239, 231)
            tonos_piel = [color.rgb32(226, 184, 151), color.rgb32(191, 139, 103),
                          color.rgb32(153, 105, 78), color.rgb32(120, 78, 59)]
            tonos_cabello = [color.rgb32(34, 30, 29), color.rgb32(76, 51, 37),
                             color.rgb32(115, 91, 59)]
            color_piel = tonos_piel[(indice + equipo * 2) % len(tonos_piel)]
            color_cabello = tonos_cabello[(indice * 2 + equipo) % len(tonos_cabello)]
            for lado in (-1, 1):
                cadera = Entity(parent=cuerpo, position=(lado * .145, .57, 0))
                piernas.append(cadera)
                Entity(parent=cadera, model=Cylinder(), color=color_media,
                       position=(0, -.18, 0), scale=(.125, .36, .13))
                Entity(parent=cadera, model="cube", color=color.rgb32(30, 34, 39),
                       position=(0, -.39, -.075), scale=(.17, .105, .27))
                Entity(parent=cadera, model="cube", color=color.rgb32(221, 224, 214),
                       position=(0, -.355, -.19), scale=(.17, .035, .035))
                brazo = Entity(parent=cuerpo, position=(lado * .255, 1.12, 0),
                               rotation_z=-lado * 8)
                brazos.append(brazo)
                Entity(parent=brazo, model=Cylinder(), color=color_camiseta,
                       position=(0, -.18, 0), scale=(.12, .39, .13))
                Entity(parent=brazo, model="sphere", color=color_piel,
                       position=(0, -.40, 0), scale=(.115, .14, .115))
            Entity(parent=cuerpo, model="sphere", color=color_pantalon,
                   position=(0, .58, 0), scale=(.37, .25, .28))
            Entity(parent=cuerpo, model="sphere", color=color_camiseta,
                   position=(0, .98, 0), scale=(.43, .53, .30))
            # Paneles del uniforme visibles desde la cámara de retransmisión.
            Entity(parent=cuerpo, model="cube", color=color_detalle,
                   position=(0, .99, -.154), scale=(.055, .48, .018))
            for lado in (-1, 1):
                Entity(parent=cuerpo, model="cube", color=color_detalle,
                       position=(lado * .185, .96, -.113), scale=(.035, .37, .015))
            Entity(parent=cuerpo, model=Cylinder(), color=color_piel,
                   position=(0, 1.30, 0), scale=(.12, .15, .12))
            Entity(parent=cuerpo, model="sphere", color=color_piel,
                   position=(0, 1.48, 0), scale=(.29, .34, .28))
            Entity(parent=cuerpo, model="sphere", color=color_cabello,
                   position=(0, 1.61, .015), scale=(.30, .16, .29))
            for lado in (-1, 1):
                Entity(parent=cuerpo, model="sphere", color=color.rgb32(34, 36, 34),
                       position=(lado * .075, 1.49, -.129), scale=(.025, .025, .018))
            dorsal = Text(str(indice + 1), parent=cuerpo, position=(0, 1.02, -.164),
                          scale=1.8, color=BLANCO, unlit=True)
            dorsal.billboard = True
            # Las hojas prerenderizadas sustituyen la malla solo en transmisión.
            # La vista cenital conserva el modelo 3D para no tumbar los sprites.
            sprite = None
            marco_base = (indice - 1) % 7
            if indice != 0 and hoja_jugadores is not None:
                margen = .015 / CUADROS_JUGADOR_3D
                sprite = Entity(
                    parent=actor, model="quad", texture=hoja_jugadores,
                    texture_scale=(.97 / CUADROS_JUGADOR_3D, 1),
                    texture_offset=(marco_base / CUADROS_JUGADOR_3D + margen, 0),
                    position=(0, .84, -.035), scale=(1.23, 1.68),
                    color=BLANCO, billboard=True, double_sided=True, unlit=True,
                    enabled=not self.vista_cenital,
                )
                cuerpo.enabled = self.vista_cenital
            self.jugadores.append({"equipo": equipo, "indice": indice, "control": control,
                                   "nombre": seleccion.once[indice], "e": actor,
                                   "casa": (x, z), "objetivo": (x, z), "stamina": 1.0,
                                   "direccion": (1.0 if equipo == 0 else -1.0, 0.0),
                                   "recarga_robo": 0.0, "piernas": piernas,
                                   "brazos": brazos, "fase": indice * 1.4,
                                   "moviendo": False, "marcador": marcador,
                                   "cuerpo": cuerpo, "sprite": sprite,
                                   "sprite_base": marco_base, "sprite_marco": marco_base,
                                   "sprite_reloj": 0.0})

    def _animar_jugadores(self, dt: float) -> None:
        """Balancea brazos y piernas mientras corren para dar vida a la escena."""
        for jugador in self.jugadores:
            if jugador["moviendo"]:
                jugador["fase"] += dt * 15.5
                paso = math.sin(jugador["fase"]) * 25
                jugador["e"].y = .025 + abs(math.sin(jugador["fase"] * 2)) * .025
                for indice, pierna in enumerate(jugador["piernas"]):
                    pierna.rotation_z = paso if indice == 0 else -paso
                for indice, brazo in enumerate(jugador["brazos"]):
                    brazo.rotation_z = (-12 if indice == 0 else 12) - (paso * .45 if indice == 0 else -paso * .45)
                sprite = jugador.get("sprite")
                if sprite is not None:
                    jugador["sprite_reloj"] += dt
                    if jugador["sprite_reloj"] >= .12:
                        jugador["sprite_reloj"] %= .12
                        jugador["sprite_marco"] = (jugador["sprite_marco"] + 1) % 7
                        sprite.texture_offset = (
                            jugador["sprite_marco"] / CUADROS_JUGADOR_3D
                            + .015 / CUADROS_JUGADOR_3D, 0
                        )
            else:
                jugador["e"].y = 0
                for indice, pierna in enumerate(jugador["piernas"]):
                    pierna.rotation_z = 0
                for indice, brazo in enumerate(jugador["brazos"]):
                    brazo.rotation_z = -12 if indice == 0 else 12

    def _crear_balon(self) -> None:
        self.balon = Entity(parent=self.arena, model="sphere", color=color.rgb32(246, 246, 233),
                            scale=.42, position=(0, .35, 0),
                            shader=lit_with_shadows_shader)
        for i in range(5):
            ang = i * math.tau / 5
            Entity(parent=self.balon, model="sphere", color=color.rgb32(35, 42, 48),
                   position=(math.cos(ang) * .28, math.sin(ang) * .20, -.04),
                   scale=.105, shader=lit_with_shadows_shader)
        self.vel_balon = Vec3(0, 0, 0)

    # ------------------------------ Controles ------------------------------
    def _movimiento(self, control: str) -> tuple[float, float, bool]:
        if control == "H1":
            dx = held_keys["d"] - held_keys["a"]
            # En Ursina +Z es hacia delante: W y Flecha arriba deben sumar Z.
            dz = held_keys["w"] - held_keys["s"]
            correr = held_keys["left shift"]
        else:
            dx = held_keys["right arrow"] - held_keys["left arrow"]
            dz = held_keys["up arrow"] - held_keys["down arrow"]
            correr = held_keys["right shift"]
        return dx, dz, bool(correr)

    def _accion(self, tecla: str) -> None:
        es_j1 = tecla in ("space", "q", "e")
        p = next((j for j in self.jugadores if j["control"] == ("H1" if es_j1 else "H2")), None)
        if p is None:
            return
        accion = "pase" if tecla in ("q", "enter") else "centro" if tecla in ("e", "u") else "tiro"
        companero = self._mejor_companero(p, solo_ataque=accion == "centro")
        self._patear(p, accion, companero)

    def _mejor_companero(self, jugador: dict, solo_ataque: bool = False) -> dict | None:
        """Busca una opción de pase adelantada y con espacio respecto a los rivales."""
        signo = 1 if jugador["equipo"] == 0 else -1
        candidatos = [q for q in self.jugadores if q["equipo"] == jugador["equipo"]
                      and q is not jugador and q["indice"] != 0]
        if solo_ataque:
            candidatos = [q for q in candidatos if signo * (q["e"].x - jugador["e"].x) > 0]
        rivales = [q for q in self.jugadores if q["equipo"] != jugador["equipo"]]
        def puntuacion(q: dict) -> float:
            avance = signo * (q["e"].x - jugador["e"].x)
            distancia = math.hypot(q["e"].x - jugador["e"].x, q["e"].z - jugador["e"].z)
            espacio = min((math.hypot(q["e"].x - r["e"].x, q["e"].z - r["e"].z)
                           for r in rivales), default=99)
            return avance * .55 - distancia * .35 + min(6, espacio) * .8
        return max(candidatos, key=puntuacion, default=None)

    def _cambiar_jugador(self, control: str, objetivo: dict | None = None) -> None:
        """Pasa el control al siguiente jugador de campo, dejando el anterior a la IA."""
        activo = next((p for p in self.jugadores if p["control"] == control), None)
        if activo is None or objetivo is activo:
            return
        ocupados = {p["indice"] for p in self.jugadores
                    if p["equipo"] == activo["equipo"] and p is not activo
                    and p["control"] in ("H1", "H2")}
        candidatos = [p for p in self.jugadores if p["equipo"] == activo["equipo"]
                      and p is not activo and p["indice"] not in ocupados]
        if not candidatos:
            return
        coincide = next((p for p in candidatos if p is objetivo), None)
        if coincide is not None:
            nuevo = coincide
        else:
            por_indice = sorted(candidatos, key=lambda p: p["indice"])
            nuevo = next((p for p in por_indice if p["indice"] > activo["indice"]), por_indice[0])
        activo["control"] = "IA"
        activo["marcador"].enabled = False
        nuevo["control"] = control
        nuevo["marcador"].enabled = True
        self.mensaje_partido = f"CONTROL · {nuevo['nombre']} · {nuevo['indice'] + 1}"
        self.mensaje_tiempo = 1.0

    def _sincronizar_controles(self) -> None:
        """Sigue la recepción del pase y cambia al defensor más cercano al balón."""
        if self.poseedor is self._poseedor_control_anterior:
            return
        self._poseedor_control_anterior = self.poseedor
        controles = sorted(c for c in ("H1", "H2")
                           if any(p["control"] == c for p in self.jugadores))
        control_del_portador = None
        if self.poseedor is not None:
            portadores_humanos = [
                (c, next((p for p in self.jugadores if p["control"] == c), None))
                for c in controles
            ]
            portadores_humanos = [(c, p) for c, p in portadores_humanos
                                  if p is not None and p["equipo"] == self.poseedor["equipo"]]
            if portadores_humanos:
                # En cooperativo, solo una persona cambia al receptor del pase.
                # El otro usuario conserva un jugador distinto para dar apoyo.
                control_del_portador, _ = min(
                    portadores_humanos,
                    key=lambda par: math.hypot(par[1]["e"].x - self.poseedor["e"].x,
                                               par[1]["e"].z - self.poseedor["e"].z))
                self._cambiar_jugador(control_del_portador, self.poseedor)
        for control in controles:
            activo = next((p for p in self.jugadores if p["control"] == control), None)
            if activo is None or control == control_del_portador:
                continue
            if self.poseedor is not None and self.poseedor["equipo"] == activo["equipo"]:
                # El segundo usuario mantiene el control de un compañero diferente.
                continue
            if activo["indice"] == 0:
                # Si el usuario tomó al arquero, lo conserva mientras defiende.
                continue
            ocupados = {p["indice"] for p in self.jugadores
                        if p["equipo"] == activo["equipo"] and p is not activo
                        and p["control"] in ("H1", "H2")}
            opciones = [p for p in self.jugadores if p["equipo"] == activo["equipo"]
                        and p["indice"] != 0 and p is not activo
                        and p["indice"] not in ocupados]
            cercano = min(opciones, key=lambda p: math.hypot(
                p["e"].x - self.balon.x, p["e"].z - self.balon.z), default=None)
            if cercano:
                self._cambiar_jugador(control, cercano)

    def _robar(self, control: str) -> None:
        """El usuario disputa la posesión cerca del portador o recoge un balón dividido."""
        p = next((j for j in self.jugadores if j["control"] == control), None)
        if p is None:
            return
        objetivo = self.poseedor
        bx, bz = ((objetivo["e"].x, objetivo["e"].z) if objetivo
                  else (self.balon.x, self.balon.z))
        distancia = math.hypot(p["e"].x - bx, p["e"].z - bz)
        if objetivo is not None and objetivo["equipo"] != p["equipo"] and distancia < 1.35:
            self.poseedor = p
            p["recarga_robo"] = .65
            self.vel_balon = Vec3(0, 0, 0)
        elif objetivo is None and distancia < 1.15:
            self.poseedor = p
            self.vel_balon = Vec3(0, 0, 0)

    def _patear(self, p: dict, accion: str, companero: dict | None = None) -> None:
        if math.hypot(p["e"].x - self.balon.x, p["e"].z - self.balon.z) > 1.55:
            return
        if self.poseedor is not None and self.poseedor["equipo"] != p["equipo"]:
            return
        signo = 1 if p["equipo"] == 0 else -1
        if accion == "pase" and companero:
            dx = companero["e"].x + companero["direccion"][0] * .8 - self.balon.x
            dz = companero["e"].z + companero["direccion"][1] * .8 - self.balon.z
            potencia = 7.2
            altura = 1.4
        elif accion == "centro":
            # Balón bombeado desde el carril hacia la zona de remate.
            meta_x = 9.5 if p["equipo"] == 0 else -9.5
            dx, dz = meta_x - self.balon.x, (companero["e"].z if companero else 0) - self.balon.z
            potencia = 8.1
            altura = 5.2
        elif accion == "pase":
            # Sin compañero cercano, el usuario puede filtrar el balón al espacio.
            dx, dz = p["direccion"]
            potencia = 6.3
            altura = .9
        else:
            teclas = {"H1": ("d", "a", "s", "w"),
                      "H2": ("right arrow", "left arrow", "down arrow", "up arrow")}
            if p["control"] in teclas:
                derecha, izquierda, abajo, arriba = teclas[p["control"]]
                dx = held_keys[derecha] - held_keys[izquierda]
                dz = held_keys[arriba] - held_keys[abajo]
                if math.hypot(dx, dz) > 0:
                    largo_aim = math.hypot(dx, dz)
                    p["direccion"] = (dx / largo_aim, dz / largo_aim)
            dx, dz = p["direccion"]
            potencia = 10.5
            altura = 3.3
        largo = max(.001, math.hypot(dx, dz))
        self.vel_balon = Vec3(dx / largo * potencia, altura, dz / largo * potencia)
        self.poseedor = None
        self.ultimo_golpeador = p
        self.audio.efecto("balon")
        self.audio.jugada(p["nombre"], accion)
        if self.ia:
            self.ia.log.action(p["equipo"], p["nombre"], accion, self.tiempo)

    def input(self, key: str) -> None:
        if key == "escape":
            if self.estado == "partido":
                if self.pausa or self.fin:
                    self._volver_al_menu()
                else:
                    self.pausa = True
                    self._actualizar_overlay_partido()
            else:
                self.audio.cerrar()
                application.quit()
        elif self.estado == "menu" and key in ("1", "2", "3", "4"):
            self.iniciar(int(key))
        elif self.estado == "menu" and key in ("a", "d", "left arrow", "right arrow"):
            equipo = 0 if key in ("a", "d") else 1
            paso = 1 if key in ("d", "right arrow") else -1
            self.cambiar_pais(equipo, paso)
        elif self.estado == "menu" and key == "r":
            equipo_ia = 1 if self.modo in (1, 2) else 0
            opciones = [i for i in range(len(SELECCIONES)) if i != self.pais_indices[1 - equipo_ia]]
            self.pais_indices[equipo_ia] = random.choice(opciones)
            self.cambiar_pais(equipo_ia, 0)
        elif key == "v" and self.estado == "partido" and not self.pausa and not self.fin:
            self._alternar_vista()
        elif self.estado == "partido":
            if key == "p" and not self.fin:
                self.pausa = not self.pausa
                self._actualizar_overlay_partido()
            elif key == "r":
                self._reiniciar_partido()
            elif key in ("space", "q", "e", "right control", "enter", "u") and not self.pausa and not self.fin:
                self._accion(key)
            elif key in ("f", "right alt") and not self.pausa and not self.fin:
                self._robar("H1" if key == "f" else "H2")
            elif key == "tab" and not self.pausa and not self.fin:
                self._cambiar_jugador("H1")
            elif key == "backspace" and not self.pausa and not self.fin:
                self._cambiar_jugador("H2")

    # -------------------------------- Bucle ---------------------------------
    def update(self) -> None:
        if self.estado != "partido" or self.pausa or self.fin:
            self._actualizar_hud()
            return
        dt = min(time.dt, .04)
        self.tiempo += dt
        # Desplazamiento de transmisión muy leve: mantiene la jugada centrada
        # sin mover la vista cenital táctica.
        if not self.vista_cenital:
            objetivo_camara = Vec3(clamp(self.balon.x * .12, -1.4, 1.4),
                                   23, -29 + clamp(self.balon.z * .10, -.8, .8))
            camera.position += (objetivo_camara - camera.position) * min(1.0, dt * 1.8)
        self.mensaje_tiempo = max(0.0, self.mensaje_tiempo - dt)
        self.reloj_partido = max(0.0, self.reloj_partido - dt)
        for p in self.jugadores:
            if p["control"] == "IA":
                continue
            dx, dz, sprint = self._movimiento(p["control"])
            magnitud = math.hypot(dx, dz)
            p["moviendo"] = magnitud > 0
            if magnitud:
                dx, dz = dx / magnitud, dz / magnitud
                velocidad = 9.2 if sprint and p["stamina"] > .06 else 7.0
                if self.poseedor is p:
                    velocidad *= .90
                p["e"].x = clamp(p["e"].x + dx * velocidad * dt, -11.4, 11.4)
                p["e"].z = clamp(p["e"].z + dz * velocidad * dt, -6.4, 6.4)
                p["direccion"] = (dx, dz)
                # El modelo mira hacia -Z en reposo; se orienta al vector de movimiento.
                p["e"].rotation_y = math.degrees(math.atan2(-dx, -dz))
                p["stamina"] = max(0.0, p["stamina"] - dt * (.22 if sprint else .07))
            else:
                p["stamina"] = min(1.0, p["stamina"] + dt * .15)

        for p in self.jugadores:
            p["recarga_robo"] = max(0.0, p["recarga_robo"] - dt)
        self._actualizar_ia(dt)
        self._animar_jugadores(dt)
        self._actualizar_posesion(dt)
        self._sincronizar_controles()
        if self.poseedor is not None:
            pais = obtener_seleccion(self.pais_indices[self.poseedor["equipo"]]).nombre
            self.audio.posesion(self.poseedor["nombre"], pais, self.tiempo)
        self._actualizar_balon(dt)
        if self.reloj_partido <= 0:
            self.fin = True
            if self.ia:
                self.ia.log.finish()
        self._actualizar_hud()

    def _actualizar_ia(self, dt: float) -> None:
        if not self.ia:
            return
        self.temporizador_ia -= dt
        if self.temporizador_ia <= 0:
            self.temporizador_ia = .22
            por_equipo = {t: [p for p in self.jugadores
                              if p["equipo"] == t and p["control"] == "IA"] for t in (0, 1)}
            for equipo, miembros in por_equipo.items():
                if not miembros:
                    continue
                signo = 1 if equipo == 0 else -1
                portador = self.poseedor
                rivales = [q for q in self.jugadores if q["equipo"] != equipo]
                cazador = min(miembros, key=lambda q: math.hypot(
                    q["e"].x - self.balon.x, q["e"].z - self.balon.z))
                actor_ia = portador if any(portador is q for q in miembros) else cazador
                compañero = self._mejor_companero(actor_ia)
                accion, prediccion = self.ia.decide(
                    (self.balon.x / 12, self.balon.z / 7, clamp(self.balon.y / 3, 0, 1)),
                    (actor_ia["e"].x / 12, actor_ia["e"].z / 7),
                    (compañero["e"].x / 12, compañero["e"].z / 7) if compañero else None,
                    signo)
                for p in miembros:
                    if p["indice"] == 0:
                        p["objetivo"] = (-10.8 if equipo == 0 else 10.8,
                                          clamp(self.balon.z * .24, -1.25, 1.25))
                    elif portador is p:
                        meta = 12.0 if equipo == 0 else -12.0
                        distancia_meta = abs(meta - p["e"].x)
                        presion = min((math.hypot(p["e"].x - r["e"].x,
                                                  p["e"].z - r["e"].z) for r in rivales), default=99)
                        distancia_balon = math.hypot(p["e"].x - self.balon.x,
                                                     p["e"].z - self.balon.z)
                        if distancia_balon < 1.55 and distancia_meta < 5.2:
                            self._patear(p, "tiro", compañero)
                        elif distancia_balon < 1.55 and compañero and (
                                (presion < 1.65 and accion == "pase") or
                                (distancia_meta < 8.0 and abs(p["e"].z) > 2.4)):
                            tipo = "centro" if distancia_meta < 8 and abs(p["e"].z) > 2.4 else "pase"
                            self._patear(p, tipo, self._mejor_companero(p, solo_ataque=tipo == "centro"))
                        else:
                            p["objetivo"] = (clamp(p["e"].x + signo * 1.9, -10.8, 10.8),
                                              clamp(p["e"].z * .88, -5.9, 5.9))
                    elif portador and portador["equipo"] != equipo:
                        presionador = min(miembros, key=lambda q: math.hypot(
                            q["e"].x - portador["e"].x, q["e"].z - portador["e"].z))
                        if p is presionador:
                            p["objetivo"] = (portador["e"].x, portador["e"].z)
                        else:
                            p["objetivo"] = (clamp(p["casa"][0] + (self.balon.x - p["casa"][0]) * .13,
                                                   -10.8, 10.8),
                                              clamp(p["casa"][1] + (self.balon.z - p["casa"][1]) * .18,
                                                   -5.9, 5.9))
                    elif portador is None and p is cazador:
                        p["objetivo"] = (clamp(prediccion[0] * 12, -10.8, 10.8),
                                          clamp(prediccion[1] * 7, -5.9, 5.9))
                    else:
                        empuje = 2.5 if portador and portador["equipo"] == equipo else -.9
                        p["objetivo"] = (clamp(p["casa"][0] + signo * empuje + self.balon.x * .10,
                                               -10.8, 10.8),
                                          clamp(p["casa"][1] + self.balon.z * .12,
                                               -5.9, 5.9))
        for p in self.jugadores:
            if p["control"] != "IA":
                continue
            dx, dz = p["objetivo"][0] - p["e"].x, p["objetivo"][1] - p["e"].z
            distancia = math.hypot(dx, dz)
            if distancia > .08:
                velocidad = min(6.4, distancia * 3.0)
                nx, nz = dx / distancia, dz / distancia
                p["moviendo"] = True
                p["e"].x += nx * velocidad * dt
                p["e"].z += nz * velocidad * dt
                p["direccion"] = (nx, nz)
                p["e"].rotation_y = math.degrees(math.atan2(-nx, -nz))
            else:
                p["moviendo"] = False

    def _actualizar_posesion(self, dt: float) -> None:
        """Pega el balón al portador y permite intercepciones y recuperaciones."""
        if self.poseedor is not None:
            p = self.poseedor
            dx, dz = p["direccion"]
            self.balon.position = (p["e"].x + dx * .72, .42, p["e"].z + dz * .72)
            self.vel_balon = Vec3(0, 0, 0)
            # La defensa de la máquina intenta recuperar el balón al entrar en rango.
            for defensor in self.jugadores:
                if (defensor["control"] == "IA" and defensor["equipo"] != p["equipo"]
                        and defensor["recarga_robo"] <= 0 and p["recarga_robo"] <= 0
                        and math.hypot(defensor["e"].x - p["e"].x,
                                       defensor["e"].z - p["e"].z) < .78):
                    self.poseedor = defensor
                    defensor["recarga_robo"] = .8
                    break
            if self.poseedor is not None:
                return

        velocidad = math.hypot(self.vel_balon.x, self.vel_balon.z)
        receptor = min(self.jugadores, key=lambda q: math.hypot(
            q["e"].x - self.balon.x, q["e"].z - self.balon.z), default=None)
        umbral = .78 if velocidad < 5.0 else .48
        if (receptor and self.balon.y < 1.25
                and math.hypot(receptor["e"].x - self.balon.x,
                               receptor["e"].z - self.balon.z) < umbral):
            self.poseedor = receptor
            self.vel_balon = Vec3(0, 0, 0)

    def _actualizar_balon(self, dt: float) -> None:
        if self.poseedor is not None:
            return
        self.vel_balon.y -= 9.8 * dt
        self.balon.position += self.vel_balon * dt
        self.balon.rotation_x += self.vel_balon.z * dt * 70
        self.balon.rotation_z -= self.vel_balon.x * dt * 70
        if self.balon.y < .34:
            self.balon.y = .34
            self.vel_balon.y = abs(self.vel_balon.y) * .40
            self.vel_balon.x *= .985
            self.vel_balon.z *= .985
        if abs(self.balon.z) > 6.75:
            self.balon.z = clamp(self.balon.z, -6.75, 6.75)
            self.vel_balon.z *= -.62
        if abs(self.balon.x) > 12.35:
            if abs(self.balon.z) < 1.72 and self.balon.y < 2.05:
                equipo = 0 if self.balon.x > 0 else 1
                autor = self.ultimo_golpeador
                if self.ia:
                    self.ia.log.goal(equipo, autor["nombre"] if autor else "Equipo", self.tiempo)
                    pais_goleador = obtener_seleccion(self.pais_indices[equipo]).nombre
                    self.audio.gol(autor["nombre"] if autor else "el equipo", pais_goleador)
                    if max(self.ia.log.score.values()) >= 5:
                        self.fin = True
                        self.ia.log.finish()
                equipo_saque = 1 - equipo
                self._iniciar_saque(equipo_saque)
                self.mensaje_partido = (
                    f"¡GOL {obtener_seleccion(self.pais_indices[equipo]).nombre.upper()}!  ·  "
                    f"SAQUE {obtener_seleccion(self.pais_indices[equipo_saque]).nombre.upper()}"
                )
                self.mensaje_tiempo = 2.4
            else:
                self.balon.x = math.copysign(12.35, self.balon.x)
                self.vel_balon.x *= -.62

    def _actualizar_hud(self) -> None:
        if not self.hud_widgets or not self.ia:
            return
        _, marcador, ayuda, etiqueta = self.hud_widgets
        minutos, segundos = divmod(int(self.reloj_partido), 60)
        pais0 = obtener_seleccion(self.pais_indices[0])
        pais1 = obtener_seleccion(self.pais_indices[1])
        marcador.text = (f"{pais0.sigla}   {self.ia.log.score[0]}     ·     "
                         f"{self.ia.log.score[1]}   {pais1.sigla}       "
                         f"{minutos:02}:{segundos:02}")
        if self.panel_marcador is not None:
            self.panel_marcador.text = (f"{pais0.sigla}  {self.ia.log.score[0]}  —  "
                                        f"{self.ia.log.score[1]}  {pais1.sigla}")
        ayuda.text = "J1 WASD · SPACE tiro · Q pase · E centro · F robo · TAB cambia · SHIFT corre\n" \
                     "J2 FLECHAS · CTRL DER. tiro · ENTER pase · U centro · ALT robo · BKSP cambia · SHIFT DER. corre\n" \
                     "P pausa · R reinicia · ESC menú/pausa · V cámara"
        posesion = (obtener_seleccion(self.pais_indices[self.poseedor["equipo"]]).sigla
                    if self.poseedor else "DIVIDIDA")
        vista = "CENITAL 2D" if self.vista_cenital else "TRANSMISIÓN 3D"
        nombre_poseedor = f" · {self.poseedor['nombre']}" if self.poseedor else ""
        etiqueta.text = f"{MODOS[self.modo].upper()} · {vista} · BALÓN {posesion}{nombre_poseedor}"
        if self.mensaje_tiempo > 0 and self.mensaje_partido:
            etiqueta.text = self.mensaje_partido
        if self.pausa:
            etiqueta.text = "PAUSA  ·  P continúa  ·  R reinicia  ·  ESC menú"
        elif self.fin:
            etiqueta.text = "FINAL  ·  R reinicia  ·  ESC menú"
        self._actualizar_overlay_partido()


if __name__ == "__main__":
    app = Ursina(title="PITCH / Fútbol 3D con IA", fullscreen=False,
                 size=(1440, 810), development_mode=False,
                 editor_ui_enabled=False)
    juego = Juego3D()
    app.run()

