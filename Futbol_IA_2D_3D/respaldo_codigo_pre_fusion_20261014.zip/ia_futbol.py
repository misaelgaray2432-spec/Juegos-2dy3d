"""IA compartida: decisiones sklearn, movimiento Keras e historial Pandas."""
from datetime import datetime
from pathlib import Path
import uuid
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
try:
    import keras
except Exception as error:  # TensorFlow puede fallar al cargar DLL en algunos equipos.
    keras = None
    print(f"Aviso: Keras no disponible ({type(error).__name__}); se usará movimiento de respaldo.")

MODOS = {1:"Humano vs PC", 2:"Humano vs Humano", 3:"1 IA vs 2 humanos", 4:"2 IA vs 2 humanos"}

def clamp(x, lo, hi):
    return float(np.clip(x, lo, hi))

class IAFutbol:
    def __init__(self):
        rng = np.random.default_rng(7)
        rows, labels = [], []
        for _ in range(3000):
            bx,bz,ax,az,tx,tz = rng.uniform(-1,1),rng.uniform(-.9,.9),rng.uniform(-1,1),rng.uniform(-.9,.9),rng.uniform(-1,1),rng.uniform(-.9,.9)
            da,dc,dg = np.hypot(bx-ax,bz-az),np.hypot(bx-tx,bz-tz),np.hypot(1-bx,bz)
            label = "apoyo" if dc+.08<da else "tiro" if dg<.34 and da<.24 else "pase" if da<.19 and dc<.4 and tx>bx+.18 else "defender" if bx<-.2 and da>.2 else "perseguir"
            rows.append(self.features(bx,bz,0,ax,az,tx,tz,dc)); labels.append(label)
        self.policy = make_pipeline(StandardScaler(), LogisticRegression(max_iter=300,class_weight="balanced")).fit(rows,labels)
        bx,yy,bz = rng.uniform(-1,1,3000),rng.uniform(0,1,3000),rng.uniform(-1,1,3000)
        target = np.column_stack([np.clip(.78*bx+np.where(bx>=0,.12,-.10)+.035*yy,-.85,.85),np.clip(bz*(.78-.1*yy),-.8,.8)])
        self.net = None
        if keras is not None:
            try:
                self.net = keras.Sequential([
                    keras.layers.Input((3,)),
                    keras.layers.Dense(20, activation="relu"),
                    keras.layers.Dense(12, activation="relu"),
                    keras.layers.Dense(2, activation="tanh"),
                ])
                self.net.compile(optimizer="adam", loss="mse")
                self.net.fit(np.column_stack([bx, yy, bz]), target,
                             epochs=4, batch_size=64, verbose=0)
            except Exception as error:
                self.net = None
                print(f"Aviso: no se pudo entrenar Keras ({type(error).__name__}); se usará movimiento de respaldo.")
        self.log = MatchLog()

    @staticmethod
    def features(bx,bz,y,ax,az,tx,tz,dc):
        return [bx,bz,y,ax,az,tx,tz,np.hypot(bx-ax,bz-az),dc,np.hypot(1-bx,bz)]

    def decide(self, ball, actor, mate, sign):
        bx,bz = ball[0]*sign,ball[1]; ax,az = actor[0]*sign,actor[1]
        if mate is None: tx,tz,dc=ax,az,3.0
        else:
            tx,tz=mate[0]*sign,mate[1]; dc=float(np.hypot(bx-tx,bz-tz))
        action=str(self.policy.predict([self.features(bx,bz,ball[2],ax,az,tx,tz,dc)])[0])
        # La llamada directa evita la sobrecarga de Model.predict() en el bucle
        # del juego y mantiene la inferencia de Keras ligera por frame.
        if self.net is not None:
            pred = self.net(
                np.asarray([[bx, ball[2], bz]], dtype=np.float32), training=False
            ).numpy()[0]
        else:
            # Aproxima el objetivo con la misma regla usada para generar los
            # datos sintéticos de entrenamiento de Keras.
            pred = np.asarray([
                np.clip(.78 * bx + (.12 if bx >= 0 else -.10) + .035 * ball[2], -.85, .85),
                np.clip(bz * (.78 - .1 * ball[2]), -.8, .8),
            ], dtype=np.float32)
        return action,(clamp(pred[0]*sign,-.9,.9),clamp(pred[1],-.85,.85))

class MatchLog:
    def __init__(self):
        self.folder=Path(__file__).resolve().parent/"data"; self.folder.mkdir(exist_ok=True)
        self.matches=self.read("partidos.csv",["id","fecha","modo","goles_0","goles_1","resultado"])
        self.events=self.read("eventos.csv",["id","segundo","equipo","pais","jugador","evento"])
        self.players=self.read("jugadores.csv",["id","equipo","pais","jugador","goles","tiros","pases","centros"])
        self.start(1)
    def read(self,name,cols):
        p=self.folder/name
        return pd.read_csv(p) if p.exists() else pd.DataFrame(columns=cols)
    def start(self,mode,selecciones=("Local", "Visitante")):
        self.id=uuid.uuid4().hex[:12]; self.mode=mode; self.when=datetime.now()
        self.selecciones=selecciones
        self.score={0:0,1:0}; self.stats={}; self.done=False
    def event(self,team,player,action,seconds):
        row={"id":self.id,"segundo":round(seconds,2),"equipo":team,
             "pais":self.selecciones[team],"jugador":player,"evento":action}
        self.events=pd.concat([self.events,pd.DataFrame([row])],ignore_index=True)
    def action(self,team,player,action,seconds):
        if action not in ("tiro","pase","centro"): return
        key=(team,player)
        self.stats.setdefault(key,{"goles":0,"tiros":0,"pases":0,"centros":0})
        columna={"tiro":"tiros","pase":"pases","centro":"centros"}[action]
        self.stats[key][columna]+=1
        self.event(team,player,action,seconds)
    def goal(self,team,player,seconds):
        self.score[team]+=1; key=(team,player)
        self.stats.setdefault(key,{"goles":0,"tiros":0,"pases":0,"centros":0}); self.stats[key]["goles"]+=1
        self.event(team,player,"gol",seconds)
    def finish(self):
        if self.done: return
        result="empate" if self.score[0]==self.score[1] else ("gana_equipo_0" if self.score[0]>self.score[1] else "gana_equipo_1")
        row={"id":self.id,"fecha":self.when.isoformat(timespec="seconds"),"modo":MODOS[self.mode],
             "pais_0":self.selecciones[0],"pais_1":self.selecciones[1],
             "goles_0":self.score[0],"goles_1":self.score[1],"resultado":result}
        self.matches=pd.concat([self.matches,pd.DataFrame([row])],ignore_index=True)
        rows=[{"id":self.id,"equipo":t,"pais":self.selecciones[t],"jugador":p,**s}
              for (t,p),s in self.stats.items()]
        if rows: self.players=pd.concat([self.players,pd.DataFrame(rows)],ignore_index=True)
        self.matches.to_csv(self.folder/"partidos.csv",index=False); self.events.to_csv(self.folder/"eventos.csv",index=False); self.players.to_csv(self.folder/"jugadores.csv",index=False)
        self.done=True

