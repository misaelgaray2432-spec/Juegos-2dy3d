"""Edición volumétrica de fútbol Ursina, separada del lanzador 3D original."""
from __future__ import annotations

import argparse
import importlib.util
import math
import sys
from pathlib import Path

RAIZ_PROYECTO = Path(__file__).resolve().parent
if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))

_BASE_SPEC = importlib.util.spec_from_file_location(
    "_juego_3d_base", RAIZ_PROYECTO / "juego_3d_base.py"
)
if _BASE_SPEC is None or _BASE_SPEC.loader is None:
    raise ImportError("No se encontró el juego Ursina de la raíz del proyecto.")
_BASE_MODULO = importlib.util.module_from_spec(_BASE_SPEC)
sys.modules[_BASE_SPEC.name] = _BASE_MODULO
_BASE_SPEC.loader.exec_module(_BASE_MODULO)
Juego3DBase = _BASE_MODULO.Juego3D

# El módulo de IA del juego base se carga antes de Panda/Ursina para respetar
# el orden de DLL que ya usa el proyecto en Windows.
from ursina import (Entity, Ursina, Vec3, application, camera, color, held_keys,
                    invoke, time, window)  # noqa: E402
from animador_procedural import AnimadorProcedural  # noqa: E402
from estadio_procedural import construir_detalle_estadio  # noqa: E402


RADIO_BALON = .21
RADIO_POSTE_MAS_BALON = .30
RADIO_TRAVESAÑO_MAS_BALON = .32


def producto(a: Vec3, b: Vec3) -> float:
    return float(a.x * b.x + a.y * b.y + a.z * b.z)


def distancia_horizontal(x: float, z: float) -> float:
    return math.hypot(x, z)


class Juego3DVolumetrico(Juego3DBase):
    """Amplía el partido existente con atletas, graderías y físicas volumétricas."""

    def __init__(self) -> None:
        self._cuenta_gradas: dict[str, int] = {}
        super().__init__()

        # El partido ya tiene modelos geométricos de futbolistas. Se desactiva
        # la creación de recortes solo en esta instancia de la clase base.
        self.recursos_3d.hoja_jugadores = lambda _equipo, _camiseta: None
        self.recursos_3d.textura_portero = lambda _equipo: None
        self._cuenta_gradas = construir_detalle_estadio(
            self.arena, Entity=Entity, color=color
        )

    def _multitud(self) -> None:
        """Sustituye las tiras decorativas del público por figuras con volumen."""
        anteriores = {id(entidad) for entidad in self.arena.children}
        super()._multitud()
        for entidad in self.arena.children:
            if id(entidad) not in anteriores:
                entidad.enabled = False

    def _crear_jugadores(self) -> None:
        super()._crear_jugadores()
        for jugador in self.jugadores:
            jugador["sprite"] = None
            jugador["cuerpo"].enabled = True
            jugador["sombra"].enabled = True
            jugador["velocidad_anim"] = 0.0
            jugador["animador"] = AnimadorProcedural(jugador)
            if jugador["indice"] == 0:
                x_guardameta = -11.25 if jugador["equipo"] == 0 else 11.25
                jugador["e"].x = x_guardameta
                jugador["casa"] = (x_guardameta, jugador["casa"][1])
                jugador["objetivo"] = jugador["casa"]

    def _actualizar_ia(self, dt: float) -> None:
        """Conserva la IA existente y da funciones individuales al modo 4."""
        posiciones = {
            id(j): (float(j["e"].x), float(j["e"].z)) for j in self.jugadores
        }
        super()._actualizar_ia(dt)

        if self.modo == 4:
            # Dos atacantes de la PC se coordinan por separado: uno presiona o
            # desmarca y otro apoya o cubre al rival con el balón.
            atacantes = [
                p for p in self.jugadores
                if p["equipo"] == 0 and p["indice"] in (9, 10)
                and p["control"] == "IA"
            ]
            portador = self.poseedor
            if portador is None:
                cazador = min(
                    atacantes,
                    key=lambda p: distancia_horizontal(
                        p["e"].x - self.balon.x, p["e"].z - self.balon.z
                    ),
                    default=None,
                )
                for p in atacantes:
                    if p is cazador:
                        p["objetivo"] = (
                            float(self.balon.x + self.vel_balon.x * .16),
                            float(self.balon.z + self.vel_balon.z * .16),
                        )
                    else:
                        p["objetivo"] = (
                            float(self.balon.x - 1.5), float(-self.balon.z * .65)
                        )
            elif portador["equipo"] == 0:
                for p in atacantes:
                    if p is portador:
                        p["objetivo"] = (float(p["e"].x), float(p["e"].z))
                    elif p["indice"] == 10:
                        p["objetivo"] = (
                            min(10.6, float(portador["e"].x + 3.0)),
                            float(portador["e"].z * .55),
                        )
                    else:
                        p["objetivo"] = (
                            float(portador["e"].x - 1.0),
                            float(-portador["e"].z * .8),
                        )
            else:
                rivales = [
                    p for p in self.jugadores
                    if p["equipo"] == 1 and p["indice"] != 0
                ]
                marcado = min(
                    rivales,
                    key=lambda p: distancia_horizontal(
                        p["e"].x - portador["e"].x,
                        p["e"].z - portador["e"].z,
                    ),
                    default=None,
                )
                for p in atacantes:
                    objetivo = marcado if p["indice"] == 9 else portador
                    if objetivo:
                        p["objetivo"] = (
                            float(objetivo["e"].x), float(objetivo["e"].z)
                        )

        for portero in self.jugadores:
            if portero["indice"] != 0:
                continue
            if portero["control"] == "IA":
                x_meta = -11.25 if portero["equipo"] == 0 else 11.25
                z_meta = max(-1.42, min(1.42, float(self.balon.z) * .43))
                portero["objetivo"] = (x_meta, z_meta)
                paso = min(1.0, dt * 7.0)
                portero["e"].x += (x_meta - portero["e"].x) * paso
                portero["e"].z += (z_meta - portero["e"].z) * paso

                se_acerca = (
                    self.vel_balon.x < -4.0 if portero["equipo"] == 0
                    else self.vel_balon.x > 4.0
                )
                if (
                    self.poseedor is None and se_acerca
                    and abs(float(portero["e"].x - self.balon.x)) < 4.0
                    and self.balon.y < 2.2
                    and abs(float(self.balon.z - portero["e"].z)) < 2.1
                    and portero["animador"].tiempo_restante <= 0
                ):
                    diferencia = float(self.balon.z - portero["e"].z)
                    estado = "portero_salto" if self.balon.y > 1.0 else "portero_estirada"
                    portero["animador"].activar(
                        estado, .62, direccion=1 if diferencia >= 0 else -1
                    )

        if dt > 0:
            for jugador in self.jugadores:
                anterior = posiciones.get(id(jugador))
                if anterior is not None:
                    jugador["velocidad_anim"] = distancia_horizontal(
                        float(jugador["e"].x) - anterior[0],
                        float(jugador["e"].z) - anterior[1],
                    ) / dt

    def _animar_jugadores(self, dt: float) -> None:
        super()._animar_jugadores(dt)
        for jugador in self.jugadores:
            jugador["animador"].actualizar(jugador, dt)

    def _patear(self, jugador: dict, accion: str, companero: dict | None = None) -> None:
        super()._patear(jugador, accion, companero)
        if self.ultimo_golpeador is jugador:
            animacion = {"pase": "pase", "centro": "centro", "tiro": "disparo"}.get(
                accion, "disparo"
            )
            jugador["animador"].activar(
                animacion, .46 if accion == "tiro" else .38
            )

    def _iniciar_saque(self, equipo: int) -> None:
        super()._iniciar_saque(equipo)
        for jugador in self.jugadores:
            if jugador.get("animador"):
                jugador["animador"].activar("espera", .01)

    def _colisionar_con_porteros(self, anterior: Vec3, siguiente: Vec3) -> bool:
        """Resuelve el contacto del balón con el cuerpo geométrico del portero."""
        movimiento = siguiente - anterior
        plano = Vec3(movimiento.x, 0, movimiento.z)
        longitud2 = max(.00001, producto(plano, plano))
        for portero in self.jugadores:
            if portero["indice"] != 0:
                continue
            centro = portero["e"].position + Vec3(0, .93, 0)
            origen_plano = Vec3(anterior.x, 0, anterior.z)
            centro_plano = Vec3(centro.x, 0, centro.z)
            t = max(
                0.0,
                min(1.0, producto(centro_plano - origen_plano, plano) / longitud2),
            )
            cercano = anterior + movimiento * t
            diferencia = Vec3(cercano.x - centro.x, 0, cercano.z - centro.z)
            distancia = diferencia.length()
            acercamiento = producto(self.vel_balon, diferencia)
            if (
                distancia >= .69 or not .21 <= cercano.y <= 1.94
                or (distancia > .0001 and acercamiento >= 0)
            ):
                continue
            normal = (
                diferencia.normalized() if distancia > .0001
                else Vec3(-1 if self.vel_balon.x > 0 else 1, 0, 0)
            )
            siguiente += normal * (.69 - distancia + .015)
            componente = producto(self.vel_balon, normal)
            self.vel_balon -= normal * (1.55 * componente)
            self.vel_balon *= .72
            estado = "portero_salto" if cercano.y > 1.0 else "portero_estirada"
            portero["animador"].activar(
                estado, .62, direccion=1 if self.balon.z >= portero["e"].z else -1
            )
            return True
        return False

    def _colisionar_con_marcos(self, anterior: Vec3, siguiente: Vec3) -> bool:
        """Prueba el segmento de vuelo contra postes y travesaños de ambas metas."""
        movimiento = siguiente - anterior
        hubo_contacto = False
        for lado in (-1, 1):
            x_meta = lado * 12.35

            # Postes verticales: distancia del segmento del balón a una cápsula.
            movimiento_plano = Vec3(movimiento.x, 0, movimiento.z)
            longitud2 = max(.00001, producto(movimiento_plano, movimiento_plano))
            for z_poste in (-1.70, 1.70):
                centro = Vec3(x_meta, 0, z_poste)
                origen = Vec3(anterior.x, 0, anterior.z)
                t = max(
                    0.0,
                    min(1.0, producto(centro - origen, movimiento_plano) / longitud2),
                )
                punto = anterior + movimiento * t
                eje = Vec3(x_meta, max(.05, min(1.85, punto.y)), z_poste)
                diferencia = punto - eje
                distancia = diferencia.length()
                if distancia < RADIO_POSTE_MAS_BALON:
                    normal = (
                        diferencia.normalized() if distancia > .0001
                        else Vec3(-1 if self.vel_balon.x > 0 else 1, 0, 0)
                    )
                    siguiente += normal * (RADIO_POSTE_MAS_BALON - distancia + .01)
                    componente = producto(self.vel_balon, normal)
                    if componente < 0:
                        self.vel_balon -= normal * (1.55 * componente)
                    self.vel_balon *= .76
                    hubo_contacto = True

            # Travesaño horizontal, limitado al tramo entre los postes.
            movimiento_xy = Vec3(movimiento.x, movimiento.y, 0)
            longitud_xy2 = max(.00001, producto(movimiento_xy, movimiento_xy))
            hacia_eje = Vec3(x_meta - anterior.x, 1.90 - anterior.y, 0)
            t_barra = max(
                0.0, min(1.0, producto(hacia_eje, movimiento_xy) / longitud_xy2)
            )
            punto_barra = anterior + movimiento * t_barra
            z_barra = max(-1.75, min(1.75, float(punto_barra.z)))
            eje_barra = Vec3(x_meta, 1.90, z_barra)
            diferencia_barra = punto_barra - eje_barra
            distancia_barra = diferencia_barra.length()
            if distancia_barra < RADIO_TRAVESAÑO_MAS_BALON:
                normal = (
                    diferencia_barra.normalized() if distancia_barra > .0001
                    else Vec3(-1 if self.vel_balon.x > 0 else 1, 0, 0)
                )
                siguiente += normal * (
                    RADIO_TRAVESAÑO_MAS_BALON - distancia_barra + .01
                )
                componente = producto(self.vel_balon, normal)
                if componente < 0:
                    self.vel_balon -= normal * (1.55 * componente)
                self.vel_balon *= .76
                hubo_contacto = True
        return hubo_contacto

    def _registrar_gol(self, equipo: int) -> None:
        autor = self.ultimo_golpeador
        if self.ia:
            self.ia.log.goal(
                equipo, autor["nombre"] if autor else "Equipo", self.tiempo
            )
            pais = self.obtener_nombre_pais(self.pais_indices[equipo])
            self.audio.gol(autor["nombre"] if autor else "el equipo", pais)
            if max(self.ia.log.score.values()) >= 5:
                self.fin = True
                self.ia.log.finish()

        saque = 1 - equipo
        nombre_goleador = self.obtener_nombre_pais(self.pais_indices[equipo])
        nombre_saque = self.obtener_nombre_pais(self.pais_indices[saque])
        self._iniciar_saque(saque)
        self.mensaje_partido = (
            f"¡GOL {nombre_goleador.upper()}!  ·  SAQUE {nombre_saque.upper()}"
        )
        self.mensaje_tiempo = 2.4
        if autor and autor.get("animador"):
            autor["animador"].activar("celebracion", 1.7)

    @staticmethod
    def obtener_nombre_pais(indice: int) -> str:
        from selecciones import obtener_seleccion
        return obtener_seleccion(indice).nombre

    def _actualizar_balon(self, dt: float) -> None:
        """Integra la esfera y resuelve rebotes, atajadas, postes y goles."""
        if self.poseedor is not None:
            return

        anterior = Vec3(self.balon.x, self.balon.y, self.balon.z)
        self.vel_balon.y -= 9.8 * dt
        siguiente = anterior + self.vel_balon * dt
        self.balon.rotation_x += self.vel_balon.z * dt * 70
        self.balon.rotation_z -= self.vel_balon.x * dt * 70

        if siguiente.y <= RADIO_BALON:
            siguiente.y = RADIO_BALON
            self.vel_balon.y = abs(self.vel_balon.y) * .39
            if self.vel_balon.y < .85:
                self.vel_balon.y = 0
            rozamiento = math.exp(-.36 * dt)
            self.vel_balon.x *= rozamiento
            self.vel_balon.z *= rozamiento
        else:
            rozamiento = math.exp(-.035 * dt)
            self.vel_balon.x *= rozamiento
            self.vel_balon.z *= rozamiento

        if abs(siguiente.z) > 6.78:
            siguiente.z = math.copysign(6.78, siguiente.z)
            self.vel_balon.z *= -.60

        self._colisionar_con_porteros(anterior, siguiente)
        self._colisionar_con_marcos(anterior, siguiente)

        for lado in (-1, 1):
            x_meta = lado * 12.35
            cruza = (
                anterior.x < x_meta <= siguiente.x if lado == 1
                else anterior.x > x_meta >= siguiente.x
            )
            if not cruza:
                continue
            delta_x = float(siguiente.x - anterior.x)
            if abs(delta_x) < .00001:
                continue
            fraccion = (x_meta - anterior.x) / delta_x
            y_cruce = anterior.y + (siguiente.y - anterior.y) * fraccion
            z_cruce = anterior.z + (siguiente.z - anterior.z) * fraccion
            if RADIO_BALON <= y_cruce <= 1.60 and abs(z_cruce) <= 1.40:
                self._registrar_gol(0 if lado == 1 else 1)
                return
            siguiente.x = x_meta - lado * .015
            self.vel_balon.x = (
                -abs(self.vel_balon.x) * .58 if lado == 1
                else abs(self.vel_balon.x) * .58
            )

        if abs(siguiente.x) > 12.35:
            siguiente.x = math.copysign(12.35, siguiente.x)
            self.vel_balon.x *= -.58

        self.balon.position = siguiente
        if (
            abs(self.vel_balon.x) + abs(self.vel_balon.y) + abs(self.vel_balon.z)
            < .06
        ):
            self.vel_balon = Vec3(0, 0, 0)

    def _seguir_camara(self, dt: float) -> None:
        """Acompaña el balón en perspectiva y cambia la distancia suavemente."""
        if self.vista_cenital or self.estado != "partido":
            return
        foco = Vec3(
            max(-2.8, min(2.8, float(self.balon.x) * .24)),
            0,
            max(-1.1, min(1.1, float(self.balon.z) * .16)),
        )
        velocidad = distancia_horizontal(self.vel_balon.x, self.vel_balon.z)
        distancia = 30.0 - min(1.8, velocidad * .055)
        posicion_objetivo = foco + Vec3(0, distancia * .72, -distancia)
        mezcla = 1.0 - math.exp(-1.45 * dt)
        camera.position += (posicion_objetivo - camera.position) * mezcla
        camera.look_at(foco)
        camera.fov += (59.0 - camera.fov) * min(1.0, dt * .7)

    def update(self) -> None:
        super().update()
        self._seguir_camara(min(float(time.dt), .04))

    def _configurar_camara(self) -> None:
        super()._configurar_camara()
        if not self.vista_cenital:
            camera.look_at(Vec3(0, 0, 0))

    def cerrar(self) -> None:
        try:
            self.audio.cerrar()
        except (AttributeError, RuntimeError):
            pass


def comprobar_modos_controles_y_gol(juego: Juego3DVolumetrico) -> None:
    """Comprueba escena, cuatro formatos, controles, tiro, atajada y gol."""
    for modo in (1, 2, 3, 4):
        juego.iniciar(modo)
        humanos = [p for p in juego.jugadores if p["control"] in ("H1", "H2")]
        total_humanos = 1 if modo == 1 else 2
        assert len(juego.jugadores) == 22
        assert len(humanos) == total_humanos
        assert all(p["sprite"] is None and p["cuerpo"].enabled for p in juego.jugadores)
        juego.ia.log.done = True  # No guardar partidas simuladas por esta prueba.

    held_keys["w"] = 1
    assert juego._movimiento("H1")[1] > 0
    held_keys["w"] = 0
    held_keys["up arrow"] = 1
    assert juego._movimiento("H2")[1] > 0
    held_keys["up arrow"] = 0

    # En modo 4, el usuario 1 es del equipo visitante y ataca hacia -X.
    jugador = next(p for p in juego.jugadores if p["control"] == "H1")
    jugador["e"].position = (-10.0, 0, 0)
    jugador["direccion"] = (-1.0, 0.0)
    juego.balon.position = (-10.55, .42, 0)
    juego.poseedor = jugador
    juego._patear(jugador, "tiro")
    assert juego.poseedor is None and juego.vel_balon.x < 0
    assert jugador["animador"].estado == "disparo"

    # La trayectoria contra el arquero vuelve al campo y no cuenta como gol.
    juego.poseedor = None
    juego.balon.position = (-11.0, .90, 0)
    juego.vel_balon = Vec3(-10.0, 0, 0)
    marcador_antes = juego.ia.log.score[1]
    juego._actualizar_balon(.04)
    assert juego.vel_balon.x > 0, "el portero no desvió el balón"
    assert juego.ia.log.score[1] == marcador_antes

    # Un disparo que toca el poste y otro que supera el larguero no son goles.
    juego.balon.position = (-12.20, 1.15, 1.50)
    juego.vel_balon = Vec3(-10.0, 0, 0)
    juego._actualizar_balon(.04)
    assert juego.ia.log.score[1] == marcador_antes, "un tiro al poste contó como gol"
    juego.balon.position = (-12.20, 1.82, 0)
    juego.vel_balon = Vec3(-10.0, 0, 0)
    juego._actualizar_balon(.04)
    assert juego.ia.log.score[1] == marcador_antes, "un tiro alto contó como gol"

    # Un tiro centrado y bajo atraviesa el hueco y devuelve el saque al rival.
    juego.balon.position = (-12.20, .70, 0)
    juego.vel_balon = Vec3(-10.0, 0, 0)
    juego._actualizar_balon(.04)
    assert juego.ia.log.score[1] == marcador_antes + 1
    assert juego.balon.x == 0
    juego.ia.log.done = True
    print(
        "PRUEBA OK: cuatro modos, 22 futbolistas geométricos, WASD/flechas, "
        "tiro, atajada, gol y saque central."
    )
    sys.stdout.flush()


def main() -> None:
    parser = argparse.ArgumentParser(description="Fútbol 3D volumétrico con Ursina")
    parser.add_argument(
        "--prueba-rapida", action="store_true",
        help="abre una escena breve y comprueba los cuatro modos y la física",
    )
    args = parser.parse_args()

    app = Ursina(
        title="Fútbol 3D · Estadio volumétrico",
        fullscreen=False,
        development_mode=False,
        editor_ui_enabled=False,
    )
    monitor = window.main_monitor
    if monitor:
        ancho = min(1440, int(monitor.width))
        alto = min(900, int(monitor.height))
        window.size = (ancho, alto)
        window.position = (
            int(monitor.x + (monitor.width - ancho) / 2),
            int(monitor.y + (monitor.height - alto) / 2),
        )
    juego = Juego3DVolumetrico()

    if args.prueba_rapida:
        comprobar_modos_controles_y_gol(juego)
        invoke(juego.cerrar)
        invoke(application.quit, delay=2.0)

    app.run()


if __name__ == "__main__":
    main()
