"""Estados de animación procedural para futbolistas formados con primitivas."""
from __future__ import annotations

import math


class AnimadorProcedural:
    """Anima articulaciones existentes sin crear geometría en cada fotograma."""

    DURACIONES = {
        "giro": .20,
        "pase": .30,
        "centro": .38,
        "disparo": .46,
        "celebracion": 1.70,
        "portero_salto": .62,
        "portero_estirada": .62,
    }

    def __init__(self, jugador: dict) -> None:
        self.tiempo_restante = 0.0
        self.direccion = 1
        self.ultimo_yaw = float(jugador["e"].rotation_y)
        self.estado = "espera"
        jugador["estado_animacion"] = "espera"

    def activar(
        self, estado: str, duracion: float | None = None, direccion: int = 1
    ) -> None:
        """Inicia una animación con duración limitada."""
        if duracion is None:
            duracion = self.DURACIONES.get(estado, .25)
        self.tiempo_restante = max(0.0, float(duracion))
        self.direccion = 1 if direccion >= 0 else -1
        self.estado = estado

    @staticmethod
    def _limpiar_pose(jugador: dict) -> None:
        jugador["cuerpo"].rotation_x = 0
        jugador["cuerpo"].rotation_y = 0
        jugador["cuerpo"].rotation_z = 0
        for pierna in jugador["piernas"]:
            pierna.rotation_z = 0
        for indice, brazo in enumerate(jugador["brazos"]):
            brazo.rotation_z = -12 if indice == 0 else 12
        if jugador["e"].y > .04:
            jugador["e"].y = 0

    def actualizar(self, jugador: dict, dt: float) -> None:
        """Actualiza la pose según movimiento, acción o función del portero."""
        self.tiempo_restante = max(0.0, self.tiempo_restante - dt)
        yaw = float(jugador["e"].rotation_y)
        diferencia = abs((yaw - self.ultimo_yaw + 180) % 360 - 180)
        self.ultimo_yaw = yaw

        if self.tiempo_restante > 0:
            estado = self.estado
        elif diferencia > 42:
            estado = "giro"
            self.tiempo_restante = .12
            self.estado = estado
        else:
            estado = (
                "carrera" if jugador.get("velocidad_anim", 0.0) > .16
                else "espera"
            )
        jugador["estado_animacion"] = estado
        self._limpiar_pose(jugador)

        velocidad = float(jugador.get("velocidad_anim", 0.0))
        fase = float(jugador.get("fase", 0.0))
        paso = min(39.0, 13.0 + velocidad * 3.1)
        swing = math.sin(fase) * paso

        if estado == "carrera":
            jugador["piernas"][0].rotation_z = swing
            jugador["piernas"][1].rotation_z = -swing
            jugador["brazos"][0].rotation_z = -12 - swing * .52
            jugador["brazos"][1].rotation_z = 12 + swing * .52
        elif estado == "giro":
            jugador["cuerpo"].rotation_z = -self.direccion * 12
            jugador["brazos"][0].rotation_z = -28
            jugador["brazos"][1].rotation_z = 28
        elif estado in ("pase", "centro", "disparo"):
            potencia = 33 if estado == "pase" else 48 if estado == "centro" else 72
            jugador["piernas"][1].rotation_z = -potencia
            jugador["brazos"][0].rotation_z = -32
            jugador["brazos"][1].rotation_z = 42
            jugador["cuerpo"].rotation_x = -8 if estado != "disparo" else -15
        elif estado == "celebracion":
            jugador["brazos"][0].rotation_z = 150
            jugador["brazos"][1].rotation_z = 210
            jugador["piernas"][0].rotation_z = -13
            jugador["piernas"][1].rotation_z = 13
            jugador["e"].y = .04 + abs(math.sin(fase * 1.5)) * .12
        elif estado in ("portero_salto", "portero_estirada"):
            inclinacion = 54 if estado == "portero_estirada" else 38
            jugador["cuerpo"].rotation_z = -self.direccion * inclinacion
            jugador["brazos"][0].rotation_z = -82
            jugador["brazos"][1].rotation_z = 82
            jugador["piernas"][0].rotation_z = 25 * self.direccion
            jugador["piernas"][1].rotation_z = -25 * self.direccion
            if estado == "portero_salto":
                jugador["e"].y = .08 + abs(math.sin(fase * 2)) * .17
