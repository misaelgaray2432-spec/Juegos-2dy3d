"""Audio del partido: ambiente y efectos WAV, más narración en proceso separado."""
from __future__ import annotations

import atexit
import math
import os
import queue
import random
import struct
import subprocess
import sys
import threading
import wave
from pathlib import Path


CARPETA_AUDIO = Path(__file__).resolve().parent / "assets" / "audio"


class AudioFutbol:
    """Reproduce sonidos con Pygame y delega TTS para no bloquear el juego."""

    def __init__(self) -> None:
        self.sonidos: dict[str, object] = {}
        self.ultimo_poseedor: str | None = None
        self.ultimo_anuncio = -10.0
        self.cola_voz: queue.Queue[str | None] = queue.Queue(maxsize=6)
        self.reproductor_voz: subprocess.Popen | None = None
        self.efectos_activos = False
        self.cerrado = False
        self._iniciar_efectos()
        # La voz se inicia aunque falle el dispositivo de mezcla de efectos.
        self._iniciar_voz()
        atexit.register(self.cerrar)

    @staticmethod
    def _crear_wav(ruta: Path, tipo: str, duracion: float,
                   frecuencia: int = 22050) -> None:
        """Crea recursos de audio del juego sin conexión ni archivos licenciados."""
        ruta.parent.mkdir(parents=True, exist_ok=True)
        rng = random.Random({"estadio": 31, "gol": 73, "silbato": 19, "balon": 47}[tipo])
        datos = bytearray()
        ruido_filtrado = 0.0
        total = max(1, round(duracion * frecuencia))
        for muestra_indice in range(total):
            t = muestra_indice / frecuencia
            borde = min(1.0, t / .28, (duracion - t) / .28)
            borde = max(0.0, borde)
            if tipo == "estadio":
                # Ruido rosa con tres bandas de público y oleadas de intensidad.
                ruido_filtrado = ruido_filtrado * .955 + rng.uniform(-1, 1) * .045
                oleada = .52 + .20 * math.sin(t * .77) + .11 * math.sin(t * 1.93)
                murmullo = .12 * math.sin(math.tau * 185 * t + .3 * math.sin(t * 2.1))
                cantos = .075 * math.sin(math.tau * 310 * t + .4 * math.sin(t * 1.3))
                valor = (ruido_filtrado * .74 + murmullo + cantos) * oleada * borde
            elif tipo == "gol":
                subida = min(1.0, t * 2.8)
                caida = max(0.0, 1 - t / duracion * .65)
                envolvente = subida * caida
                ruido_filtrado = ruido_filtrado * .90 + rng.uniform(-1, 1) * .10
                grito = (.22 * math.sin(math.tau * (270 + 26 * math.sin(t * 3)) * t)
                         + .14 * math.sin(math.tau * (410 + 17 * math.sin(t * 2)) * t))
                valor = (ruido_filtrado * .38 + grito) * envolvente * borde
            elif tipo == "silbato":
                envolvente = min(1.0, t * 28) * max(0.0, min(1.0, (duracion - t) * 13))
                valor = .64 * math.sin(math.tau * (1880 + 75 * math.sin(t * 8)) * t) * envolvente
            else:
                golpe = math.exp(-t * 33)
                valor = (rng.uniform(-1, 1) * .56 + .35 * math.sin(math.tau * 125 * t)) * golpe
            pcm = int(max(-.95, min(.95, valor)) * 32767)
            datos.extend(struct.pack("<h", pcm))
        with wave.open(str(ruta), "wb") as archivo:
            archivo.setnchannels(1)
            archivo.setsampwidth(2)
            archivo.setframerate(frecuencia)
            archivo.writeframes(datos)

    def _iniciar_efectos(self) -> None:
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=1024)
            pygame.mixer.set_num_channels(16)
            duraciones = {"estadio": 7.0, "gol": 3.4, "silbato": .75, "balon": .28}
            for nombre, duracion in duraciones.items():
                archivo = CARPETA_AUDIO / f"{nombre}.wav"
                if not archivo.exists():
                    self._crear_wav(archivo, nombre, duracion)
                self.sonidos[nombre] = pygame.mixer.Sound(str(archivo))
            # El sonido de tribuna se oye claramente, sin tapar los comentarios.
            self.sonidos["estadio"].set_volume(.46)
            self.sonidos["gol"].set_volume(.92)
            self.sonidos["silbato"].set_volume(.62)
            self.sonidos["balon"].set_volume(.76)
            self.sonidos["estadio"].play(loops=-1)
            self.efectos_activos = True
        except Exception as error:
            self._registrar_estado_voz(f"Mezclador de audio no disponible: {error}")
            # Plan B en Windows: al menos suena la tribuna mediante winsound.
            if os.name == "nt":
                try:
                    import winsound
                    winsound.PlaySound(str(CARPETA_AUDIO / "estadio.wav"),
                                       winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
                    self.efectos_activos = True
                except Exception:
                    self.efectos_activos = False

    @staticmethod
    def _registrar_estado_voz(estado: str) -> None:
        ruta = CARPETA_AUDIO.parent / "narrador_estado.txt"
        try:
            ruta.parent.mkdir(parents=True, exist_ok=True)
            ruta.write_text(estado, encoding="utf-8")
        except OSError:
            pass

    def _iniciar_voz(self) -> None:
        """El motor de voz corre en otro Python para que Windows/SAPI tenga su COM propio."""
        trabajador = Path(__file__).resolve().parent / "narrador_local.py"
        try:
            self.reproductor_voz = subprocess.Popen(
                [sys.executable, str(trabajador)], stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                text=True, encoding="utf-8", bufsize=1,
                cwd=str(Path(__file__).resolve().parent),
            )
            hilo = threading.Thread(target=self._enviar_textos_voz, daemon=True,
                                    name="comentarista-futbol")
            hilo.start()
        except Exception as error:
            self._registrar_estado_voz(f"No se pudo iniciar la voz: {error}")

    def _enviar_textos_voz(self) -> None:
        proceso = self.reproductor_voz
        if proceso is None or proceso.stdin is None:
            return
        try:
            while True:
                texto = self.cola_voz.get()
                if texto is None or proceso.poll() is not None:
                    break
                proceso.stdin.write(texto.replace("\n", " ") + "\n")
                proceso.stdin.flush()
        except (BrokenPipeError, OSError, ValueError):
            pass
        finally:
            try:
                proceso.stdin.close()
            except (OSError, ValueError):
                pass

    def narrar(self, texto: str) -> None:
        try:
            self.cola_voz.put_nowait(texto)
        except queue.Full:
            try:
                self.cola_voz.get_nowait()
                self.cola_voz.put_nowait(texto)
            except queue.Empty:
                pass

    def posesion(self, nombre: str, pais: str, ahora: float) -> None:
        clave = f"{pais}:{nombre}"
        if clave != self.ultimo_poseedor and ahora - self.ultimo_anuncio >= 1.0:
            self.ultimo_poseedor = clave
            self.ultimo_anuncio = ahora
            self.narrar(f"{nombre}, de {pais}, conduce el balón.")

    def efecto(self, nombre: str) -> None:
        sonido = self.sonidos.get(nombre)
        if sonido is not None:
            try:
                sonido.play()
            except Exception:
                pass
        elif os.name == "nt" and nombre in ("gol", "silbato", "balon"):
            try:
                import winsound
                archivo = CARPETA_AUDIO / f"{nombre}.wav"
                winsound.PlaySound(str(archivo), winsound.SND_FILENAME | winsound.SND_ASYNC)
            except Exception:
                pass

    def gol(self, nombre: str, pais: str) -> None:
        self.efecto("gol")
        self.ultimo_poseedor = None
        self.narrar(f"¡Gooooool! ¡Gol de {nombre}, para {pais}!")

    def jugada(self, nombre: str, accion: str) -> None:
        # Si el mismo jugador recupera el balón después de una acción,
        # debe volver a anunciarse su posesión.
        self.ultimo_poseedor = None
        frases = {
            "tiro": f"¡Remate de {nombre}!",
            "pase": f"Pase de {nombre}.",
            "centro": f"¡Centro al área de {nombre}!",
        }
        if accion in frases:
            self.narrar(frases[accion])

    def cerrar(self) -> None:
        if self.cerrado:
            return
        self.cerrado = True
        try:
            self.sonidos.get("estadio").stop()
        except Exception:
            pass
        if os.name == "nt":
            try:
                import winsound
                winsound.PlaySound(None, 0)
            except Exception:
                pass
        try:
            while True:
                self.cola_voz.get_nowait()
        except queue.Empty:
            self.cola_voz.put_nowait(None)
        if self.reproductor_voz is not None:
            try:
                self.reproductor_voz.wait(timeout=.4)
            except subprocess.TimeoutExpired:
                self.reproductor_voz.terminate()
